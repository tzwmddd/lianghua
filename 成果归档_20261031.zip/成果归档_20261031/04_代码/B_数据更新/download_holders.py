"""下载股东户数 + 增减持 + 十大流通股东, 用于构造正交因子。

股东户数(holder_num)下降 = 筹码集中, 是中证500/1000 上最经典、最不易拥挤的
正交因子之一, 与现有 22 个技术面因子相关性极低。

用法:
  python download_holders.py 1000            # 下载股东户数
  python download_holders.py 1000 --check    # 只看已有缓存进度
"""
import argparse
import os
import sys
import time

import pandas as pd

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

import tushare_common as tc

UNIVERSES = {"500": "cache_zz500", "1000": "cache_zz1000"}
START = "20150101"


def fetch_holdernumber(pro, ts_code):
    """股东户数: 用 ts_code 单只拉, 覆盖全历史。"""
    df = pro.stk_holdernumber(ts_code=ts_code,
                              start_date=START, end_date="20261231")
    if df is None or df.empty:
        return None
    return df[["ts_code", "ann_date", "end_date", "holder_num"]]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("universe", nargs="?", default="1000", choices=["500", "1000"])
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--limit", type=int, default=0)
    args = ap.parse_args()

    cache_dir = UNIVERSES[args.universe]
    cons = pd.read_csv(os.path.join(cache_dir, "_constituents.csv"), dtype={"code": str})
    codes = sorted(cons["code"].unique())
    path = os.path.join(cache_dir, "_holder_number.csv")

    done = set()
    if os.path.exists(path):
        old = pd.read_csv(path, dtype={"code": str}, usecols=["code"])
        done = set(old["code"].unique())
    todo = [c for c in codes if c not in done]
    print(f"{cache_dir}: 成分股 {len(codes)} 只, 已有 {len(done)} 只, 待下载 {len(todo)} 只",
          flush=True)
    if args.check:
        print("(--check) 未下载任何数据", flush=True)
        return
    if args.limit:
        todo = todo[:args.limit]

    pro = tc.get_pro()
    parts, fails = [], []
    t0 = time.time()
    for i, code in enumerate(todo):
        try:
            df = tc._retry(lambda: fetch_holdernumber(pro, tc.to_ts_code(code)))
            if df is not None and len(df):
                df = df.copy()
                df["code"] = code
                parts.append(df)
        except Exception as e:  # noqa: BLE001
            fails.append((code, repr(e)[:60]))
        if (i + 1) % 200 == 0:
            el = time.time() - t0
            print(f"  进度 {i + 1}/{len(todo)}  用时 {el:.0f}s  "
                  f"预计剩余 {el / (i + 1) * (len(todo) - i - 1):.0f}s", flush=True)
        tc.sleep(0.25)

    if parts:
        new = pd.concat(parts, ignore_index=True)
        new["ann_date"] = pd.to_datetime(new["ann_date"], errors="coerce")
        new["end_date"] = pd.to_datetime(new["end_date"], errors="coerce")
        new = new.dropna(subset=["ann_date", "holder_num"])
        if os.path.exists(path):
            old = pd.read_csv(path, dtype={"code": str},
                              parse_dates=["ann_date", "end_date"])
            new = pd.concat([old, new], ignore_index=True)
        new = new.drop_duplicates(subset=["code", "end_date"]).sort_values(["code", "end_date"])
        new.to_csv(path, index=False, encoding="utf-8-sig")
        print(f"\n保存 {path}: {len(new)} 行, {new['code'].nunique()} 只", flush=True)
        print(f"  日期范围 {new['end_date'].min().date()} ~ {new['end_date'].max().date()}", flush=True)
    if fails:
        print(f"失败 {len(fails)} 只: {fails[:5]}", flush=True)
    print(f"总耗时 {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
