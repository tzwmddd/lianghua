"""中证500/1000 数据增量更新器。

解决现有链路的问题: download_zz_daily.py 的 `todo = [c for c in all_codes if c not in have]`
只下载"完全没有缓存"的股票, 已存在的 {code}.csv 永远不会更新 —— 数据会静默停止增长,
而 recommend_zz.py 照样能跑出一个看着正常的推荐榜。

本脚本的做法:
  1. 只用"最新基准"做增量拼接(而不是完整 adj_factor 序列), 把每只股票 3 次 API 降到 2 次
  2. 拼接点连续性校验: 用缓存末日与新数据首日的实际价格对比, 跳变超阈值就判定基准变了,
     退回完整拉取
  3. 维护 _daily_meta.csv 记录每只股票使用的复权基准, 下次增量就能精确换算
  4. 更新后打印新鲜度体检: 有多少股票落后于最新交易日

用法:
  python update_data.py 1000                 # 体检 + 增量更新
  python update_data.py 1000 --check         # 只体检不改数据
  python update_data.py 1000 --limit 50      # 只处理 50 只(试跑用)
  python update_data.py 1000 --full          # 强制全量重拉(基准不明时用)
  python update_data.py 1000 --asof 20260911 # 指定"最新交易日"
"""
import argparse
import glob
import os
import sys
import time

import numpy as np
import pandas as pd

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

import tushare_common as tc

UNIVERSES = {
    "500": ("000905.SH", "cache_zz500"),
    "1000": ("000852.SH", "cache_zz1000"),
}
START = "20150101"
MIN_ROWS = 120
JUMP_TOL = 0.01          # 拼接点跳变容忍度(1%): 超过就认为复权基准变了
STALE_SKIP_DAYS = 60     # 落后超过这么多天视为已退市/停牌, 不再浪费 API 检查
SLEEP = 0.30             # tushare 限流约 200 次/分钟, 每只 2 次调用 -> 0.3s 安全


def load_meta(cache_dir):
    path = os.path.join(cache_dir, "_daily_meta.csv")
    if os.path.exists(path):
        m = pd.read_csv(path, dtype={"code": str})
        return {r["code"]: r for _, r in m.iterrows()}
    return {}


def save_meta(cache_dir, meta):
    path = os.path.join(cache_dir, "_daily_meta.csv")
    rows = [{"code": c, "basis_factor": v.get("basis_factor", np.nan),
             "last_date": v.get("last_date"), "updated_at": v.get("updated_at")}
            for c, v in sorted(meta.items())]
    pd.DataFrame(rows).to_csv(path, index=False, encoding="utf-8-sig")
    return path


def read_cache(cache_dir, code):
    p = os.path.join(cache_dir, f"{code}.csv")
    if not os.path.exists(p):
        return None
    try:
        df = pd.read_csv(p, parse_dates=["date"])
    except Exception:
        return None
    if len(df) == 0:
        return None
    return df.sort_values("date").reset_index(drop=True)


def fetch_daily(pro, ts_code, start, end):
    """拉不复权日线(含成交额 amount, 供流动性过滤用)。"""
    daily = pro.daily(ts_code=ts_code, start_date=start, end_date=end)
    if daily is None or daily.empty:
        return None
    daily = daily.rename(columns={"vol": "volume"})
    daily["date"] = pd.to_datetime(daily["trade_date"])
    cols = ["date", "open", "high", "low", "close", "volume"]
    if "amount" in daily.columns:
        cols.append("amount")
    return daily[cols].sort_values("date").reset_index(drop=True)


def fetch_adj(pro, ts_code, start, end):
    """拉复权因子序列(只取 trade_date/adj_factor)。"""
    adj = pro.adj_factor(ts_code=ts_code, start_date=start, end_date=end)
    if adj is None or adj.empty:
        return None
    adj["date"] = pd.to_datetime(adj["trade_date"])
    return adj[["date", "adj_factor"]].sort_values("date").reset_index(drop=True)


def to_qfq(df, basis):
    """按给定基准做前复权(基准 = 最新 adj_factor)。"""
    f = df["adj_factor"] / basis
    out = df.copy()
    for col in ["open", "high", "low", "close"]:
        out[col] = out[col] * f
    cols = ["date", "open", "high", "low", "close", "volume"]
    if "amount" in out.columns:
        cols.append("amount")
    return out[cols]


def process_one(pro, cache_dir, code, latest_date, meta, force_full=False,
                fetch_daily_fn=None, fetch_adj_fn=None):
    """更新单只股票。返回 (状态, 说明)。状态: ok_incr / ok_full / skip / fail。

    增量判断全部基于"从缓存自身反推的真实基准", 不依赖外部记录:
      前复权缓存里每行价格的隐含 adj 比例恒定, 用它去匹配完整 adj 序列,
      就能知道缓存末日对应的 adj_factor; 再看该日之后 adj 是否变化,
      即可判断有没有除权。这样即使 _daily_meta.csv 丢失或写错也不会出错。

    fetch_daily_fn / fetch_adj_fn 可注入(测试用)。
    """
    fd = fetch_daily_fn or (lambda c, s, e: fetch_daily(pro, c, s, e))
    fa = fetch_adj_fn or (lambda c, s, e: fetch_adj(pro, c, s, e))
    ts_code = tc.to_ts_code(code)
    cached = read_cache(cache_dir, code)
    end_str = latest_date.strftime("%Y%m%d")

    if cached is None or len(cached) == 0:
        return _full_pull(fd, cache_dir, code, ts_code, latest_date, meta, "无缓存")

    last = cached["date"].iloc[-1]
    if last >= latest_date and not force_full:
        if code not in meta:
            adj_all = fa(ts_code, START, end_str)
            if adj_all is not None and len(adj_all):
                meta[code] = {"basis_factor": float(adj_all["adj_factor"].iloc[-1]),
                              "last_date": str(last.date()),
                              "updated_at": pd.Timestamp.now().strftime("%Y-%m-%d %H:%M")}
        return "skip", "已最新"

    # ---- 一次调用拿完整 adj 序列(11 年约 2700 行 < 单次 6000 上限) ----
    adj_all = fa(ts_code, START, end_str)
    if adj_all is None or len(adj_all) == 0:
        return _full_pull(fd, cache_dir, code, ts_code, latest_date, meta, "无复权数据", adj_all)

    # ---- 反推缓存末日对应的 adj_factor ----
    m = adj_all["date"] <= last
    if not m.any():
        return _full_pull(fd, cache_dir, code, ts_code, latest_date, meta, "缓存早于数据源", adj_all)
    target = float(adj_all.loc[m, "adj_factor"].iloc[-1])
    cand = (adj_all["adj_factor"] - target).abs() / target
    if float(cand.min()) > 0.01:
        return _full_pull(fd, cache_dir, code, ts_code, latest_date, meta, "基准无法反推", adj_all)
    basis = float(adj_all.loc[cand.idxmin(), "adj_factor"])

    # ---- 校验: 缓存末日之后复权因子是否变化(除权/送转) ----
    after = adj_all[adj_all["date"] >= last]
    if len(after) and float((after["adj_factor"] / basis - 1.0).abs().max()) > JUMP_TOL:
        return _full_pull(fd, cache_dir, code, ts_code, latest_date, meta, "期间除权", adj_all)

    # ---- 增量拼接(全程用缓存自己的基准, 保证历史价格一字不改) ----
    start = (last + pd.Timedelta(days=1)).strftime("%Y%m%d")
    if start > end_str:
        return "skip", "无新数据"
    new_raw = fd(ts_code, start, end_str)
    if new_raw is None or len(new_raw) == 0:
        return "skip", "无新数据"
    new_adj = adj_all[adj_all["date"] > last][["date", "adj_factor"]]
    if len(new_adj) == 0:
        return _full_pull(fd, cache_dir, code, ts_code, latest_date, meta, "缺新复权因子", adj_all)
    new = new_raw.merge(new_adj, on="date", how="left")
    new["adj_factor"] = new["adj_factor"].ffill().bfill()
    if new["adj_factor"].isna().any():
        return _full_pull(fd, cache_dir, code, ts_code, latest_date, meta, "新复权因子缺失", adj_all)

    new_q = to_qfq(new, basis)
    merged = pd.concat([cached, new_q], ignore_index=True)
    merged = merged.drop_duplicates("date").sort_values("date").reset_index(drop=True)
    merged.to_csv(os.path.join(cache_dir, f"{code}.csv"), index=False)
    meta[code] = {"basis_factor": basis,
                  "last_date": str(merged["date"].iloc[-1].date()),
                  "updated_at": pd.Timestamp.now().strftime("%Y-%m-%d %H:%M")}
    return "ok_incr", f"+{len(new)} 行"


def _full_pull(fd, cache_dir, code, ts_code, latest_date, meta, reason, adj_all=None):
    """全量重拉。

    关键: 尽量沿用**缓存已有的基准**(adj_all 里与缓存末日匹配的那个值),
    这样历史价格一字不改, 只有新增段是新的。拿不到 adj_all 时才退化为
    原始价格落盘 —— 收益率不受影响, 但下次会再全量一次。
    """
    raw = fd(ts_code, START, latest_date.strftime("%Y%m%d"))
    if raw is None or len(raw) < MIN_ROWS:
        return "fail", f"数据不足({reason})"
    cached = read_cache(cache_dir, code)
    basis = np.nan
    if adj_all is not None and len(adj_all) and cached is not None and len(cached):
        last = cached["date"].iloc[-1]
        m = adj_all["date"] <= last
        if m.any():
            target = float(adj_all.loc[m, "adj_factor"].iloc[-1])
            cand = (adj_all["adj_factor"] - target).abs() / target
            if float(cand.min()) <= 0.01:
                basis = float(adj_all.loc[cand.idxmin(), "adj_factor"])
    if np.isfinite(basis):
        new = raw.merge(adj_all, on="date", how="left")
        new["adj_factor"] = new["adj_factor"].ffill().bfill()
        out = to_qfq(new, basis)
    else:
        cols = ["date", "open", "high", "low", "close", "volume"]
        if "amount" in raw.columns:
            cols.append("amount")
        out = raw[cols].copy()
    out.to_csv(os.path.join(cache_dir, f"{code}.csv"), index=False)
    meta[code] = {"basis_factor": basis,
                  "last_date": str(out["date"].iloc[-1].date()),
                  "updated_at": pd.Timestamp.now().strftime("%Y-%m-%d %H:%M")}
    return "ok_full", f"全量({reason}) {len(out)} 行"


def latest_trade_date(pro, asof=None):
    """从 tushare 交易日历取"最新的已收盘交易日"。

    不能用本地 index.csv 的末日当基准(那样永远显示"已是最新")。
    """
    today = pd.Timestamp(asof) if asof else pd.Timestamp.today().normalize()
    start = (today - pd.Timedelta(days=20)).strftime("%Y%m%d")
    cal = pro.trade_cal(exchange="SSE", start_date=start,
                        end_date=today.strftime("%Y%m%d"), is_open="1")
    if cal is None or cal.empty:
        return None
    days = sorted(cal["cal_date"].astype(str))
    cand = [d for d in days if d < today.strftime("%Y%m%d")]
    if not cand:
        cand = days
    return pd.Timestamp(cand[-1])


def sync_index(pro, index_code, cache_dir, latest):
    """把指数日线(index.csv)更新到最新。"""
    path = os.path.join(cache_dir, "index.csv")
    old = pd.read_csv(path, parse_dates=["date"]) if os.path.exists(path) else None
    start = "20150101"
    if old is not None and len(old):
        last = old["date"].max()
        if last >= latest:
            print(f"  指数已最新: {last.date()}", flush=True)
            return False
        start = (last + pd.Timedelta(days=1)).strftime("%Y%m%d")
    df = pro.index_daily(ts_code=index_code, start_date=start,
                         end_date=latest.strftime("%Y%m%d"))
    if df is None or df.empty:
        print(f"  指数无新数据 (从 {start} 起查)", flush=True)
        return False
    df = df.rename(columns={"vol": "volume"})
    df["date"] = pd.to_datetime(df["trade_date"])
    df = df[["date", "open", "high", "low", "close", "volume"]]
    out = df if old is None else pd.concat([old, df], ignore_index=True)
    out = out.drop_duplicates("date").sort_values("date").reset_index(drop=True)
    out.to_csv(path, index=False)
    print(f"  指数已更新: 新增 {len(df)} 行, 现末日 {out['date'].max().date()}", flush=True)
    return True


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("universe", nargs="?", default="1000", choices=["500", "1000"])
    ap.add_argument("--check", action="store_true", help="只体检, 不改数据")
    ap.add_argument("--full", action="store_true", help="强制全量重拉")
    ap.add_argument("--limit", type=int, default=0, help="只处理前 N 只(试跑)")
    ap.add_argument("--asof", default=None, help="指定最新交易日 YYYYMMDD")
    args = ap.parse_args()

    index_code, cache_dir = UNIVERSES[args.universe]
    t0 = time.time()

    # ---- 体检 ----
    pro = tc.get_pro()
    cons = pd.read_csv(os.path.join(cache_dir, "_constituents.csv"), dtype={"code": str})
    codes = sorted(cons["code"].unique())
    # 最新交易日必须问 tushare 交易日历(本地 index.csv 的末日可能就是过期的)
    latest = None
    if args.asof:
        latest = pd.Timestamp(args.asof)
    else:
        latest = latest_trade_date(pro)
    idx = pd.read_csv(os.path.join(cache_dir, "index.csv"), parse_dates=["date"])
    idx_last = idx["date"].max()
    if latest is None:
        latest = idx_last
    print(f"\n=== 中证{args.universe} 数据新鲜度体检 ===", flush=True)
    print(f"  tushare 最新已收盘交易日: {latest.date()}", flush=True)
    print(f"  本地指数末日            : {idx_last.date()}", flush=True)

    rows = []
    for code in codes:
        d = read_cache(cache_dir, code)
        if d is None or len(d) == 0:
            rows.append((code, None, 0))
        else:
            rows.append((code, d["date"].iloc[-1], len(d)))
    chk = pd.DataFrame(rows, columns=["code", "last", "n"])
    lag = (latest - chk["last"]).dt.days
    print(f"  股票总数 {len(chk)}", flush=True)
    print(f"  已是最新(末日 == 最新交易日): {(chk['last'] == latest).sum()}", flush=True)
    print(f"  落后 1~7 天 : {((lag >= 1) & (lag <= 7)).sum()}", flush=True)
    print(f"  落后 8~60 天: {((lag > 7) & (lag <= 60)).sum()}", flush=True)
    print(f"  落后 >60 天(多半已退市/停牌): {(lag > 60).sum()}", flush=True)
    print(f"  无数据      : {chk['last'].isna().sum()}", flush=True)
    need = chk[(chk["last"] < latest) & chk["last"].notna()]
    # 落后超过 STALE_SKIP_DAYS 的基本是已退市/长期停牌, 不必浪费 API 去查
    need = need[(latest - need["last"]).dt.days <= STALE_SKIP_DAYS]
    n_stale = int(((chk["last"] < latest) & chk["last"].notna()
                   & ((latest - chk["last"]).dt.days > STALE_SKIP_DAYS)).sum())
    print(f"  需要更新    : {len(need)} 只"
          f" (另有 {n_stale} 只落后 >{STALE_SKIP_DAYS} 天, 视为已退市/停牌, 跳过)", flush=True)

    if args.check:
        print(f"\n[--check] 未修改任何数据。总耗时 {time.time() - t0:.0f}s", flush=True)
        return

    # ---- 先同步指数 ----
    print(f"\n[1/2] 同步指数日线", flush=True)
    sync_index(pro, index_code, cache_dir, latest)

    meta = load_meta(cache_dir)
    have_meta = len(meta)
    print(f"\n[2/2] 更新个股 (共 {len(need)} 只需要处理)", flush=True)
    print(f"  复权基准记录: 已有 {have_meta} 只"
          f"{'(首次运行, 新股票将走全量拉取)' if have_meta == 0 else ''}", flush=True)

    todo = [c for c in codes if c in set(need["code"])]
    if args.limit:
        todo = todo[:args.limit]
    print(f"  本次处理 {len(todo)} 只", flush=True)

    fetch_d = lambda c, s, e: fetch_daily(pro, c, s, e)
    fetch_a = lambda c, s, e: fetch_adj(pro, c, s, e)
    stats = {"ok_incr": 0, "ok_full": 0, "skip": 0, "fail": 0}
    fails = []
    for i, code in enumerate(todo):
        try:
            st, msg = tc._retry(lambda: process_one(pro, cache_dir, code, latest, meta,
                                                    force_full=args.full,
                                                    fetch_daily_fn=fetch_d, fetch_adj_fn=fetch_a))
            stats[st] = stats.get(st, 0) + 1
            if st == "fail":
                fails.append((code, msg))
        except Exception as e:  # noqa: BLE001
            stats["fail"] += 1
            fails.append((code, repr(e)[:60]))
        if (i + 1) % 100 == 0:
            el = time.time() - t0
            print(f"  进度 {i + 1}/{len(todo)}  增量 {stats['ok_incr']} 全量 {stats['ok_full']} "
                  f"失败 {stats['fail']}  用时 {el:.0f}s "
                  f"预计剩余 {el / (i + 1) * (len(todo) - i - 1):.0f}s", flush=True)
        tc.sleep(SLEEP)

    path = save_meta(cache_dir, meta)
    print(f"\n完成: 增量 {stats['ok_incr']}, 全量 {stats['ok_full']}, "
          f"跳过 {stats['skip']}, 失败 {stats['fail']}", flush=True)
    print(f"复权基准记录已保存: {path} ({len(meta)} 只)", flush=True)
    if fails:
        with open(os.path.join(cache_dir, "_update_failed.txt"), "w", encoding="utf-8") as f:
            for c, m in fails:
                f.write(f"{c}: {m}\n")
        print(f"失败明细见 {cache_dir}/_update_failed.txt", flush=True)
    print(f"总耗时 {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
