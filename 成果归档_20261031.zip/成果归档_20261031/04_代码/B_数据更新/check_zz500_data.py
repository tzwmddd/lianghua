"""中证500 数据完整性全面检查。

检查项:
  1. 个股日线: 数量、末日分布、是否有缺口
  2. 指数日线
  3. 成分股快照
  4. 各类因子数据: 行数、日期范围、覆盖股票数、缺失月份
  5. 与中证1000 对比(找出500 相对缺什么)
"""
import glob
import os
import sys

import pandas as pd

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

CHECKS = [
    ("index.csv", "date", "指数日线"),
    ("_constituents.csv", "snapshot_date", "成分股快照"),
    ("_daily_basic.csv", "date", "市值/PE/PB/换手率"),
    ("_financial.csv", "ann_date", "财务指标"),
    ("_holder_number.csv", "ann_date", "股东户数"),
    ("_moneyflow.csv", "date", "资金流"),
    ("_amount.csv", "date", "成交额"),
    ("_forecast.csv", "ann_date", "业绩预告"),
    ("_holder_trade.csv", "ann_date", "增减持"),
    ("_share_float.csv", "ann_date", "解禁"),
    ("_top_list.csv", "trade_date", "龙虎榜个股"),
    ("_top_inst.csv", "trade_date", "龙虎榜机构"),
    ("_express.csv", "ann_date", "业绩快报"),
]

for cache, label in [("cache_zz500", "中证500"), ("cache_zz1000", "中证1000")]:
    print(f"\n{'='*70}\n{label}  ({cache})\n{'='*70}")
    files = [f for f in glob.glob(f"{cache}/*.csv")
             if os.path.splitext(os.path.basename(f))[0].isdigit()]
    print(f"个股日线文件数: {len(files)}")
    if files:
        tails = []
        for f in files:
            try:
                d = pd.read_csv(f, parse_dates=["date"], usecols=["date"])
                tails.append(d["date"].max())
            except Exception:
                pass
        s = pd.Series(tails)
        print(f"  末日分布(前5): {s.value_counts().head(5).to_dict()}")
        print(f"  最新末日: {s.max().date()}")

    for fname, dcol, desc in CHECKS:
        if fname is None:
            continue
        p = os.path.join(cache, fname)
        if not os.path.exists(p):
            print(f"  [缺] {desc:<18} ({fname})")
            continue
        try:
            d = pd.read_csv(p, usecols=[dcol, "code"], dtype={"code": str})
        except Exception:
            try:
                d = pd.read_csv(p, usecols=[dcol])
            except Exception as e:
                print(f"  [?] {desc:<18} 读取失败: {str(e)[:40]}")
                continue
        dt = pd.to_datetime(d[dcol], format="%Y%m%d", errors="coerce")
        n_code = d["code"].nunique() if "code" in d.columns else -1
        print(f"  [OK] {desc:<18} {len(d):>8} 行, {n_code:>5} 只, "
              f"{dt.min().date()} ~ {dt.max().date()}")
