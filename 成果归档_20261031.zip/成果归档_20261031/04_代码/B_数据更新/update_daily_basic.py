"""补齐/更新每日指标表(_daily_basic.csv): 市值/PE/PB/换手率。

为什么需要单独做:
  日线由 update_data.py 更新, 但 _daily_basic.csv 最初是用
  download_zz_daily_basic.py 下载的(只下载缺失的股票, 不更新已有),
  于是它停留在 2026-09-11, 落后日线 13 个交易日。
  而这张表支撑两件事:
    1. 市值中性化(size 因子) —— cross_section.neutralize 用它
    2. 流动性过滤 —— 选股时剔除换手率最低 20%
  不补齐会让最新截面的中性化和流动性过滤都失真。

做法: 按 trade_date 拉全市场(单日约 5300 行 < 单次上限), 筛出成分股后追加。

用法:
  python update_daily_basic.py 500             # 增量补齐到最新
  python update_daily_basic.py 500 --check      # 只看差距
"""
import argparse
import os
import sys
import time

import pandas as pd

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

import tushare_common as tc

UNIVERSES = {"500": "cache_zz500", "1000": "cache_zz1000"}
COLS = ["total_mv", "pe_ttm", "pb", "turnover_rate"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("universe", nargs="?", default="500", choices=["500", "1000"])
    ap.add_argument("--check", action="store_true")
    args = ap.parse_args()

    cache_dir = UNIVERSES[args.universe]
    path = os.path.join(cache_dir, "_daily_basic.csv")
    cons = pd.read_csv(os.path.join(cache_dir, "_constituents.csv"), dtype={"code": str})
    universe = set(cons["code"].unique())

    old = pd.read_csv(path, parse_dates=["date"], dtype={"code": str})
    last = old["date"].max()
    print(f"{cache_dir}/_daily_basic.csv: {len(old)} 行, 最新 {last.date()}", flush=True)

    pro = tc.get_pro()
    today = pd.Timestamp.today().normalize().strftime("%Y%m%d")
    cal = pro.trade_cal(exchange="SSE", start_date=last.strftime("%Y%m%d"),
                        end_date=today, is_open="1")
    days = [d for d in sorted(cal["cal_date"].astype(str)) if d > last.strftime("%Y%m%d")]
    print(f"待补齐交易日: {len(days)} 天 ({days[0] if days else '-'} ~ {days[-1] if days else '-'})",
          flush=True)
    if args.check or not days:
        print("(--check 或无需更新)", flush=True)
        return

    t0 = time.time()
    buf, ok, fail = [], 0, 0
    for i, d in enumerate(days):
        try:
            df = tc._retry(lambda: pro.daily_basic(trade_date=d))
            if df is not None and not df.empty:
                df = df.copy()
                df["code"] = df["ts_code"].map(tc.to_code)
                df = df[df["code"].isin(universe)]
                if len(df):
                    sub = df[["code", "trade_date"] + [c for c in COLS if c in df.columns]].copy()
                    sub["date"] = pd.to_datetime(sub["trade_date"])
                    buf.append(sub.drop(columns=["trade_date"]))
                    ok += 1
        except Exception as e:  # noqa: BLE001
            fail += 1
            if fail <= 3:
                print(f"  {d} 失败: {str(e)[:50]}", flush=True)
        tc.sleep(0.3)
    if buf:
        new = pd.concat(buf, ignore_index=True)
        merged = pd.concat([old, new], ignore_index=True)
        merged = merged.drop_duplicates(subset=["code", "date"]).sort_values(["code", "date"])
        merged.to_csv(path, index=False, encoding="utf-8-sig")
        print(f"保存 {path}: {len(merged)} 行 (新增 {len(merged) - len(old)}), "
              f"最新 {merged['date'].max().date()}", flush=True)
    print(f"成功 {ok} 天, 失败 {fail} 天, 耗时 {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
