﻿# ============================================================
#  中证500 / 1000  数据更新 + 榜单生成
#
#  用法(双击对应的 .bat 即可, 或在 PowerShell 里):
#     .\update_data.ps1 -Market 500        更新中证500 并出榜单
#     .\update_data.ps1 -Market 1000       更新中证1000
#     .\update_data.ps1 -Market both       两个市场都做
#     .\update_data.ps1 -Market 500 -Check 只看数据差距(不下载)
#
#  说明: 文件名与内容都用英文/ASCII, 避免 PowerShell/cmd 的编码问题。
#        控制台输出仍是中文, 不影响阅读。
# ============================================================

param(
    [ValidateSet("500", "1000", "both")]
    [string]$Market = "500",
    [switch]$Check,
    [switch]$NoRecommend,
    [switch]$SkipFactors
)

$ErrorActionPreference = "Continue"
$base = Split-Path -Parent $MyInvocation.MyCommand.Definition
Set-Location $base
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

Write-Host ""
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "   中证500/1000 量化选股 - 数据更新与榜单生成" -ForegroundColor Cyan
Write-Host "================================================================" -ForegroundColor Cyan

try {
    $v = (& python --version 2>&1)
    Write-Host "   $v" -ForegroundColor DarkGray
} catch {
    Write-Host "   [错误] 未找到 python, 请先安装并加入 PATH" -ForegroundColor Red
    Read-Host "   按回车退出"
    exit 1
}

$pyArgs = @("run_update.py", $Market)
if ($Check)       { $pyArgs += "--check" }
if ($NoRecommend) { $pyArgs += "--no-recommend" }
if ($SkipFactors) { $pyArgs += "--skip-factors" }

Write-Host "   执行: python $($pyArgs -join ' ')" -ForegroundColor DarkGray

& python @pyArgs
$code = $LASTEXITCODE

Write-Host ""
if ($code -eq 0) {
    Write-Host "   全部完成" -ForegroundColor Green
} else {
    Write-Host "   有步骤失败 (退出码 $code), 请查看上方日志" -ForegroundColor Yellow
}

if (-not $Check -and -not $NoRecommend) {
    $results = Join-Path $base "results"
    if (Test-Path $results) {
        Write-Host "   结果目录: $results" -ForegroundColor DarkGray
        Start-Process explorer.exe $results
    }
}

Write-Host ""
Read-Host "   按回车关闭窗口"
