"""下载事件型数据: 增减持(stk_holdertrade) / 解禁(share_float) / 业绩预告(forecast) / 业绩快报(express)。

统一按"公告日"批量拉取(单次返回全市场), 再筛出中证500/1000 成分股并集, 压缩存储。
所有表都保留 ann_date, 让下游可以做点-in-time 对齐(不用报告期)。

用法:
  python download_events.py 1000 --what holder_trade
  python download_events.py 1000 --what float
  python download_events.py 1000 --what forecast
  python download_events.py 1000 --what express
  python download_events.py 1000 --what all
"""
import argparse
import os
import sys
import time

import pandas as pd

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

import tushare_common as tc

UNIVERSES = {"500": "cache_zz500", "1000": "cache_zz1000"}
START = "20150101"

# 每类: (输出文件, 拉取函数名, 需要保留的列)
KINDS = {
    "holder_trade": ("_holder_trade.csv", "stk_holdertrade",
                     ["ts_code", "ann_date", "holder_name", "holder_type", "in_de",
                      "change_vol", "change_ratio", "after_share", "avg_price"]),
    "float": ("_share_float.csv", "share_float",
              ["ts_code", "ann_date", "float_date", "float_share", "float_ratio",
               "holder_name", "share_type"]),
    "forecast": ("_forecast.csv", "forecast",
                 ["ts_code", "ann_date", "end_date", "type", "p_change_min", "p_change_max",
                  "net_profit_min", "net_profit_max", "last_parent_net"]),
    "express": ("_express.csv", "express",
                ["ts_code", "ann_date", "end_date", "revenue", "operate_profit",
                 "total_profit", "n_income", "yoy_net_profit"]),
}


def trade_days(pro, end="today"):
    end = pd.Timestamp.today().normalize().strftime("%Y%m%d") if end == "today" else end
    cal = pro.trade_cal(exchange="SSE", start_date=START, end_date=end, is_open="1")
    return sorted(cal["cal_date"].astype(str).tolist())


def all_days(pro):
    """所有自然日(事件按公告日披露, 非交易日也会有公告)。"""
    cal = pro.trade_cal(exchange="SSE", start_date=START,
                        end_date=pd.Timestamp.today().normalize().strftime("%Y%m%d"),
                        is_open="1")
    d0 = pd.Timestamp(START)
    d1 = pd.Timestamp(cal["cal_date"].max())
    return [d.strftime("%Y%m%d") for d in pd.date_range(d0, d1, freq="D")]


def month_ranges():
    """自然月区间: 适合支持 start_date/end_date 的接口(一次调用覆盖一个月)。"""
    d0 = pd.Timestamp(START)
    d1 = pd.Timestamp.today().normalize()
    out = []
    for p in pd.period_range(d0, d1, freq="M"):
        s = max(p.start_time, d0).strftime("%Y%m%d")
        e = min(p.end_time, d1).strftime("%Y%m%d")
        out.append((s, e))
    return out


def download_kind(pro, cache_dir, universe, kind, verbose=True):
    fname, api, cols = KINDS[kind]
    path = os.path.join(cache_dir, fname)
    fn = getattr(pro, api)
    # forecast 只支持 ann_date(逐日); 其余支持日期范围(逐月, 快 30 倍)
    by_month = kind != "forecast"

    done_max = None
    if os.path.exists(path):
        try:
            old = pd.read_csv(path, usecols=["ann_date"], dtype={"ann_date": str})
            if len(old):
                done_max = str(old["ann_date"].max())
        except Exception:
            pass

    if by_month:
        segs = [(s, e) for s, e in month_ranges() if done_max is None or e > done_max]
        label = "个月"
    else:
        segs = [(d, d) for d in all_days(pro) if done_max is None or d > done_max]
        label = "天"
    print(f"\n[{kind}] {api}: 待拉取 {len(segs)} {label} (已有到 {done_max})", flush=True)
    if not segs:
        print(f"  已是最新", flush=True)
        return 0

    buf, ok, fail, total = [], 0, 0, 0
    t0 = time.time()
    for i, (s, e) in enumerate(segs):
        try:
            if by_month:
                df = tc._retry(lambda: fn(start_date=s, end_date=e))
            else:
                df = tc._retry(lambda: fn(ann_date=s))
            if df is not None and len(df):
                df = df.copy()
                df["code"] = df["ts_code"].map(tc.to_code)
                df = df[df["code"].isin(universe)]
                # 增量时只保留缓存末日之后的部分
                if done_max is not None:
                    df = df[df["ann_date"].astype(str) > done_max]
                if len(df):
                    keep = ["code"] + [c for c in cols if c in df.columns]
                    buf.append(df[keep])
                    total += len(df)
                ok += 1
        except Exception as ex:  # noqa: BLE001
            fail += 1
            if fail <= 3:
                print(f"  {s}~{e} 失败: {str(ex)[:60]}", flush=True)
        if (i + 1) % 50 == 0:
            el = time.time() - t0
            print(f"  进度 {i + 1}/{len(segs)}  有数据 {ok} 失败 {fail} 累计 {total} 行  "
                  f"用时 {el:.0f}s", flush=True)
        tc.sleep(0.3)

    if buf:
        new = pd.concat(buf, ignore_index=True)
        if os.path.exists(path):
            old = pd.read_csv(path, dtype={"code": str})
            new = pd.concat([old, new], ignore_index=True)
        new = new.drop_duplicates().sort_values(["ann_date", "code"])
        new.to_csv(path, index=False, encoding="utf-8-sig")
        print(f"  保存 {path}: {len(new)} 行, {new['code'].nunique()} 只", flush=True)
    print(f"  [{kind}] 完成: 有数据 {ok} 段, 失败 {fail} 段, 总耗时 {time.time() - t0:.0f}s",
          flush=True)
    return total


def download_toplist(pro, cache_dir, universe):
    """龙虎榜: top_list(个股上榜明细) + top_inst(机构席位)。

    关键注意: 龙虎榜是**盘后披露**, 所以用 trade_date 拉取时, 该数据在
    trade_date 当天收盘后才可得 —— 下游做点-in-time 必须对齐到 t+1,
    否则前视(会用到当天还不知道的席位信息)。
    """
    for fname, api, cols, label in [
        ("_top_list.csv", "top_list",
         ["ts_code", "trade_date", "close", "pct_change", "turnover_rate",
          "amount", "l_sell", "l_buy", "l_amount", "net_amount", "net_rate", "reason"],
         "龙虎榜个股"),
        ("_top_inst.csv", "top_inst",
         ["ts_code", "trade_date", "exalter", "buy", "buy_rate", "sell",
          "sell_rate", "net_buy"],
         "龙虎榜机构"),
    ]:
        path = os.path.join(cache_dir, fname)
        fn = getattr(pro, api)
        done_max = None
        if os.path.exists(path):
            try:
                old = pd.read_csv(path, usecols=["trade_date"], dtype={"trade_date": str})
                if len(old):
                    done_max = str(old["trade_date"].max())
            except Exception:
                pass
        days = [d for d in trade_days(pro) if done_max is None or d > done_max]
        print(f"\n[{label}] {api}: 待拉取 {len(days)} 个交易日", flush=True)
        if not days:
            print("  已是最新", flush=True)
            continue
        buf, ok, fail, total = [], 0, 0, 0
        t0 = time.time()
        for i, d in enumerate(days):
            try:
                df = tc._retry(lambda: fn(trade_date=d))
                if df is not None and len(df):
                    df = df.copy()
                    if "ts_code" in df.columns:
                        df["code"] = df["ts_code"].map(tc.to_code)
                    df["trade_date"] = d
                    if "code" in df.columns:
                        sub = df[df["code"].isin(universe)]
                    else:      # top_inst 用 ts_code
                        sub = df[df["ts_code"].astype(str).str[:6].isin(universe)].copy()
                        sub["code"] = sub["ts_code"].str[:6]
                    if len(sub):
                        keep = ["code"] + [c for c in cols if c in sub.columns]
                        keep = list(dict.fromkeys(keep + ["trade_date"]))
                        buf.append(sub[keep])
                        total += len(sub)
                    ok += 1
            except Exception as e:  # noqa: BLE001
                fail += 1
                if fail <= 3:
                    print(f"  {d} 失败: {str(e)[:50]}", flush=True)
            if (i + 1) % 300 == 0:
                el = time.time() - t0
                print(f"  进度 {i + 1}/{len(days)}  有数据 {ok} 失败 {fail} 累计 {total} 行  "
                      f"用时 {el:.0f}s", flush=True)
            tc.sleep(0.28)
        if buf:
            new = pd.concat(buf, ignore_index=True)
            if os.path.exists(path):
                old = pd.read_csv(path, dtype={"code": str})
                new = pd.concat([old, new], ignore_index=True)
            new = new.drop_duplicates().sort_values(["trade_date", "code"])
            new.to_csv(path, index=False, encoding="utf-8-sig")
            print(f"  保存 {path}: {len(new)} 行, {new['code'].nunique()} 只", flush=True)
        print(f"  [{label}] 完成: 有数据 {ok} 天, 失败 {fail} 天, "
              f"耗时 {time.time() - t0:.0f}s", flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("universe", nargs="?", default="1000", choices=["500", "1000"])
    ap.add_argument("--what", default="all",
                    choices=list(KINDS.keys()) + ["toplist", "all"])
    args = ap.parse_args()

    cache_dir = UNIVERSES[args.universe]
    cons = pd.read_csv(os.path.join(cache_dir, "_constituents.csv"), dtype={"code": str})
    universe = set(cons["code"].unique())
    print(f"{cache_dir}: 成分股并集 {len(universe)} 只", flush=True)
    pro = tc.get_pro()

    if args.what in ("toplist", "all"):
        download_toplist(pro, cache_dir, universe)
    if args.what == "toplist":
        return
    kinds = list(KINDS.keys()) if args.what == "all" else [args.what]
    for k in kinds:
        download_kind(pro, cache_dir, universe, k)


if __name__ == "__main__":
    main()
