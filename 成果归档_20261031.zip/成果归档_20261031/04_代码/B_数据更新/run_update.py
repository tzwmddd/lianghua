"""一键更新: 下载最新数据 -> 生成推荐榜单。

这是把整个流程封装成一个可重复运行的工具, 依次做四件事:
  1. 体检: 检查各数据源与最新交易日的差距
  2. 更新行情: 个股日线+指数(update_data.py) + 每日指标(update_daily_basic.py)
  3. 更新因子: 股东户数/资金流/成交额/业绩预告/增减持/解禁
  4. 生成推荐: 按市场最优配置跑模型, 输出建议持仓与权重

设计要点:
  - 每一步都有失败容忍: 单个数据源失败不中断整体流程, 最后统一报告
  - 幂等: 可反复运行, 已最新的部分会跳过
  - 相对路径: 用脚本所在目录, 可从任意位置调用

用法:
  python run_update.py 500              # 更新中证500 并出榜单
  python run_update.py 1000             # 中证1000
  python run_update.py both             # 两个市场都做
  python run_update.py 500 --check      # 只看数据差距, 不下载
  python run_update.py 500 --skip-factors   # 跳过因子更新(只更新行情)
"""
import argparse
import os
import subprocess
import sys
import time

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

BASE = os.path.dirname(os.path.abspath(__file__))
PY = sys.executable or "python"

# 各市场对应的更新命令清单: (说明, 命令参数)
# 注意: 顺序有意义 —— 先行情(日线/指数)再因子, 因子里的资金流/成交额依赖交易日历
STEPS_COMMON = [
    ("行情: 个股日线 + 指数", lambda u: [PY, "update_data.py", u]),
    ("行情: 每日指标(市值/PE/PB/换手率)", lambda u: [PY, "update_daily_basic.py", u]),
    ("因子: 股东户数", lambda u: [PY, "download_holders.py", u]),
    ("因子: 资金流", lambda u: [PY, "download_moneyflow.py", u]),
    ("因子: 成交额", lambda u: [PY, "download_amount.py", u]),
    ("因子: 业绩预告", lambda u: [PY, "download_events.py", u, "--what", "forecast"]),
    ("因子: 增减持", lambda u: [PY, "download_events.py", u, "--what", "holder_trade"]),
    ("因子: 解禁", lambda u: [PY, "download_events.py", u, "--what", "float"]),
]


def run_step(label, cmd, log_path=None):
    """运行一步, 实时回显; 返回 (是否成功, 耗时)。"""
    print(f"\n{'='*68}\n[{label}]\n{'='*68}", flush=True)
    t0 = time.time()
    try:
        r = subprocess.run(cmd, cwd=BASE, timeout=None)
        ok = (r.returncode == 0)
    except KeyboardInterrupt:
        print("\n[中断] 用户终止", flush=True)
        raise
    except Exception as e:  # noqa: BLE001
        print(f"[失败] {type(e).__name__}: {str(e)[:120]}", flush=True)
        ok = False
    el = time.time() - t0
    print(f"[{'完成' if ok else '失败'}] {label}  ({el:.0f}s)", flush=True)
    return ok, el


def check_only(universe):
    print(f"\n=== 数据差距体检: 中证{universe} ===", flush=True)
    for label, cmd_fn in STEPS_COMMON[:2]:
        run_step(label + " (仅检查)", cmd_fn(universe) + ["--check"])


def update_market(universe, skip_factors=False):
    results = []
    steps = STEPS_COMMON[:2] if skip_factors else STEPS_COMMON
    for label, cmd_fn in steps:
        ok, el = run_step(label, cmd_fn(universe))
        results.append((label, ok, el))
    return results


def make_recommend(universe):
    return run_step(f"生成中证{universe} 推荐榜单", [PY, "recommend_zz.py", universe])


def show_result(universe):
    """读取并展示推荐结果摘要。"""
    import pandas as pd
    path = os.path.join(BASE, "results", f"recommend_zz{universe}.csv")
    if not os.path.exists(path):
        print(f"[警告] 未找到 {path}", flush=True)
        return
    d = pd.read_csv(path, dtype={"code": str})
    q5 = d[d["group"] == "Q5_buy"].sort_values("prob", ascending=False)
    keep = int(q5["in_buffer_keep"].sum()) if "in_buffer_keep" in q5.columns else 0
    print(f"\n{'#'*68}", flush=True)
    print(f"#  中证{universe} 建议持仓  ({d['date'].iloc[0]} 截面, 共 {len(q5)} 只)", flush=True)
    print(f"#  其中缓冲保留 {keep} 只, 新买入 {len(q5)-keep} 只", flush=True)
    print(f"#  权重 {q5['weight'].min():.2%} ~ {q5['weight'].max():.2%}, "
          f"概率 {q5['prob'].min():.1%} ~ {q5['prob'].max():.1%}", flush=True)
    print(f"{'#'*68}", flush=True)
    print(f"{'代码':<8}{'名称':<12}{'收盘价':>9}{'换手率%':>8}{'跑赢概率':>9}{'建议权重':>9}{'来源':>6}")
    for _, r in q5.head(20).iterrows():
        src = "保留" if r.get("in_buffer_keep") else "新买"
        print(f"{r['code']:<8}{str(r['name'])[:10]:<12}{r['close']:>9.2f}"
              f"{r['turnover']:>8.2f}{r['prob']:>9.1%}{r['weight']:>9.2%}{src:>6}")
    print(f"  ... 完整清单: {path}", flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("market", nargs="?", default="500",
                    choices=["500", "1000", "both"])
    ap.add_argument("--check", action="store_true", help="只体检, 不下载")
    ap.add_argument("--skip-factors", action="store_true", help="只更新行情, 跳过因子")
    ap.add_argument("--no-recommend", action="store_true", help="不生成推荐")
    args = ap.parse_args()

    markets = ["500", "1000"] if args.market == "both" else [args.market]
    t_all = time.time()

    if args.check:
        for u in markets:
            check_only(u)
        print(f"\n[体检完成] 总耗时 {time.time() - t_all:.0f}s", flush=True)
        return

    all_results = {}
    for u in markets:
        print(f"\n\n{'#'*68}\n#  处理中证{u}\n{'#'*68}", flush=True)
        all_results[u] = update_market(u, skip_factors=args.skip_factors)

    if not args.no_recommend:
        for u in markets:
            make_recommend(u)
            show_result(u)

    # ---- 汇总 ----
    print(f"\n\n{'='*68}\n数据更新汇总\n{'='*68}", flush=True)
    for u, res in all_results.items():
        ok_n = sum(1 for _, ok, _ in res if ok)
        print(f"\n中证{u}: {ok_n}/{len(res)} 步成功", flush=True)
        for label, ok, el in res:
            print(f"  [{'OK' if ok else '失败'}] {label}  ({el:.0f}s)", flush=True)
    print(f"\n总耗时 {time.time() - t_all:.0f}s", flush=True)
    print(f"结果目录: {os.path.join(BASE, 'results')}", flush=True)


if __name__ == "__main__":
    main()
