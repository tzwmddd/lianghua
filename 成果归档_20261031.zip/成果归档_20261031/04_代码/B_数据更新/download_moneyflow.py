"""下载个股资金流(moneyflow), 按交易日拉取全市场后再筛成分股。

为什么按交易日拉: 单日全市场约 5000 行/次调用, 而按股票拉是 1 只/次 —— 快 30 倍以上。
中证1000 只保留成分股(并集 2800 只), 大幅压缩存储。

moneyflow 字段(tushare 官方, 单位: 手/万元):
  buy_sm/md/lg/elg_vol,amount : 小/中/大/特大单 买入量、买入额
  sell_* 同理; net_mf_amount  : 净流入额
  惯用构造: 主力 = 大单 + 特大单, 主力净流入 = (buy_lg+buy_elg) - (sell_lg+sell_elg)

用法:
  python download_moneyflow.py 1000                 # 从 2015 拉到最新
  python download_moneyflow.py 1000 --start 20200101
  python download_moneyflow.py 1000 --check
"""
import argparse
import os
import sys
import time

import numpy as np
import pandas as pd

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

import tushare_common as tc

UNIVERSES = {"500": "cache_zz500", "1000": "cache_zz1000"}
KEEP = ["buy_lg_amount", "sell_lg_amount", "buy_elg_amount", "sell_elg_amount",
        "buy_md_amount", "sell_md_amount", "buy_sm_amount", "sell_sm_amount",
        "net_mf_amount"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("universe", nargs="?", default="1000", choices=["500", "1000"])
    ap.add_argument("--start", default="20150101")
    ap.add_argument("--check", action="store_true")
    args = ap.parse_args()

    cache_dir = UNIVERSES[args.universe]
    path = os.path.join(cache_dir, "_moneyflow.csv")
    cons = pd.read_csv(os.path.join(cache_dir, "_constituents.csv"), dtype={"code": str})
    universe = set(cons["code"].unique())
    print(f"成分股并集 {len(universe)} 只", flush=True)

    # 交易日历
    pro = tc.get_pro()
    today = pd.Timestamp.today().normalize().strftime("%Y%m%d")
    cal = pro.trade_cal(exchange="SSE", start_date=args.start, end_date=today,
                        is_open="1")
    days = sorted(cal["cal_date"].astype(str).tolist())
    print(f"交易日 {len(days)} 天 ({days[0]} ~ {days[-1]})", flush=True)

    done = set()
    if os.path.exists(path):
        old_dates = pd.read_csv(path, usecols=["date"])["date"].unique()
        done = set(pd.to_datetime(old_dates).strftime("%Y%m%d"))
    # 增量起点: 从缓存最新日之后开始 —— 否则未来的交易日会全部被当成"待下载",
    # 而它们本来就没有数据(刚才就出现过"65 天全部失败"的误报)
    if done:
        todo = [d for d in days if d > max(done)]
    else:
        todo = days
    print(f"已有 {len(done)} 天, 待下载 {len(todo)} 天", flush=True)
    if args.check:
        print("(--check) 未下载任何数据", flush=True)
        return
    if not todo:
        print("已是最新, 无需下载", flush=True)
        return

    t0 = time.time()
    buf, n_ok, n_fail, total_rows = [], 0, 0, 0
    for i, d in enumerate(todo):
        try:
            df = tc._retry(lambda: pro.moneyflow(trade_date=d))
            if df is None or df.empty:
                n_fail += 1
            else:
                df = df.copy()
                df["code"] = df["ts_code"].map(tc.to_code)
                df = df[df["code"].isin(universe)]
                if len(df):
                    keep = ["code"] + [c for c in KEEP if c in df.columns]
                    df = df[keep]
                    df["date"] = pd.to_datetime(d)
                    buf.append(df)
                    total_rows += len(df)
                n_ok += 1
        except Exception as e:  # noqa: BLE001
            n_fail += 1
            if n_fail <= 3:
                print(f"  {d} 失败: {str(e)[:60]}", flush=True)
        if (i + 1) % 100 == 0:
            el = time.time() - t0
            print(f"  进度 {i + 1}/{len(todo)}  成功 {n_ok} 失败 {n_fail} "
                  f"累计 {total_rows} 行  用时 {el:.0f}s  "
                  f"预计剩余 {el / (i + 1) * (len(todo) - i - 1):.0f}s", flush=True)
        tc.sleep(0.3)

    if buf:
        new = pd.concat(buf, ignore_index=True)
        if os.path.exists(path):
            old = pd.read_csv(path, parse_dates=["date"], dtype={"code": str})
            new = pd.concat([old, new], ignore_index=True)
        new = new.drop_duplicates(subset=["code", "date"]).sort_values(["code", "date"])
        new.to_csv(path, index=False, encoding="utf-8-sig")
        print(f"\n保存 {path}: {len(new)} 行, {new['code'].nunique()} 只, "
              f"{new['date'].nunique()} 个交易日", flush=True)
    print(f"成功 {n_ok} 天, 失败 {n_fail} 天, 总耗时 {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
