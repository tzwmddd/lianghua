"""下载日线成交额(amount), 用于资金流因子的归一化。

moneyflow 的金额单位是万元, 必须除以成交额才能变成"比率", 否则净流入额
基本就是 size 的别名(与项目已验证的"换手率是 size 别名"同理)。

tushare daily 接口自带 amount(千元), 按 trade_date 全市场拉一次即可。

用法: python download_amount.py 1000
"""
import argparse
import os
import sys
import time

import pandas as pd

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

import tushare_common as tc

UNIVERSES = {"500": "cache_zz500", "1000": "cache_zz1000"}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("universe", nargs="?", default="1000", choices=["500", "1000"])
    ap.add_argument("--start", default="20150101")
    ap.add_argument("--check", action="store_true")
    args = ap.parse_args()

    cache_dir = UNIVERSES[args.universe]
    path = os.path.join(cache_dir, "_amount.csv")
    cons = pd.read_csv(os.path.join(cache_dir, "_constituents.csv"), dtype={"code": str})
    universe = set(cons["code"].unique())

    pro = tc.get_pro()
    # 交易日历只查到"今天"为止: 否则未来交易日会被当成待下载, 反复报"无数据"
    today = pd.Timestamp.today().normalize().strftime("%Y%m%d")
    cal = pro.trade_cal(exchange="SSE", start_date=args.start, end_date=today, is_open="1")
    days = sorted(cal["cal_date"].astype(str).tolist())

    done = set()
    if os.path.exists(path):
        _d = pd.read_csv(path, usecols=["date"])["date"]
        done = set(pd.to_datetime(_d).dt.strftime("%Y%m%d"))
    # 增量起点: 从缓存最新日之后开始(而不是逐日对比交易日历,
    # 否则未来的交易日会全部被当成"待下载")
    if done:
        todo = [d for d in days if d > max(done)]
    else:
        todo = days
    print(f"{cache_dir}: 交易日 {len(days)}, 已有 {len(done)} 天, 待下载 {len(todo)} 天", flush=True)
    if args.check:
        return
    if not todo:
        print("已是最新, 无需下载", flush=True)
        return

    t0 = time.time()
    buf, total = [], 0
    for i, d in enumerate(todo):
        try:
            df = tc._retry(lambda: pro.daily(trade_date=d))
            if df is not None and not df.empty:
                df = df.copy()
                df["code"] = df["ts_code"].map(tc.to_code)
                df = df[df["code"].isin(universe)]
                if len(df):
                    df = df[["code", "amount"]].copy()
                    df["date"] = pd.to_datetime(d)
                    buf.append(df)
                    total += len(df)
        except Exception as e:  # noqa: BLE001
            print(f"  {d} 失败: {str(e)[:50]}", flush=True)
        if (i + 1) % 200 == 0:
            el = time.time() - t0
            print(f"  进度 {i + 1}/{len(todo)}  累计 {total} 行  用时 {el:.0f}s  "
                  f"预计剩余 {el / (i + 1) * (len(todo) - i - 1):.0f}s", flush=True)
        tc.sleep(0.28)

    if buf:
        new = pd.concat(buf, ignore_index=True)
        if os.path.exists(path):
            old = pd.read_csv(path, parse_dates=["date"], dtype={"code": str})
            new = pd.concat([old, new], ignore_index=True)
        new = new.drop_duplicates(subset=["code", "date"]).sort_values(["code", "date"])
        new.to_csv(path, index=False, encoding="utf-8-sig")
        print(f"\n保存 {path}: {len(new)} 行, {new['code'].nunique()} 只", flush=True)
    print(f"总耗时 {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
