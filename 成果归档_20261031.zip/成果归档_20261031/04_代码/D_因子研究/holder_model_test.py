"""股东户数因子接入模型的增量测试。

单因子 IC 只有 -0.03, 但:
  - 与现有技术面因子最大相关仅 0.135(真正正交)
  - 分层单调(Q5-Q1 = -0.80%, 户数增加组明显跑输)
所以值得测"接入模型后净收益是否提升"——这是唯一的标准。

用已找到的最优交易参数(H=30, 缓冲50%, 概率加权), 只变特征集, 保证可比。

用法: python holder_model_test.py [1000]
"""
import os
import sys
import time

import numpy as np
import pandas as pd
import lightgbm as lgb

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

from config import SEED, EMBARGO_DAYS, RESULTS_DIR
from zz_pool import BASE_FEATURES
from _tune_model import get_pool, rebal_calendar
from holder_factor_test import build_holder_factors, FACTORS
from q_frac_test import metrics, run_combined

UNIVERSES = {"500": ("cache_zz500", 0.004), "1000": ("cache_zz1000", 0.005)}
LIQUIDITY_DROP = 0.2
MIN_TRAIN = 5000
H = 30
TOP_FRAC = 0.15
BUFFER = 0.5


def run(pool, features, cost):
    """与 q_frac_test.run_combined 同口径, 但特征集可变。"""
    dates = sorted(pool["date"].unique())
    start = next(i for i, d in enumerate(dates) if d >= pd.Timestamp("2017-01-01"))
    rebal = dates[start::H]

    rec = []
    prev_hold = set()
    for t in rebal:
        cutoff = t - pd.Timedelta(days=EMBARGO_DAYS)
        train = pool[(pool["date"] < cutoff) & pool["target_rel"].notna()].dropna(subset=features)
        if len(train) < MIN_TRAIN:
            continue
        cross = pool[(pool["date"] == t) & pool["stock_fwd"].notna()].dropna(subset=features)
        if len(cross) < 30:
            continue
        model = lgb.LGBMClassifier(
            n_estimators=150, learning_rate=0.10, num_leaves=63,
            subsample=0.8, colsample_bytree=0.8,
            random_state=SEED, verbosity=-1, n_jobs=-1)
        model.fit(train[features].to_numpy(), train["target_rel"].to_numpy())
        cross = cross.copy()
        cross["prob"] = model.predict_proba(cross[features].to_numpy())[:, 1]
        if cross["turnover"].notna().sum() > 10:
            th = cross["turnover"].quantile(LIQUIDITY_DROP)
            cross = cross[cross["turnover"] >= th]
        n_liq = len(cross)
        k = max(1, int(n_liq * TOP_FRAC))
        buf_k = max(k, int(n_liq * BUFFER))
        cross = cross.sort_values("prob", ascending=False)
        buf_codes = set(cross.head(buf_k)["code"])
        buyable = cross[cross["tradable_buy"].astype(bool)]
        keep = [c for c in prev_hold if c in buf_codes]
        final = keep[:k]
        for c in buyable["code"]:
            if len(final) >= k:
                break
            if c not in final:
                final.append(c)
        if not final:
            continue
        hold = set(final)
        turn = len(hold - prev_hold) / len(hold) if prev_hold else 1.0
        prev_hold = hold
        q = cross[cross["code"].isin(hold)].copy()
        p = q["prob"].to_numpy(dtype=float)
        if len(p) > 1 and p.max() > p.min():
            w = 0.5 + (p - p.min()) / (p.max() - p.min())
            w = w / w.sum()
        else:
            w = np.full(len(q), 1.0 / len(q))
        rec.append({"date": t, "hold": sorted(hold), "turn": turn, "w": w.tolist(),
                    "n": len(q),
                    "gross": float(np.dot(w, q["stock_fwd"].to_numpy())),
                    "excess": float(np.dot(w, q["excess_fwd"].to_numpy()))})
    return rec


def main():
    u = sys.argv[1] if len(sys.argv) > 1 else "1000"
    cache_dir, cost = UNIVERSES[u]
    t0 = time.time()
    pool, _, _ = get_pool(u, horizon=H)
    pool = build_holder_factors(cache_dir, pool)
    # 中性化新因子
    from cross_section import neutralize
    have = [f for f in FACTORS if pool[f].notna().mean() > 0.5]
    pool = neutralize(pool, have)
    print(f"pool {len(pool)} 条, 可用新因子 {have}", flush=True)

    configs = [
        ("基准(无股东户数)", BASE_FEATURES),
        ("+hl_chg_4q", BASE_FEATURES + ["hl_chg_4q"]),
        ("+hl_chg_q+hl_speed", BASE_FEATURES + ["hl_chg_q", "hl_speed"]),
        ("+全部4个股东因子", BASE_FEATURES + have),
    ]
    header = (f"{'特征集':<22}{'持仓':>6}{'换手':>7}{'净收益/期':>10}{'年化绝对':>9}"
              f"{'最大回撤':>9}{'日频夏普':>9}{'年化超额':>9}")
    print("\n" + header, flush=True)
    print("-" * len(header), flush=True)
    rows = []
    for name, feats in configs:
        t1 = time.time()
        rec = run(pool, feats, cost)
        m = metrics(rec, cache_dir, cost)
        row = (f"{name:<22}{m['hold']:>6.0f}{m['turn']:>7.1%}{m['net']:>+10.3%}"
               f"{m['ann']:>+9.2%}{m['dd']:>9.2%}{m['sharpe']:>9.3f}{m['ann_ex']:>+9.2%}")
        print(row + f"  ({time.time() - t1:.0f}s)", flush=True)
        rows.append((name, m))

    path = os.path.join(RESULTS_DIR, f"holder_model_zz{u}_report.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"中证{u} 股东户数因子接入模型增量测试\n")
        f.write(f"最优交易参数: top{TOP_FRAC:.0%} / 缓冲{BUFFER:.0%} / 概率加权 / H={H}\n\n")
        f.write(header + "\n" + "-" * len(header) + "\n")
        for name, m in rows:
            f.write(f"{name:<22}{m['hold']:>6.0f}{m['turn']:>7.1%}{m['net']:>+10.3%}"
                    f"{m['ann']:>+9.2%}{m['dd']:>9.2%}{m['sharpe']:>9.3f}{m['ann_ex']:>+9.2%}\n")
        base = rows[0][1]
        for name, m in rows[1:]:
            f.write(f"\n{name} 相对基准: 年化绝对 {m['ann'] - base['ann']:+.2%}, "
                    f"年化超额 {m['ann_ex'] - base['ann_ex']:+.2%}, "
                    f"夏普 {m['sharpe'] - base['sharpe']:+.3f}\n")
    print(f"\n报告已保存: {path}", flush=True)
    base = rows[0][1]
    for name, m in rows[1:]:
        print(f"  {name}: 年化绝对 {m['ann'] - base['ann']:+.2%}, "
              f"年化超额 {m['ann_ex'] - base['ann_ex']:+.2%}", flush=True)
    print(f"总耗时 {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
