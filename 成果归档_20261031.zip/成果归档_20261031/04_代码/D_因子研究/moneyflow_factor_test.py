"""资金流因子: 构建 + 单因子 IC + 正交性 + 接入模型的净收益增量。

因子构造(全部用点-in-time 数据, 并用成交额归一化以剥离 size):
  mf_main_ratio_20 : 主力净流入(大单+特大单) / 成交额, 20 日均值
  mf_main_ratio_5  : 同上, 5 日均值(更敏感)
  mf_small_ratio_20: 小单净流入 / 成交额, 20 日均值(散户行为)
  mf_divergence    : 主力 - 小单 的净流入比率差(主力买、散户卖 = 强信号)
  mf_trend         : 主力净流入比率的 5 日均值 - 20 日均值(资金流加速度)

关键: 不做归一化的净流入额几乎是 size 别名(与"换手率是 size 别名"同理),
所以这里一律用 成交额 归一化。

用法: python moneyflow_factor_test.py [1000]
"""
import os
import sys
import time

import numpy as np
import pandas as pd

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

from config import RESULTS_DIR
from zz_pool import BASE_FEATURES
from _tune_model import get_pool
from cross_section import neutralize
from holder_factor_test import ic_stats, quintile_returns

FACTORS = ["mf_main_ratio_20", "mf_main_ratio_5", "mf_small_ratio_20",
           "mf_divergence", "mf_trend"]


def build_moneyflow_factors(cache_dir, pool):
    mf_path = os.path.join(cache_dir, "_moneyflow.csv")
    amt_path = os.path.join(cache_dir, "_amount.csv")
    if not (os.path.exists(mf_path) and os.path.exists(amt_path)):
        raise FileNotFoundError("缺少 _moneyflow.csv 或 _amount.csv, 请先运行下载脚本")

    mf = pd.read_csv(mf_path, parse_dates=["date"], dtype={"code": str})
    amt = pd.read_csv(amt_path, parse_dates=["date"], dtype={"code": str})
    print(f"资金流 {len(mf)} 行, 成交额 {len(amt)} 行", flush=True)

    df = mf.merge(amt, on=["code", "date"], how="inner")
    # moneyflow 金额单位万元; daily.amount 单位千元 -> 统一成万元
    df["amount_w"] = df["amount"] / 10.0
    df = df[df["amount_w"] > 0]
    df["main_net"] = (df["buy_lg_amount"] + df["buy_elg_amount"]
                      - df["sell_lg_amount"] - df["sell_elg_amount"])
    df["small_net"] = df["buy_sm_amount"] - df["sell_sm_amount"]
    df["main_ratio"] = df["main_net"] / df["amount_w"]
    df["small_ratio"] = df["small_net"] / df["amount_w"]
    df = df.sort_values(["code", "date"])

    g = df.groupby("code")
    df["mf_main_ratio_20"] = g["main_ratio"].transform(lambda s: s.rolling(20, min_periods=10).mean())
    df["mf_main_ratio_5"] = g["main_ratio"].transform(lambda s: s.rolling(5, min_periods=3).mean())
    df["mf_small_ratio_20"] = g["small_ratio"].transform(lambda s: s.rolling(20, min_periods=10).mean())
    df["mf_divergence"] = df["mf_main_ratio_20"] - df["mf_small_ratio_20"]
    df["mf_trend"] = df["mf_main_ratio_5"] - df["mf_main_ratio_20"]

    cols = ["code", "date"] + FACTORS
    df = df[cols]
    return pool.merge(df, on=["code", "date"], how="left")


def main():
    u = sys.argv[1] if len(sys.argv) > 1 else "1000"
    cache_dir = {"500": "cache_zz500", "1000": "cache_zz1000"}[u]
    t0 = time.time()
    pool, _, _ = get_pool(u, horizon=30)
    p = build_moneyflow_factors(cache_dir, pool)
    print(f"合并后 {len(p)} 条", flush=True)

    print(f"\n因子覆盖率:", flush=True)
    for f in FACTORS:
        print(f"  {f:<20} {p[f].notna().mean():6.2%}  均值 {p[f].mean():+.5f}  "
              f"标准差 {p[f].std():.5f}", flush=True)

    print(f"\n=== 单因子 Rank IC (中性化后, 每30交易日口径) ===", flush=True)
    pn = p.dropna(subset=FACTORS).copy()
    pn = neutralize(pn, FACTORS)
    header = f"{'因子':<20}{'IC':>10}{'ICIR':>9}{'IC>0':>8}{'Q1':>9}{'Q5':>9}{'Q5-Q1':>10}"
    print(header, flush=True)
    print("-" * len(header), flush=True)
    rows = []
    for f in FACTORS:
        ic, icir, n, pos = ic_stats(pn, f)
        means, spread = quintile_returns(pn, f)
        print(f"{f:<20}{ic:>+10.4f}{icir:>+9.3f}{pos:>8.1%}"
              + "".join(f"{m:>+9.2%}" for m in [means[0], means[-1]]) + f"{spread:>+10.2%}",
              flush=True)
        rows.append((f, ic, icir, pos, spread))

    print(f"\n=== 与现有技术面因子的最大相关性(中性化后) ===", flush=True)
    keep = [c for c in BASE_FEATURES if c in pn.columns]
    x = pn[FACTORS + keep].dropna()
    if len(x) > 100:
        corr = x.corr(method="spearman")
        for f in FACTORS:
            sub = corr.loc[f, keep].drop(f, errors="ignore")
            top = sub.abs().sort_values(ascending=False).head(3)
            print(f"  {f:<20} " + ", ".join(f"{k}={sub[k]:+.3f}" for k in top.index), flush=True)

    path = os.path.join(RESULTS_DIR, f"moneyflow_factor_zz{u}_report.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"中证{u} 资金流因子测试\n\n")
        f.write(header + "\n")
        for r in rows:
            f.write(f"{r[0]:<20}{r[1]:>+10.4f}{r[2]:>+9.3f}{r[3]:>8.1%}{r[4]:>+10.2%}\n")
    print(f"\n报告已保存: {path}", flush=True)
    print(f"总耗时 {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
