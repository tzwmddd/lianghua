"""tushare 数据维度探测: 找出 2000 积分档还能拉到哪些可用于 alpha 的数据。

重点探测"可能与现有技术面正交"的维度(资金流/股东/龙虎榜/解禁/预告),
因为项目已验证: 财务/估值/size/换手率/两融在中证1000 上增量有限。

用法: python probe_tushare_dims.py
"""
import os
import sys
import time

import pandas as pd

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

import tushare_common as tc

pro = tc.get_pro()
SAMPLE = "000006.SZ"      # 中证1000 成分股样本
START, END = "20240101", "20240131"


def probe(name, fn, note=""):
    t0 = time.time()
    try:
        df = fn()
        n = 0 if df is None else len(df)
        cols = list(df.columns)[:8] if df is not None and n else []
        print(f"[OK]   {name}: {n} 行 ({time.time() - t0:.1f}s) {note}")
        if cols:
            print(f"         列: {cols}")
        return df
    except Exception as e:  # noqa: BLE001
        msg = str(e)[:110]
        print(f"[FAIL] {name}: {msg}")
        return None


print("=== 1. 资金流类 ===")
probe("moneyflow 个股", lambda: pro.moneyflow(ts_code=SAMPLE, start_date=START, end_date=END))
probe("moneyflow 单日全市场", lambda: pro.moneyflow(trade_date="20240102"))
probe("moneyflow_dc 东财个股",
      lambda: pro.moneyflow_dc(ts_code=SAMPLE, start_date=START, end_date=END))
probe("moneyflow_dc 单日全市场", lambda: pro.moneyflow_dc(trade_date="20240102"))
probe("moneyflow_hsgt 沪深港通资金", lambda: pro.moneyflow_hsgt(start_date=START, end_date=END))
probe("hsgt_top10 十大成交股",
      lambda: pro.hsgt_top10(trade_date="20240102", market_type="1"))

print("\n=== 2. 股东/筹码类 ===")
probe("stk_holdernumber 股东户数",
      lambda: pro.stk_holdernumber(ts_code=SAMPLE, start_date="20220101", end_date="20241231"))
probe("stk_holdertrade 增减持",
      lambda: pro.stk_holdertrade(ts_code=SAMPLE, start_date="20230101", end_date="20241231"))
probe("top10_holders 十大股东",
      lambda: pro.top10_holders(ts_code=SAMPLE, period="20231231"))
probe("top10_floatholders 十大流通股东",
      lambda: pro.top10_floatholders(ts_code=SAMPLE, period="20231231"))
probe("share_float 限售解禁",
      lambda: pro.share_float(ts_code=SAMPLE, start_date="20230101", end_date="20261231"))
probe("repurchase 股票回购",
      lambda: pro.repurchase(ann_date="20240102"))
probe("stk_managers 管理层",
      lambda: pro.stk_managers(ts_code=SAMPLE))

print("\n=== 3. 交易行为类 ===")
probe("top_list 龙虎榜(个股)",
      lambda: pro.top_list(ts_code=SAMPLE, start_date="20240101", end_date="20240630"))
probe("top_list 单日全部", lambda: pro.top_list(trade_date="20240102"))
probe("top_inst 龙虎榜机构", lambda: pro.top_inst(trade_date="20240102"))
probe("block_trade 大宗交易",
      lambda: pro.block_trade(ts_code=SAMPLE, start_date="20240101", end_date="20240630"))
probe("stk_limit 涨跌停价", lambda: pro.stk_limit(ts_code=SAMPLE, start_date=START, end_date=END))
probe("stk_limit 单日全市场", lambda: pro.stk_limit(trade_date="20240102"))
probe("margin_detail 两融明细", lambda: pro.margin_detail(trade_date="20240102"))
probe("limit_list_d 涨跌停统计", lambda: pro.limit_list_d(trade_date="20240102"))

print("\n=== 4. 基本面/预期类 ===")
probe("forecast 业绩预告", lambda: pro.forecast(ts_code=SAMPLE, start_date="20230101", end_date="20241231"))
probe("forecast_vip 单日全市场", lambda: pro.forecast_vip(ann_date="20240131"))
probe("express 业绩快报", lambda: pro.express(ts_code=SAMPLE, start_date="20230101", end_date="20241231"))
probe("fina_indicator 财务指标",
      lambda: pro.fina_indicator(ts_code=SAMPLE, start_date="20230101", end_date="20241231"))
probe("fina_mainbz 主营构成",
      lambda: pro.fina_mainbz(ts_code=SAMPLE, start_date="20230101", end_date="20241231"))
probe("dividend 分红送股", lambda: pro.dividend(ts_code=SAMPLE))
probe("daily_basic 单日全市场", lambda: pro.daily_basic(trade_date="20240102"))

print("\n=== 5. 指数/其他 ===")
probe("index_dailybasic 指数每日指标",
      lambda: pro.index_dailybasic(trade_date="20240102"))
probe("index_weight 中证1000", lambda: pro.index_weight(index_code="000852.SH",
                                                       start_date="20240101", end_date="20240131"))
probe("index_member_all 申万成分", lambda: pro.index_member_all(ts_code=SAMPLE))
probe("trade_cal 交易日历", lambda: pro.trade_cal(exchange="SSE", start_date=START, end_date=END))
probe("bak_basic 备用基础", lambda: pro.bak_basic(trade_date="20240102"))
probe("cyq_perf 每日筹码分布", lambda: pro.cyq_perf(ts_code=SAMPLE, start_date=START, end_date=END))

print("\n=== 6. 期货(用于判断能否自查 IM 贴水) ===")
probe("fut_basic IM", lambda: pro.fut_basic(exchange="CFFEX", fut_type="1"))
probe("fut_daily IM 主力", lambda: pro.fut_daily(ts_code="IM2401.CFX",
                                                  start_date="20240101", end_date="20240131"))
probe("index_daily 中证1000", lambda: pro.index_daily(ts_code="000852.SH",
                                                      start_date=START, end_date=END))
