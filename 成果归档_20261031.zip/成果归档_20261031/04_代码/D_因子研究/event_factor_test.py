"""事件型因子: 增减持 / 解禁 / 业绩预告。

设计原则(与已验证的股东户数/资金流因子保持一致):
  1. 全部用 **ann_date 做点-in-time 对齐**(merge_asof, backward) —— 绝不用报告期,
     避免"未来信息"。龙虎榜/业绩预告这类披露型数据尤其重要。
  2. 数值因子做时间衰减, 让"刚发生的事件"权重更高(半衰期 EVENT_HALFLIFE 天)。
  3. 比率类因子用流通股/市值/成交额归一化, 避免变成 size 别名。
  4. 事件是稀疏的: 覆盖率低是正常的, 用**是否有事件**单独做一个哑变量,
     而不是让缺失值把样本删掉。

因子清单:
  增减持(holder_trade):
    ht_net_ratio   近 180 天净增持(增持-减持)股数 / 流通股, 时间衰减
    ht_buy_ratio   近 180 天增持股数 / 流通股(只看买)
    ht_net_cnt     近 180 天净增持笔数(方向计数)
  解禁(share_float):
    fl_pressure    未来 30 天解禁股数 / 流通股  (风险过滤用; 越大越危险)
    fl_recent      过去 90 天已解禁占比
    fl_days_away   距下一次解禁的天数(越近压力越大)
  业绩预告(forecast):
    fc_pchg_mid    预告净利润变动中值 / 100, 时间衰减
    fc_type        预告类型打分(-2 首亏 .. +2 预增)
    fc_has         是否有预告(哑变量)
    fc_np_to_mv    预告净利润中值 / 总市值

用法: python event_factor_test.py [1000] [--kind holder_trade|float|forecast|all]
"""
import argparse
import os
import sys

import numpy as np
import pandas as pd

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

from config import RESULTS_DIR
from zz_pool import BASE_FEATURES
from _tune_model import get_pool
from cross_section import neutralize
from holder_factor_test import ic_stats, quintile_returns
# 构建逻辑统一放在 event_factors.py, 避免两个文件各写一份
from event_factors import (build_holder_trade, build_share_float,
                           build_forecast, build_toplist)

HALFLIFE = 120          # 事件时间衰减半衰期(交易日)
CACHE = {"500": "cache_zz500", "1000": "cache_zz1000"}


def _asof_merge(pool, ev, cols, ann="ann_date"):
    """把事件表按公告日点-in-time 合并到 pool(backward)。"""
    left = pool[["code", "date"]].sort_values("date")
    ev = ev.dropna(subset=[ann]).sort_values(ann)
    return pd.merge_asof(left, ev, left_on="date", right_on=ann,
                         by="code", direction="backward")[cols + ["code", "date"]]





BUILDERS = {
    "holder_trade": (build_holder_trade,
                     ["ht_net_ratio", "ht_buy_ratio", "ht_net_cnt"]),
    "float": (build_share_float, ["fl_pressure", "fl_days_away", "fl_recent"]),
    "forecast": (build_forecast, ["fc_type", "fc_pchg_mid", "fc_has", "fc_np_to_mv"]),
    "toplist": (build_toplist,
                ["tl_net_ratio20", "tl_inst_net20", "tl_cnt60", "tl_buy_sell"]),
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("universe", nargs="?", default="1000", choices=["500", "1000"])
    ap.add_argument("--kind", default="all", choices=list(BUILDERS.keys()) + ["all"])
    args = ap.parse_args()
    u = args.universe
    cache_dir = CACHE[u]
    pool, _, _ = get_pool(u, horizon=30)
    print(f"pool {len(pool)} 条", flush=True)

    kinds = list(BUILDERS.keys()) if args.kind == "all" else [args.kind]
    all_rows = []
    for k in kinds:
        fn, _ = BUILDERS[k]
        print(f"\n{'='*70}\n构建 [{k}] 因子\n{'='*70}", flush=True)
        pool, factors = fn(cache_dir, pool)
        factors = [f for f in factors if f in pool.columns and pool[f].notna().mean() > 0.02]
        if not factors:
            print("  无有效因子", flush=True)
            continue
        print(f"  因子: {factors}", flush=True)
        for f in factors:
            print(f"    {f:<16} 覆盖 {pool[f].notna().mean():6.2%}  "
                  f"均值 {pool[f].mean():+.5f} 标准差 {pool[f].std():.5f}", flush=True)

        # 注意: 不能对整个因子集 dropna —— 事件型因子覆盖率差异极大
        # (如解禁压力只有 4%), 一起 dropna 会把覆盖率高的因子也清空。
        pn = neutralize(pool, factors)
        print(f"\n  {'因子':<16}{'覆盖':>8}{'IC':>10}{'ICIR':>9}{'IC>0':>8}{'Q1':>9}{'Q5':>9}{'Q5-Q1':>10}",
              flush=True)
        keep = [c for c in BASE_FEATURES if c in pn.columns]
        for f in factors:
            sub = pn.dropna(subset=[f])
            cov = len(sub) / max(len(pn), 1)
            if len(sub) < 1000:
                print(f"  {f:<16}{cov:>8.2%}   样本不足, 跳过", flush=True)
                continue
            ic, icir, n, pos = ic_stats(sub, f)
            means, spread = quintile_returns(sub, f)
            print(f"  {f:<16}{cov:>8.2%}{ic:>+10.4f}{icir:>+9.3f}{pos:>8.1%}"
                  f"{means[0]:>+9.2%}{means[-1]:>+9.2%}{spread:>+10.2%}", flush=True)
            all_rows.append((k, f, cov, ic, icir, pos, spread))
            if keep:
                x = sub[[f] + keep].dropna()
                if len(x) > 100:
                    corr = x.corr(method="spearman").loc[f, keep]
                    top = corr.abs().sort_values(ascending=False).head(3)
                    print(f"     最大相关: " + ", ".join(f"{i}={corr[i]:+.3f}" for i in top.index),
                          flush=True)
        pool.to_pickle(os.path.join(cache_dir, f"_event_pool_{u}_{k}.pkl"))

    path = os.path.join(RESULTS_DIR, f"event_factors_zz{u}_report.txt")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(f"中证{u} 事件型因子测试(增减持/解禁/业绩预告)\n")
        fh.write("点-in-time(ann_date) 对齐, 时间衰减半衰期 120 交易日\n\n")
        fh.write(f"{'类别':<14}{'因子':<16}{'覆盖':>8}{'IC':>10}{'ICIR':>9}{'IC>0':>8}{'Q5-Q1':>10}\n")
        for k, f, cov, ic, icir, pos, spread in all_rows:
            fh.write(f"{k:<14}{f:<16}{cov:>8.2%}{ic:>+10.4f}{icir:>+9.3f}"
                     f"{pos:>8.1%}{spread:>+10.2%}\n")
    print(f"\n报告已保存: {path}", flush=True)


if __name__ == "__main__":
    main()
