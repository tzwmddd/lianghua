"""股东户数因子: 构建 + 单因子 IC + 与现有因子的相关性 + 边际增量。

因子(基于 log(holder_num), 用 ann_date 做点-in-time 对齐):
  hl_chg_q    : 股东户数对数环比变化(负数 = 户数下降 = 筹码集中 = 看多)
  hl_chg_4q   : 对数同比变化
  hl_level    : 对数户数水平(小 = 筹码集中)
  hl_chg_yoy2 : 连续两期的改善速度(变化率的变化率, 捕捉加速集中)

用法: python holder_factor_test.py [1000]
"""
import os
import sys

import numpy as np
import pandas as pd

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

from config import RESULTS_DIR
from zz_pool import BASE_FEATURES
from _tune_model import get_pool, TEST_START, REBAL_STEP
from cross_section import neutralize

FACTORS = ["hl_chg_q", "hl_chg_4q", "hl_level", "hl_speed"]


def build_holder_factors(cache_dir, pool):
    """把股东户数因子按 ann_date 点-in-time 合并到 pool。"""
    path = os.path.join(cache_dir, "_holder_number.csv")
    h = pd.read_csv(path, parse_dates=["ann_date", "end_date"], dtype={"code": str})
    n0 = len(h)
    h = h.dropna(subset=["ann_date", "end_date"])
    h = h[(h["end_date"] >= "2010-01-01") & (h["end_date"] <= "2026-12-31")]
    # 报告期不能晚于公告日(剔除脏数据)
    h = h[h["end_date"] <= h["ann_date"] + pd.Timedelta(days=5)]
    h = h[h["holder_num"] > 0]
    print(f"股东户数: {n0} -> {len(h)} 行 (剔除异常日期/空值)", flush=True)

    h = h.sort_values(["code", "end_date"]).drop_duplicates(["code", "end_date"], keep="last")
    g = h.groupby("code")["holder_num"]
    h["hl_level"] = np.log(h["holder_num"])
    h["hl_chg_q"] = h["hl_level"] - g.shift(1).apply(np.log)
    h["hl_chg_4q"] = h["hl_level"] - g.shift(4).apply(np.log)
    # 加速集中: 本季降幅 - 上季降幅(正 = 降速加快)
    h["hl_speed"] = h["hl_chg_q"] - (h["hl_chg_q"].shift(1))

    cols = ["code", "ann_date"] + FACTORS
    h = h[cols].dropna(subset=["code", "ann_date"]).sort_values("ann_date")
    p = pool.sort_values("date")
    merged = pd.merge_asof(p, h, left_on="date", right_on="ann_date",
                           by="code", direction="backward")
    return merged


def ic_stats(pool, factor, fwd_col="excess_fwd", min_n=100, step=REBAL_STEP):
    """按调仓频率(默认每 30 交易日)计算 Rank IC, 与模型评估口径一致。

    逐日算 IC 会得到 2700+ 期高度自相关的样本, ICIR 被严重高估/失真。
    """
    dates = sorted(pool["date"].unique())
    start = next(i for i, d in enumerate(dates) if d >= pd.Timestamp(TEST_START))
    rebal = set(dates[start::step])
    ics = []
    for t, g in pool.groupby("date"):
        if t not in rebal:
            continue
        sub = g[[factor, fwd_col]].dropna()
        if len(sub) < min_n or sub[factor].nunique() < 5:
            continue
        ics.append(sub[factor].corr(sub[fwd_col], method="spearman"))
    ics = np.array([x for x in ics if np.isfinite(x)])
    if len(ics) == 0:
        return np.nan, np.nan, 0, np.nan
    return ics.mean(), ics.mean() / ics.std(ddof=1), len(ics), (ics > 0).mean()


def quintile_returns(pool, factor, fwd_col="excess_fwd", n_groups=5, step=REBAL_STEP):
    """分层组合超额: 返回 (Q1..Q5 平均超额, Q5-Q1), 判断因子方向与单调性。"""
    dates = sorted(pool["date"].unique())
    start = next(i for i, d in enumerate(dates) if d >= pd.Timestamp(TEST_START))
    rebal = set(dates[start::step])
    grp = {g: [] for g in range(n_groups)}
    for t, gg in pool.groupby("date"):
        if t not in rebal:
            continue
        sub = gg[[factor, fwd_col]].dropna()
        if len(sub) < 100 or sub[factor].nunique() < n_groups:
            continue
        r = sub[factor].rank(method="first", pct=True)
        gidx = np.ceil(r * n_groups).astype(int) - 1
        for g in range(n_groups):
            vals = sub.loc[gidx == g, fwd_col]
            if len(vals):
                grp[g].append(vals.mean())
    means = [float(np.nanmean(grp[g])) if grp[g] else np.nan for g in range(n_groups)]
    return means, means[-1] - means[0]


def main():
    u = sys.argv[1] if len(sys.argv) > 1 else "1000"
    pool, cache_dir, cost = get_pool(u, horizon=30)
    print(f"pool {len(pool)} 条", flush=True)

    pool = build_holder_factors(cache_dir, pool)
    print(f"\n因子覆盖率:")
    for f in FACTORS:
        cov = pool[f].notna().mean()
        print(f"  {f:<12} 覆盖 {cov:6.2%}, 均值 {pool[f].mean():+.4f}, 标准差 {pool[f].std():.4f}",
              flush=True)

    # 中性化后 IC(与模型里一致的处理)
    print(f"\n=== 单因子 Rank IC (每 {REBAL_STEP} 交易日调仓口径, 与模型一致) ===", flush=True)
    print(f"{'因子':<14}{'原始IC':>10}{'原始ICIR':>10}{'中性化IC':>11}{'中性化ICIR':>12}"
          f"{'IC>0':>8}{'期数':>7}", flush=True)
    rows = []
    neutralized = {}
    for f in FACTORS:
        ic0, icir0, n0, _ = ic_stats(pool, f)
        pn = pool.dropna(subset=[f]).copy()
        if "log_mcap" in pn.columns and pn["log_mcap"].notna().any():
            pn = neutralize(pn, [f])
            ic1, icir1, n1, pos = ic_stats(pn, f)
            neutralized[f] = pn
        else:
            ic1, icir1, n1, pos = np.nan, np.nan, 0, np.nan
        print(f"{f:<14}{ic0:>+10.4f}{icir0:>+10.3f}{ic1:>+11.4f}{icir1:>+12.3f}"
              f"{pos:>8.1%}{n1:>7}", flush=True)
        rows.append((f, ic0, icir0, ic1, icir1))

    # 分层组合超额: 看因子的实际形态(单调性比 IC 更能说明能不能用)
    print(f"\n=== 中性化后分层组合超额(每期, Q1=因子最小) ===", flush=True)
    print(f"{'因子':<14}{'Q1':>9}{'Q2':>9}{'Q3':>9}{'Q4':>9}{'Q5':>9}{'Q5-Q1':>10}", flush=True)
    for f in FACTORS:
        pn = neutralized.get(f)
        if pn is None:
            continue
        means, spread = quintile_returns(pn, f)
        print(f"{f:<14}" + "".join(f"{m:>+9.2%}" for m in means) + f"{spread:>+10.2%}", flush=True)
        rows.append((f + " 分层", means[0], means[1], means[2], means[3]))
        with open(os.path.join(RESULTS_DIR, f"_holder_quintile_{u}.txt"), "a",
                  encoding="utf-8") as fh:
            fh.write(f"{f}: " + ", ".join(f"Q{i+1}={m:+.3%}" for i, m in enumerate(means))
                     + f", Q5-Q1={spread:+.3%}\n")

    # 与现有因子的相关性(判断正交性)
    print(f"\n=== 与现有技术面因子的横截面相关性(中性化后) ===", flush=True)
    pn = pool.dropna(subset=FACTORS).copy()
    keep = [c for c in BASE_FEATURES if c in pn.columns]
    x = pn[FACTORS + keep].dropna()
    if len(x) > 100:
        corr = x.corr(method="spearman")
        for f in FACTORS:
            sub = corr.loc[f, keep].drop(f, errors="ignore")
            top = sub.abs().sort_values(ascending=False).head(4)
            s = ", ".join(f"{k}={sub[k]:+.3f}" for k in top.index)
            print(f"  {f:<12} 最大相关: {s}", flush=True)
        print(f"\n  (|相关| < 0.3 才算真正交; 现有因子的做法是绝对值越小越好)", flush=True)

    path = os.path.join(RESULTS_DIR, f"holder_factor_zz{u}_report.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"中证{u} 股东户数因子测试\n\n")
        f.write("因子             原始IC    原始ICIR   中性化IC  中性化ICIR\n")
        for f_, a, b, c, d in rows:
            f.write(f"{f_:<14}{a:>+10.4f}{b:>+10.3f}{c:>+11.4f}{d:>+12.3f}\n")
    print(f"\n报告已保存: {path}", flush=True)


if __name__ == "__main__":
    main()
