"""风控过滤验证: 把"反向规律"做成候选池过滤规则, 而不是喂给模型。

动机:
  - 龙虎榜单因子是**反向**的(IC -0.010~-0.013, 上榜后容易回落), 但把 tl_* 当特征
    接入模型反而 -0.27 个点(规律已被技术面吸收)。那直接**剔除**这些股票呢?
  - 解禁因子选股完全无效(IC ±0.003), 但"临近大额解禁"是已知的风险事件,
    直接剔除可能有效。

做法(在已找到的最优配置上叠加):
  基准      : top15% / 缓冲50% / 概率加权 / 特征=技术面+股东户数+资金流+业绩预告
  +剔龙虎榜 : 候选池里剔除"近 N 天上过龙虎榜"的股票
  +剔解禁   : 候选池里剔除"未来 N 天内解禁比例 > 阈值"的股票
  +两者

用法:
  python risk_filter_test.py 1000                 # 全部
  python risk_filter_test.py 1000 --quick         # 只测基准 + 一个过滤
"""
import argparse
import os
import sys
import time

import numpy as np
import pandas as pd
import lightgbm as lgb

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

from config import SEED, EMBARGO_DAYS, RESULTS_DIR
from data import load_cached
from zz_pool import BASE_FEATURES
from orthogonal_factors import attach_orthogonal_factors, ORTHO_FEATURES
from event_factors import build_event_factors
from _tune_model import get_pool

UNIVERSES = {"500": ("cache_zz500", 0.004), "1000": ("cache_zz1000", 0.005)}
LIQUIDITY_DROP = 0.2
MIN_TRAIN = 5000
H = 30
TOP_FRAC = 0.15
BUFFER = 0.5

# 龙虎榜过滤: 近 N 天内上榜过就剔除
TL_LOOKBACK_DAYS = 20
# 解禁过滤: 未来 N 天内解禁比例 > 阈值就剔除
FL_WINDOW_DAYS = 45
FL_THRESHOLDS = [0.03, 0.05, 0.10]


def build_filter_flags(cache_dir, pool):
    """构造三个候选池过滤标记(True = 剔除)。

    tl_recent : 近 TL_LOOKBACK_DAYS 天上过龙虎榜
    fl_soon   : 未来 FL_WINDOW_DAYS 天内解禁比例 > 阈值 (分别出 3 个阈值)
    """
    n = len(pool)
    tl_flag = np.zeros(n, dtype=bool)
    fl_flags = {t: np.zeros(n, dtype=bool) for t in FL_THRESHOLDS}

    # ---- 龙虎榜 ----
    p = os.path.join(cache_dir, "_top_list.csv")
    if os.path.exists(p):
        tl = pd.read_csv(p, dtype={"code": str, "trade_date": str})
        tl["date"] = pd.to_datetime(tl["trade_date"], format="%Y%m%d", errors="coerce")
        tl = tl.dropna(subset=["date"])[["code", "date"]].drop_duplicates()
        # 每个 (code, date) 若在近 N 天内有上榜记录 -> 标记
        key = pool[["code", "date"]].copy()
        key["rid"] = np.arange(len(key))
        tl2 = tl.copy()
        tl2["hit"] = True
        m = pd.merge_asof(key.sort_values("date"), tl2.sort_values("date"),
                          left_on="date", right_on="date", by="code",
                          direction="backward",
                          tolerance=pd.Timedelta(days=int(TL_LOOKBACK_DAYS * 365 / 252)))
        tl_flag[m["rid"].to_numpy()] = m["hit"].fillna(False).to_numpy()
        print(f"  龙虎榜过滤: 命中 {tl_flag.mean():.2%} 的样本(近 "
              f"{TL_LOOKBACK_DAYS} 交易日内上榜)", flush=True)
    else:
        print("  [跳过] 无 _top_list.csv", flush=True)

    # ---- 解禁 ----
    p = os.path.join(cache_dir, "_share_float.csv")
    if os.path.exists(p):
        sf = pd.read_csv(p, dtype={"code": str, "float_date": str})
        # float_date 是 20150313 形式的整数 -> 必须先转字符串, 否则解析成 1970 年
        sf["float_date"] = pd.to_datetime(sf["float_date"], format="%Y%m%d", errors="coerce")
        # float_ratio 单位是百分比(22.38 = 22.38%), 这里统一换成小数
        sf["float_ratio"] = pd.to_numeric(sf["float_ratio"], errors="coerce") / 100.0
        sf = sf.dropna(subset=["float_date", "float_ratio"])
        sf = sf[["code", "float_date", "float_ratio"]].sort_values("float_date")
        key = pool[["code", "date"]].copy()
        key["rid"] = np.arange(len(key))
        m = pd.merge_asof(key.sort_values("date"), sf,
                          left_on="date", right_on="float_date", by="code",
                          direction="forward",
                          tolerance=pd.Timedelta(days=FL_WINDOW_DAYS))
        ratio = m["float_ratio"].to_numpy()
        rid = m["rid"].to_numpy()
        for t in FL_THRESHOLDS:
            hit = np.zeros(n, dtype=bool)
            hit[rid] = np.nan_to_num(ratio, nan=0.0) > t
            fl_flags[t] = hit
            print(f"  解禁过滤(>{t:.0%}, 未来 {FL_WINDOW_DAYS} 天): "
                  f"命中 {hit.mean():.2%}", flush=True)
    else:
        print("  [跳过] 无 _share_float.csv", flush=True)

    return {"tl": tl_flag, **{f"fl{t}": v for t, v in fl_flags.items()}}


def run(pool, features, cost, drop_mask=None):
    """drop_mask: 布尔数组, True 表示该样本在候选池中被剔除(仅作用于预测截面,
    训练集不动 —— 因为过滤是"选股规则", 不是"数据清洗")。"""
    dates = sorted(pool["date"].unique())
    start = next(i for i, d in enumerate(dates) if d >= pd.Timestamp("2017-01-01"))
    rebal = dates[start::H]
    rec = []
    prev_hold = set()
    for t in rebal:
        cutoff = t - pd.Timedelta(days=EMBARGO_DAYS)
        train = pool[(pool["date"] < cutoff) & pool["target_rel"].notna()]
        Xtr = train[features].to_numpy(dtype=float)
        keep = np.isfinite(Xtr).any(axis=1)
        train, Xtr = train[keep], Xtr[keep]
        if len(train) < MIN_TRAIN:
            continue
        cross = pool[(pool["date"] == t) & pool["stock_fwd"].notna()].copy()
        if drop_mask is not None:
            cross = cross[~drop_mask[cross.index.to_numpy()]]
        if len(cross) < 30:
            continue
        model = lgb.LGBMClassifier(
            n_estimators=150, learning_rate=0.10, num_leaves=63,
            subsample=0.8, colsample_bytree=0.8,
            random_state=SEED, verbosity=-1, n_jobs=-1)
        model.fit(Xtr, train["target_rel"].to_numpy())
        cross["prob"] = model.predict_proba(cross[features].to_numpy(dtype=float))[:, 1]
        if cross["turnover"].notna().sum() > 10:
            th = cross["turnover"].quantile(LIQUIDITY_DROP)
            cross = cross[cross["turnover"] >= th]
        n_liq = len(cross)
        k = max(1, int(n_liq * TOP_FRAC))
        buf_k = max(k, int(n_liq * BUFFER))
        cross = cross.sort_values("prob", ascending=False)
        buf_codes = set(cross.head(buf_k)["code"])
        buyable = cross[cross["tradable_buy"].astype(bool)]
        keep_h = [c for c in prev_hold if c in buf_codes]
        final = keep_h[:k]
        for c in buyable["code"]:
            if len(final) >= k:
                break
            if c not in final:
                final.append(c)
        if not final:
            continue
        hold = set(final)
        turn = len(hold - prev_hold) / len(hold) if prev_hold else 1.0
        prev_hold = hold
        q = cross[cross["code"].isin(hold)].copy()
        p = q["prob"].to_numpy(dtype=float)
        w = (0.5 + (p - p.min()) / (p.max() - p.min())) if (len(p) > 1 and p.max() > p.min()) \
            else np.ones(len(p))
        w = w / w.sum()
        rec.append({"date": t, "hold": sorted(hold), "turn": turn, "w": w.tolist(),
                    "gross": float(np.dot(w, q["stock_fwd"].to_numpy())),
                    "excess": float(np.dot(w, q["excess_fwd"].to_numpy()))})
    return rec


def metrics(rec, cache_dir, cost):
    dts = [r["date"] for r in rec]
    need = {c for r in rec for c in r["hold"]}
    px = {}
    for code in need:
        df = load_cached(code, cache_dir)
        if df is None:
            continue
        df = df[(df["date"] >= dts[0]) & (df["date"] <= dts[-1] + pd.Timedelta(days=1))]
        if len(df) >= 2:
            px[code] = df.set_index("date")["close"]
    mat = pd.DataFrame(px).sort_index().ffill()
    rets = mat.pct_change()
    segs = []
    for i, r in enumerate(rec[:-1]):
        hold = [c for c in r["hold"] if c in rets.columns]
        if not hold:
            continue
        win = rets.loc[(rets.index > dts[i]) & (rets.index <= dts[i + 1]), hold]
        if len(win) == 0:
            continue
        wmap = dict(zip(r["hold"], r["w"]))
        wv = np.array([wmap.get(c, 0.0) for c in hold], dtype=float)
        wv = wv / wv.sum() if wv.sum() > 0 else np.full(len(hold), 1.0 / len(hold))
        port = pd.Series(win.to_numpy() @ wv, index=win.index)
        port.iloc[0] -= r["turn"] * cost
        segs.append(port)
    pr = pd.concat(segs).sort_index()
    nav = (1 + pr).cumprod()
    net = np.array([r["gross"] for r in rec]) - np.array([r["turn"] for r in rec]) * cost
    exc = np.array([r["excess"] for r in rec])
    return dict(n=len(rec), turn=np.mean([r["turn"] for r in rec]),
                net=net.mean(), ann=float(nav.iloc[-1] ** (252 / len(pr)) - 1),
                ann_ex=float((1 + exc.mean()) ** (252 / H) - 1),
                dd=float((nav / nav.cummax() - 1).min()),
                sharpe=float(pr.mean() / pr.std(ddof=1) * np.sqrt(252)))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("universe", nargs="?", default="1000", choices=["500", "1000"])
    ap.add_argument("--quick", action="store_true")
    args = ap.parse_args()
    u = args.universe
    cache_dir, cost = UNIVERSES[u]
    t0 = time.time()

    pool, _, _ = get_pool(u, horizon=H)
    pool = attach_orthogonal_factors(pool, cache_dir)
    pool = build_event_factors(pool, cache_dir)
    feats = BASE_FEATURES + [f for f in ORTHO_FEATURES if f in pool.columns]
    feats += [f for f in ("fc_type", "fc_pchg_mid") if f in pool.columns]
    print(f"\n基准特征数 {len(feats)}", flush=True)
    print("\n构造过滤标记:", flush=True)
    flags = build_filter_flags(cache_dir, pool)

    configs = [("基准(无过滤)", None)]
    if "tl" in flags and flags["tl"].any():
        configs.append((f"剔除近20天上榜股", flags["tl"]))
    for t in FL_THRESHOLDS:
        key = f"fl{t}"
        if key in flags and flags[key].any():
            configs.append((f"剔除未来45天解禁>{t:.0%}", flags[key]))
    if "tl" in flags and flags["tl"].any() and "fl0.05" in flags:
        configs.append(("两者都剔", flags["tl"] | flags["fl0.05"]))
    if args.quick:
        configs = configs[:2]

    header = (f"{'配置':<26}{'期数':>6}{'换手':>7}{'净收益/期':>10}{'年化绝对':>9}"
              f"{'最大回撤':>9}{'日频夏普':>9}{'年化超额':>9}")
    print("\n" + header, flush=True)
    print("-" * len(header), flush=True)
    rows = []
    for name, mask in configs:
        t1 = time.time()
        m = metrics(run(pool, feats, cost, drop_mask=mask), cache_dir, cost)
        row = (f"{name:<26}{m['n']:>6}{m['turn']:>7.1%}{m['net']:>+10.3%}"
               f"{m['ann']:>+9.2%}{m['dd']:>9.2%}{m['sharpe']:>9.3f}{m['ann_ex']:>+9.2%}")
        print(row + f"  ({time.time() - t1:.0f}s)", flush=True)
        rows.append((name, m))

    base = rows[0][1]
    print(f"\n相对基准的增量:", flush=True)
    for name, m in rows[1:]:
        print(f"  {name:<26} 年化绝对 {m['ann'] - base['ann']:+.2%}  "
              f"年化超额 {m['ann_ex'] - base['ann_ex']:+.2%}  "
              f"夏普 {m['sharpe'] - base['sharpe']:+.3f}  "
              f"回撤 {m['dd'] - base['dd']:+.2%}", flush=True)

    path = os.path.join(RESULTS_DIR, f"risk_filter_zz{u}_report.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"中证{u} 风控过滤验证(龙虎榜/解禁)\n")
        f.write(f"基准: top{TOP_FRAC:.0%} / 缓冲{BUFFER:.0%} / 概率加权 / H={H}\n\n")
        f.write(header + "\n" + "-" * len(header) + "\n")
        for name, m in rows:
            f.write(f"{name:<26}{m['n']:>6}{m['turn']:>7.1%}{m['net']:>+10.3%}"
                    f"{m['ann']:>+9.2%}{m['dd']:>9.2%}{m['sharpe']:>9.3f}{m['ann_ex']:>+9.2%}\n")
        f.write("\n相对基准:\n")
        for name, m in rows[1:]:
            f.write(f"  {name}: 年化绝对 {m['ann'] - base['ann']:+.2%}, "
                    f"年化超额 {m['ann_ex'] - base['ann_ex']:+.2%}, "
                    f"夏普 {m['sharpe'] - base['sharpe']:+.3f}\n")
    print(f"\n报告已保存: {path}", flush=True)
    print(f"总耗时 {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
