"""对照实验: 中证1000 上"单加 fc_pchg_mid"是否仍为负?

背景: 中证500 上单加 fc_pchg_mid 是 +0.48(正), 两个一起加是 -3.31(负);
      而中证1000 的旧数据上单加 -0.41(负), 两个一起 +1.61(正) —— 完全相反。
      中证1000 的旧结论是数据更新前跑的, 需要用当前数据复核。

用法: python _fc_ablation.py [1000|500]
"""
import os
import sys
import time

import numpy as np
import pandas as pd

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

from config import RESULTS_DIR
from zz_pool import BASE_FEATURES
from orthogonal_factors import attach_orthogonal_factors, ORTHO_FEATURES
from event_factors import build_event_factors
from _tune_model import get_pool
from event_model_test import run, metrics, UNIVERSES, H

u = sys.argv[1] if len(sys.argv) > 1 else "1000"
cache_dir, cost = UNIVERSES[u]
t0 = time.time()

pool, _, _ = get_pool(u, horizon=H)
pool = attach_orthogonal_factors(pool, cache_dir)
pool = build_event_factors(pool, cache_dir)
base = BASE_FEATURES + [f for f in ORTHO_FEATURES if f in pool.columns]

configs = [
    ("基准(技术+股东户数+资金流)", base),
    ("+fc_pchg_mid 单加", base + ["fc_pchg_mid"]),
    ("+fc_type 单加", base + ["fc_type"]),
    ("+fc_type+fc_pchg_mid", base + ["fc_type", "fc_pchg_mid"]),
    ("+fc_np_to_mv 单加", base + ["fc_np_to_mv"]),
]
header = (f"{'特征集':<30}{'期数':>6}{'换手':>7}{'净收益/期':>10}{'年化绝对':>9}"
          f"{'最大回撤':>9}{'日频夏普':>9}{'年化超额':>9}")
print(f"\n=== 中证{u} 业绩预告因子消融实验 ===")
print(header)
print("-" * len(header))
rows = []
for name, feats in configs:
    feats = [f for f in feats if f in pool.columns]
    t1 = time.time()
    m = metrics(run(pool, feats, cost), cache_dir, cost)
    row = (f"{name:<30}{m['n']:>6}{m['turn']:>7.1%}{m['net']:>+10.3%}"
           f"{m['ann']:>+9.2%}{m['dd']:>9.2%}{m['sharpe']:>9.3f}{m['ann_ex']:>+9.2%}")
    print(row + f"  ({time.time() - t1:.0f}s)", flush=True)
    rows.append((name, m))

b = rows[0][1]
print(f"\n相对基准:")
for name, m in rows[1:]:
    print(f"  {name:<30} 年化绝对 {m['ann'] - b['ann']:+.2%}  "
          f"年化超额 {m['ann_ex'] - b['ann_ex']:+.2%}  "
          f"夏普 {m['sharpe'] - b['sharpe']:+.3f}  回撤 {m['dd'] - b['dd']:+.2%}")

path = os.path.join(RESULTS_DIR, f"fc_ablation_zz{u}_report.txt")
with open(path, "w", encoding="utf-8") as f:
    f.write(f"中证{u} 业绩预告因子消融实验\n")
    f.write("(复核: 中证500 与中证1000 的结论相反, 需在当前数据上重测)\n\n")
    f.write(header + "\n" + "-" * len(header) + "\n")
    for name, m in rows:
        f.write(f"{name:<30}{m['n']:>6}{m['turn']:>7.1%}{m['net']:>+10.3%}"
                f"{m['ann']:>+9.2%}{m['dd']:>9.2%}{m['sharpe']:>9.3f}{m['ann_ex']:>+9.2%}\n")
    f.write("\n相对基准:\n")
    for name, m in rows[1:]:
        f.write(f"  {name}: 年化绝对 {m['ann'] - b['ann']:+.2%}, "
                f"年化超额 {m['ann_ex'] - b['ann_ex']:+.2%}\n")
print(f"\n报告已保存: {path}")
print(f"总耗时 {time.time() - t0:.0f}s")
