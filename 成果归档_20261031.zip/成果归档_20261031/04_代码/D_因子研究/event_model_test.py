"""事件型因子接入模型的净收益增量测试。

沿用已找到的最优配置(top15% / 缓冲50% / 概率加权 / H=30),
只变特征集, 保证可比。逐因子单独加 —— 实测"全加"会稀释。

用法:
  python event_model_test.py 1000 --quick    # 只测 基准 + 增减持
  python event_model_test.py 1000            # 全部
"""
import argparse
import os
import sys
import time

import numpy as np
import pandas as pd
import lightgbm as lgb

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

from config import SEED, EMBARGO_DAYS, RESULTS_DIR
from data import load_cached
from zz_pool import BASE_FEATURES
from orthogonal_factors import attach_orthogonal_factors, ORTHO_FEATURES
from event_factors import (build_event_factors, HT_FEATURES, FL_FEATURES,
                           FC_FEATURES)
from _tune_model import get_pool

UNIVERSES = {"500": ("cache_zz500", 0.004), "1000": ("cache_zz1000", 0.005)}
LIQUIDITY_DROP = 0.2
MIN_TRAIN = 5000
H = 30
TOP_FRAC = 0.15
BUFFER = 0.5
# 龙虎榜实测是**反向**因子(IC 为负: 上榜后容易回落)
TL_FEATURES = ["tl_net_ratio20", "tl_cnt60", "tl_buy_sell"]


def run(pool, features, cost, fillna=None):
    """fillna: None=保留 NaN(LightGBM 原生处理缺失); 0.0=缺失填中性值。

    覆盖率低的因子(如增减持 45%)保留 NaN 时, LightGBM 会把"缺失"当成一个
    独立分支, 模型可能去学"有没有数据"而不是因子本身。填充 0 可以验证这一点。
    """
    dates = sorted(pool["date"].unique())
    start = next(i for i, d in enumerate(dates) if d >= pd.Timestamp("2017-01-01"))
    rebal = dates[start::H]
    rec = []
    prev_hold = set()
    for t in rebal:
        cutoff = t - pd.Timedelta(days=EMBARGO_DAYS)
        train = pool[(pool["date"] < cutoff) & pool["target_rel"].notna()]
        Xtr = train[features].to_numpy(dtype=float)
        keep = np.isfinite(Xtr).any(axis=1)
        train, Xtr = train[keep], Xtr[keep]
        if len(train) < MIN_TRAIN:
            continue
        cross = pool[(pool["date"] == t) & pool["stock_fwd"].notna()].copy()
        if len(cross) < 30:
            continue
        Xcr = cross[features].to_numpy(dtype=float)
        if fillna is not None:
            Xtr = np.nan_to_num(Xtr, nan=fillna)
            Xcr = np.nan_to_num(Xcr, nan=fillna)
        model = lgb.LGBMClassifier(
            n_estimators=150, learning_rate=0.10, num_leaves=63,
            subsample=0.8, colsample_bytree=0.8,
            random_state=SEED, verbosity=-1, n_jobs=-1)
        model.fit(Xtr, train["target_rel"].to_numpy())
        cross["prob"] = model.predict_proba(Xcr)[:, 1]
        if cross["turnover"].notna().sum() > 10:
            th = cross["turnover"].quantile(LIQUIDITY_DROP)
            cross = cross[cross["turnover"] >= th]
        n_liq = len(cross)
        k = max(1, int(n_liq * TOP_FRAC))
        buf_k = max(k, int(n_liq * BUFFER))
        cross = cross.sort_values("prob", ascending=False)
        buf_codes = set(cross.head(buf_k)["code"])
        buyable = cross[cross["tradable_buy"].astype(bool)]
        keep_h = [c for c in prev_hold if c in buf_codes]
        final = keep_h[:k]
        for c in buyable["code"]:
            if len(final) >= k:
                break
            if c not in final:
                final.append(c)
        if not final:
            continue
        hold = set(final)
        turn = len(hold - prev_hold) / len(hold) if prev_hold else 1.0
        prev_hold = hold
        q = cross[cross["code"].isin(hold)].copy()
        p = q["prob"].to_numpy(dtype=float)
        w = (0.5 + (p - p.min()) / (p.max() - p.min())) if (len(p) > 1 and p.max() > p.min()) \
            else np.ones(len(p))
        w = w / w.sum()
        rec.append({"date": t, "hold": sorted(hold), "turn": turn, "w": w.tolist(),
                    "gross": float(np.dot(w, q["stock_fwd"].to_numpy())),
                    "excess": float(np.dot(w, q["excess_fwd"].to_numpy()))})
    return rec


def metrics(rec, cache_dir, cost):
    dts = [r["date"] for r in rec]
    need = {c for r in rec for c in r["hold"]}
    px = {}
    for code in need:
        df = load_cached(code, cache_dir)
        if df is None:
            continue
        df = df[(df["date"] >= dts[0]) & (df["date"] <= dts[-1] + pd.Timedelta(days=1))]
        if len(df) >= 2:
            px[code] = df.set_index("date")["close"]
    mat = pd.DataFrame(px).sort_index().ffill()
    rets = mat.pct_change()
    segs = []
    for i, r in enumerate(rec[:-1]):
        hold = [c for c in r["hold"] if c in rets.columns]
        if not hold:
            continue
        win = rets.loc[(rets.index > dts[i]) & (rets.index <= dts[i + 1]), hold]
        if len(win) == 0:
            continue
        wmap = dict(zip(r["hold"], r["w"]))
        wv = np.array([wmap.get(c, 0.0) for c in hold], dtype=float)
        wv = wv / wv.sum() if wv.sum() > 0 else np.full(len(hold), 1.0 / len(hold))
        port = pd.Series(win.to_numpy() @ wv, index=win.index)
        port.iloc[0] -= r["turn"] * cost
        segs.append(port)
    pr = pd.concat(segs).sort_index()
    nav = (1 + pr).cumprod()
    net = np.array([r["gross"] for r in rec]) - np.array([r["turn"] for r in rec]) * cost
    exc = np.array([r["excess"] for r in rec])
    return dict(n=len(rec), turn=np.mean([r["turn"] for r in rec]),
                net=net.mean(), ann=float(nav.iloc[-1] ** (252 / len(pr)) - 1),
                ann_ex=float((1 + exc.mean()) ** (252 / H) - 1),
                dd=float((nav / nav.cummax() - 1).min()),
                sharpe=float(pr.mean() / pr.std(ddof=1) * np.sqrt(252)))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("universe", nargs="?", default="1000", choices=["500", "1000"])
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--fill", action="store_true",
                    help="缺失值填 0(验证覆盖率假设)")
    args = ap.parse_args()
    u = args.universe
    cache_dir, cost = UNIVERSES[u]
    t0 = time.time()
    fillna = 0.0 if args.fill else None

    pool, _, _ = get_pool(u, horizon=H)
    pool = attach_orthogonal_factors(pool, cache_dir)
    pool = build_event_factors(pool, cache_dir)
    base_feats = BASE_FEATURES + [f for f in ORTHO_FEATURES if f in pool.columns]
    print(f"\n基准特征数 {len(base_feats)}", flush=True)

    configs = [("基准(技术+股东户数+资金流)", base_feats)]
    if all(f in pool.columns for f in HT_FEATURES):
        configs.append(("+增减持(ht_net_ratio)", base_feats + ["ht_net_ratio"]))
        configs.append(("+增减持(两个)", base_feats + HT_FEATURES))
    if all(f in pool.columns for f in FC_FEATURES):
        configs.append(("+业绩预告(fc_pchg_mid)", base_feats + ["fc_pchg_mid"]))
        configs.append(("+业绩预告(两个)", base_feats + ["fc_type", "fc_pchg_mid"]))
    if all(f in pool.columns for f in FL_FEATURES):
        configs.append(("+解禁(fl_pressure)", base_feats + ["fl_pressure"]))
    if all(f in pool.columns for f in TL_FEATURES):
        configs.append(("+龙虎榜(反向因子)", base_feats + TL_FEATURES))
    if args.quick:
        configs = configs[:2]

    header = (f"{'特征集':<30}{'持仓':>6}{'换手':>7}{'净收益/期':>10}{'年化绝对':>9}"
              f"{'最大回撤':>9}{'日频夏普':>9}{'年化超额':>9}")
    print("\n" + header, flush=True)
    print("-" * len(header), flush=True)
    rows = []
    for name, feats in configs:
        t1 = time.time()
        m = metrics(run(pool, feats, cost, fillna=fillna), cache_dir, cost)
        row = (f"{name:<30}{m['n']:>6}{m['turn']:>7.1%}{m['net']:>+10.3%}"
               f"{m['ann']:>+9.2%}{m['dd']:>9.2%}{m['sharpe']:>9.3f}{m['ann_ex']:>+9.2%}")
        print(row + f"  ({time.time() - t1:.0f}s)", flush=True)
        rows.append((name, m))

    base = rows[0][1]
    print(f"\n相对基准的增量:", flush=True)
    for name, m in rows[1:]:
        print(f"  {name:<30} 年化绝对 {m['ann'] - base['ann']:+.2%}  "
              f"年化超额 {m['ann_ex'] - base['ann_ex']:+.2%}  "
              f"夏普 {m['sharpe'] - base['sharpe']:+.3f}  "
              f"回撤 {m['dd'] - base['dd']:+.2%}", flush=True)

    path = os.path.join(RESULTS_DIR, f"event_model_zz{u}_report.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"中证{u} 事件型因子接入模型增量测试\n")
        f.write(f"最优交易参数: top{TOP_FRAC:.0%} / 缓冲{BUFFER:.0%} / 概率加权 / H={H}\n\n")
        f.write(header + "\n" + "-" * len(header) + "\n")
        for name, m in rows:
            f.write(f"{name:<30}{m['n']:>6}{m['turn']:>7.1%}{m['net']:>+10.3%}"
                    f"{m['ann']:>+9.2%}{m['dd']:>9.2%}{m['sharpe']:>9.3f}{m['ann_ex']:>+9.2%}\n")
        f.write("\n相对基准:\n")
        for name, m in rows[1:]:
            f.write(f"  {name}: 年化绝对 {m['ann'] - base['ann']:+.2%}, "
                    f"年化超额 {m['ann_ex'] - base['ann_ex']:+.2%}, "
                    f"夏普 {m['sharpe'] - base['sharpe']:+.3f}\n")
    print(f"\n报告已保存: {path}", flush=True)
    print(f"总耗时 {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
