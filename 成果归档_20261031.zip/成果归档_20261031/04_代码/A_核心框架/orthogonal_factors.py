"""正交因子层: 股东户数 + 资金流。

这两个维度是项目里唯一验证出**正向净收益增量**的新数据源:
    仅技术面            年化绝对 +5.83%, 回撤 -43.31%, 夏普 0.366
    + hl_chg_4q         年化绝对 +7.45% (+1.63), 回撤 -42.01%, 夏普 0.438
    + hl_chg_4q + 资金流 年化绝对 +8.10% (+2.27), 回撤 -41.80%, 夏普 0.467

设计原则:
  1. 优雅降级: 数据文件不存在时返回原 pool(不报错), 让老流程照常跑。
  2. 结果缓存: 因子构建 + 中性化耗时约 40s, 缓存成 pkl 复用。
  3. 单因子接入: 实测"只加 hl_chg_4q"优于"加全部股东因子",
     所以默认只启用经验证的组合, 而不是把新因子一股脑塞进去。

用法:
    from orthogonal_factors import attach_orthogonal_factors, ORTHO_FEATURES
    pool = attach_orthogonal_factors(pool, cache_dir)
"""
import os

import numpy as np
import pandas as pd

from cross_section import neutralize

# 经验证的组合: 股东户数只取同比变化, 资金流取 3 个核心比率
HL_FACTORS = ["hl_chg_q", "hl_chg_4q", "hl_level", "hl_speed"]
HL_USED = ["hl_chg_4q"]
MF_FACTORS = ["mf_main_ratio_20", "mf_main_ratio_5", "mf_small_ratio_20",
              "mf_divergence", "mf_trend"]
MF_USED = ["mf_main_ratio_20", "mf_main_ratio_5", "mf_divergence"]
ORTHO_FEATURES = HL_USED + MF_USED

MF_WINDOW = 20


def _build_holder(cache_dir):
    path = os.path.join(cache_dir, "_holder_number.csv")
    if not os.path.exists(path):
        return None
    h = pd.read_csv(path, parse_dates=["ann_date", "end_date"], dtype={"code": str})
    h = h.dropna(subset=["ann_date", "end_date"])
    h = h[(h["end_date"] >= "2010-01-01") & (h["end_date"] <= "2026-12-31")]
    h = h[h["end_date"] <= h["ann_date"] + pd.Timedelta(days=5)]   # 剔除脏报告期
    h = h[h["holder_num"] > 0]
    h = h.sort_values(["code", "end_date"]).drop_duplicates(["code", "end_date"], keep="last")
    g = h.groupby("code")["holder_num"]
    h["hl_level"] = np.log(h["holder_num"])
    h["hl_chg_q"] = h["hl_level"] - g.shift(1).apply(np.log)
    h["hl_chg_4q"] = h["hl_level"] - g.shift(4).apply(np.log)
    h["hl_speed"] = h["hl_chg_q"] - h["hl_chg_q"].shift(1)
    return h[["code", "ann_date"] + HL_FACTORS]


def _build_moneyflow(cache_dir):
    mf_path = os.path.join(cache_dir, "_moneyflow.csv")
    amt_path = os.path.join(cache_dir, "_amount.csv")
    if not (os.path.exists(mf_path) and os.path.exists(amt_path)):
        return None
    mf = pd.read_csv(mf_path, parse_dates=["date"], dtype={"code": str})
    amt = pd.read_csv(amt_path, parse_dates=["date"], dtype={"code": str})
    df = mf.merge(amt, on=["code", "date"], how="inner")
    df["amount_w"] = df["amount"] / 10.0          # 千元 -> 万元
    df = df[df["amount_w"] > 0]
    df["main_net"] = (df["buy_lg_amount"] + df["buy_elg_amount"]
                      - df["sell_lg_amount"] - df["sell_elg_amount"])
    df["small_net"] = df["buy_sm_amount"] - df["sell_sm_amount"]
    df["main_ratio"] = df["main_net"] / df["amount_w"]
    df["small_ratio"] = df["small_net"] / df["amount_w"]
    df = df.sort_values(["code", "date"])
    g = df.groupby("code")
    df["mf_main_ratio_20"] = g["main_ratio"].transform(
        lambda s: s.rolling(MF_WINDOW, min_periods=10).mean())
    df["mf_main_ratio_5"] = g["main_ratio"].transform(
        lambda s: s.rolling(5, min_periods=3).mean())
    df["mf_small_ratio_20"] = g["small_ratio"].transform(
        lambda s: s.rolling(MF_WINDOW, min_periods=10).mean())
    df["mf_divergence"] = df["mf_main_ratio_20"] - df["mf_small_ratio_20"]
    df["mf_trend"] = df["mf_main_ratio_5"] - df["mf_main_ratio_20"]
    return df[["code", "date"] + MF_FACTORS]


def _cache_key(pool, cache_dir):
    """缓存标识: pool 的日期范围 + 股票数 + 两个源文件的修改时间。

    否则用子集首次构建的缓存会被全量 pool 命中, 导致大面积缺失。
    """
    d0 = str(pd.to_datetime(pool["date"].min()).date())
    d1 = str(pd.to_datetime(pool["date"].max()).date())
    n = pool["code"].nunique()
    mt = []
    for fn in ("_holder_number.csv", "_moneyflow.csv", "_amount.csv"):
        p = os.path.join(cache_dir, fn)
        mt.append(str(int(os.path.getmtime(p))) if os.path.exists(p) else "0")
    return f"{d0}_{d1}_{n}_{'_'.join(mt)}"


def attach_orthogonal_factors(pool, cache_dir, verbose=True):
    """把股东户数 + 资金流因子合并到 pool, 并做行业+市值中性化。

    数据缺失时原样返回, 只打一行提示 —— 不阻塞主流程。
    """
    pkl = os.path.join(cache_dir, f"_ortho_{_cache_key(pool, cache_dir)}.pkl")
    if os.path.exists(pkl):
        f = pd.read_pickle(pkl)
        if verbose:
            print(f"  复用正交因子缓存: {len(f)} 行, {list(f.columns)}", flush=True)
    else:
        parts = [pool[["code", "date"]].copy()]
        holder = _build_holder(cache_dir)
        if holder is not None:
            parts.append(pd.merge_asof(
                pool[["code", "date"]].sort_values("date"), holder.sort_values("ann_date"),
                left_on="date", right_on="ann_date", by="code", direction="backward"))
        else:
            if verbose:
                print("  [跳过] 无 _holder_number.csv (运行 download_holders.py 获取)",
                      flush=True)
        mf = _build_moneyflow(cache_dir)
        if mf is not None:
            parts.append(pool[["code", "date"]].merge(mf, on=["code", "date"], how="left"))
        else:
            if verbose:
                print("  [跳过] 无 _moneyflow.csv / _amount.csv "
                      "(运行 download_moneyflow.py + download_amount.py 获取)", flush=True)
        f = parts[0]
        for extra in parts[1:]:
            drop = [c for c in extra.columns if c in f.columns and c not in ("code", "date")]
            f = f.merge(extra.drop(columns=drop), on=["code", "date"], how="left")
        f = f.drop(columns=["ann_date"], errors="ignore")
        f.to_pickle(pkl)
        if verbose:
            print(f"  正交因子已构建并缓存: {list(f.columns)}", flush=True)

    out = pool.merge(f, on=["code", "date"], how="left")
    avail = [c for c in ORTHO_FEATURES if c in out.columns and out[c].notna().mean() > 0.3]
    if not avail:
        if verbose:
            print("  正交因子覆盖率过低, 不启用", flush=True)
        return pool

    # 中性化前提: 需要 log_mcap(市值) 与 industry(行业)。
    # 缺了就必须报错而不是静默跳过 —— 不做中性化的因子会带着 size/行业暴露,
    # 那样它就不是"正交因子"了, 接进模型反而有害。
    missing = [c for c in ("log_mcap", "industry") if c not in out.columns]
    if missing:
        raise RuntimeError(
            f"attach_orthogonal_factors 需要 {missing}, 但 pool 里没有。"
            f"请先调用 attach_fundamentals_ts(pool, cache_dir) 再调本函数。"
        )
    out = neutralize(out, avail)
    if verbose:
        for c in avail:
            print(f"    {c}: 覆盖 {out[c].notna().mean():.2%}", flush=True)
    return out
