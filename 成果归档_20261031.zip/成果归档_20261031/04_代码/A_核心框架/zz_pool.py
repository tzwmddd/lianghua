"""中证500/1000 可执行口径的数据层(实验版, 与现有 backtest_zz.py 并存对照)。

相对旧口径修正两处(见 评审_中证5001000_可提升方向.txt P0-1/P0-2):

  1. 交易时点: 旧口径在 t 日收盘"既算特征又按该收盘价成交", 等价于 T+0 收盘成交。
     新口径: t 日收盘出信号 -> **t+1 开盘买入** -> **t+1+H 开盘卖出**。
     标签 stock_fwd = open[t+1+H] / open[t+1] - 1。

  2. 退市/停牌股收尾: 旧口径里"信号日之后不足 H 个交易日"的样本被 dropna 整条删掉,
     等于假设这些股票从不被持有 —— 审计显示真正停止交易的股票最后 30 个交易日
     平均跌 63%, 被删样本用最后可得价结算平均 -27.9%/30日。
     新口径: 用**最后可得的开盘价**结算, 并打 censored 标记, 样本不再消失。

另新增涨停不可买/跌停不可卖的可执行性过滤(审计: 日均 1.35% 股票封涨停)。

用法:
    from zz_pool import build_pool, apply_constituents
    pool = build_pool("cache_zz1000", H=30)
"""
import glob
import os

import numpy as np
import pandas as pd

from config import FORECAST_HORIZON
from data import load_cached
from features import build_features, FEATURE_COLS
from cross_section import neutralize
from fundamental_ts import attach_fundamentals_ts

EXCESS_WINDOWS = [5, 20, 60]
BASE_FEATURES = FEATURE_COLS + [f"excess_{n}" for n in EXCESS_WINDOWS]


def limit_pct(code):
    """按板块返回涨跌幅限制比例。创业板/科创板 20%, 北交所 30%, 其余 10%。"""
    c = str(code).zfill(6)
    if c.startswith(("300", "301", "688", "689")):
        return 0.20
    if c.startswith(("4", "8", "920")):
        return 0.30
    return 0.10


def add_tradability(df, code):
    """逐日涨跌停标记(用前复权价的比例关系判定, 不受复权基准影响)。

    新增列:
      up_limit   收盘触及涨停(当日买不进)
      dn_limit   收盘触及跌停(当日卖不出)
      open_up    t+1 开盘即封涨停(开盘买不进)
    """
    lim = limit_pct(code)
    prev_close = df["close"].shift(1)
    chg = df["close"] / prev_close - 1.0
    open_chg = df["open"] / prev_close - 1.0
    tol = 0.002  # 容差: 吸收前复权四舍五入
    df["up_limit"] = (chg >= lim - tol).fillna(False)
    df["dn_limit"] = (chg <= -(lim - tol)).fillna(False)
    # t+1 开盘封涨停: 用下一行 open 判断(即"信号日之后一天能不能买进")
    df["open_up"] = (open_chg >= lim - tol).fillna(False).shift(-1).fillna(False)
    return df


def settle_forward(df, horizon):
    """结算未来收益, 同时给出两套成交口径。

    新增列:
      stock_fwd / buy_px / sell_px   : **开盘口径**(t+1 开盘买 -> t+1+H 开盘卖)
      stock_fwd_close / buy_px_close / sell_px_close : 收盘口径(t 收盘买 -> t+H 收盘卖)
      censored      : 持仓期内数据中断(退市/长期停牌), 用最后可得价收尾
      tradable_buy  : t+1 开盘是否可买(False = 开盘即封涨停)
    """
    n = len(df)
    open_ = df["open"].to_numpy(dtype=float)
    close_ = df["close"].to_numpy(dtype=float)
    idx = np.arange(n)

    def settle(px, buy_i, sell_i):
        """buy_i/sell_i 为位置数组; 越界用最后可得价收尾。返回 (fwd, buy_px, sell_px, censored)"""
        fwd = np.full(n, np.nan)
        bp = np.full(n, np.nan)
        sp = np.full(n, np.nan)
        cen = np.zeros(n, dtype=bool)
        ok = (buy_i >= 0) & (buy_i <= n - 1)
        normal = ok & (sell_i <= n - 1)
        fwd[normal] = px[sell_i[normal]] / px[buy_i[normal]] - 1.0
        bp[normal] = px[buy_i[normal]]
        sp[normal] = px[sell_i[normal]]
        tail = ok & (sell_i > n - 1)
        last = n - 1
        fwd[tail] = px[last] / px[buy_i[tail]] - 1.0
        bp[tail] = px[buy_i[tail]]
        sp[tail] = px[last]
        cen[tail] = True
        return fwd, bp, sp, cen

    fwd, bp, sp, cen = settle(open_, idx + 1, idx + 1 + horizon)
    fwd_c, bp_c, sp_c, cen_c = settle(close_, idx, idx + horizon)

    df = df.copy()
    df["stock_fwd"] = fwd
    df["buy_px"] = bp
    df["sell_px"] = sp
    df["censored"] = cen
    df["stock_fwd_close"] = fwd_c
    df["buy_px_close"] = bp_c
    df["sell_px_close"] = sp_c
    df["tradable_buy"] = ((idx + 1) <= n - 1) & ~df["open_up"].to_numpy()
    return df


def _index_forward_maps(cache_dir, horizon):
    """信号日 -> 指数未来收益, 返回 (开盘口径, 收盘口径)。

    开盘口径: [t+1 开盘, t+1+H 开盘]    (对应 t+1 开盘成交)
    收盘口径: [t 收盘, t+H 收盘]        (对应旧口径 T+0 收盘成交)
    """
    idx = pd.read_csv(os.path.join(cache_dir, "index.csv"), parse_dates=["date"])
    idx = idx.sort_values("date").reset_index(drop=True)
    dates = idx["date"].to_numpy()
    op = idx["open"].to_numpy(dtype=float)
    cl = idx["close"].to_numpy(dtype=float)
    n = len(op)
    caches = ({}, {})

    def make(kind):
        cache = caches[kind]

        def lookup(t):
            key = t
            if key in cache:
                return cache[key]
            p = int(np.searchsorted(dates, np.datetime64(t), side="right")) - 1
            if p < 0 or p + 1 > n - 1 or not np.isfinite(op[p + 1]):
                cache[key] = np.nan
                return np.nan
            if kind == 0:
                buy, buy_i = op, p + 1
            else:
                buy, buy_i = cl, p
            sell_i = min(buy_i + horizon, n - 1)
            val = buy[sell_i] / buy[buy_i] - 1.0 if buy[buy_i] > 0 else np.nan
            cache[key] = val
            return val

        return lookup

    return make(0), make(1)


def build_pool(cache_dir, horizon=FORECAST_HORIZON, verbose=True):
    """构建可执行口径的股票池。

    列: date/open/close/特征/excess_*/target_rel/excess_fwd/stock_fwd/
        censored(持有期内退市收尾)/tradable_buy(t+1 可否买入)/turnover(流动性)
    """
    idx_lookup, idx_lookup_c = _index_forward_maps(cache_dir, horizon)

    codes = sorted(
        os.path.splitext(os.path.basename(f))[0]
        for f in glob.glob(os.path.join(cache_dir, "*.csv"))
        if os.path.splitext(os.path.basename(f))[0].isdigit()
    )

    parts = []
    for code in codes:
        raw = load_cached(code, cache_dir)
        if raw is None or len(raw) < 120:
            continue
        feat = build_features(raw, horizon)
        if len(feat) < 60:
            continue
        # build_features 已 dropna 掉前 60 天预热期; 用 date 对齐回原始 OHLC
        raw_idx = raw.set_index("date")
        feat = feat.set_index("date")
        for col in ["open", "high", "low", "volume"]:
            feat[col] = raw_idx[col].reindex(feat.index)
        feat = feat.reset_index()
        feat["code"] = code

        feat = add_tradability(feat, code)
        feat = settle_forward(feat, horizon)
        feat["idx_fwd"] = [idx_lookup(d) for d in feat["date"].to_numpy()]
        feat["idx_fwd_close"] = [idx_lookup_c(d) for d in feat["date"].to_numpy()]
        feat["_ret"] = raw_idx["close"].pct_change().reindex(feat["date"]).to_numpy()
        parts.append(feat)

    # 指数日收益(用于超额窗口), 按信号日 map
    idx_df = pd.read_csv(os.path.join(cache_dir, "index.csv"), parse_dates=["date"])
    idx_df = idx_df.sort_values("date").set_index("date")
    idx_ret = idx_df["close"].pct_change()

    frames = []
    for feat in parts:
        feat["idx_ret"] = feat["date"].map(idx_ret).to_numpy()
        # 用 cumsum 差值做滚动和, 避免跨股票边界污染
        cs_ret = pd.Series(feat["_ret"].to_numpy()).cumsum()
        cs_idx = pd.Series(feat["idx_ret"].to_numpy()).cumsum()
        for n in EXCESS_WINDOWS:
            feat[f"excess_{n}"] = (cs_ret - cs_ret.shift(n)).to_numpy() - \
                                  (cs_idx - cs_idx.shift(n)).to_numpy()
        feat["excess_fwd"] = feat["stock_fwd"] - feat["idx_fwd"]
        feat["excess_fwd_close"] = feat["stock_fwd_close"] - feat["idx_fwd_close"]
        tgt = np.full(len(feat), np.nan)
        m = feat["excess_fwd"].notna().to_numpy()
        tgt[m] = (feat.loc[m, "excess_fwd"] > 0).astype(float)
        feat["target_rel"] = tgt
        tgt_c = np.full(len(feat), np.nan)
        mc = feat["excess_fwd_close"].notna().to_numpy()
        tgt_c[mc] = (feat.loc[mc, "excess_fwd_close"] > 0).astype(float)
        feat["target_rel_close"] = tgt_c
        frames.append(feat.drop(columns=["_ret"]))

    pool = pd.concat(frames, ignore_index=True)

    # 合并近 20 日均换手率(点-in-time 流动性)
    db_path = os.path.join(cache_dir, "_daily_basic.csv")
    if os.path.exists(db_path):
        db = pd.read_csv(db_path, parse_dates=["date"], dtype={"code": str})
        db = db.sort_values(["code", "date"])
        db["turnover"] = db.groupby("code")["turnover_rate"].transform(
            lambda s: s.rolling(20, min_periods=10).mean()
        )
        pool = pool.merge(db[["code", "date", "turnover"]], on=["code", "date"], how="left")

    pool = attach_fundamentals_ts(pool, cache_dir)
    pool = neutralize(pool, BASE_FEATURES)
    pool = pool.sort_values("date").reset_index(drop=True)

    if verbose:
        n = len(pool)
        nt = int(pool["censored"].sum())
        nu = int((~pool["tradable_buy"]).sum())
        print(f"  build_pool: {n} 条, {pool['code'].nunique()} 只, "
              f"收尾结算(退市/停牌) {nt} 条 ({nt / n:.2%}), "
              f"t+1 开盘封涨停不可买 {nu} 条 ({nu / n:.2%})", flush=True)
    return pool


def apply_constituents(pool, cache_dir):
    """点-in-time 成分过滤(与 backtest_zz.apply_constituents 同逻辑)。"""
    cons = pd.read_csv(os.path.join(cache_dir, "_constituents.csv"),
                       parse_dates=["snapshot_date"], dtype={"code": str})
    snap_dates = pd.to_datetime(sorted(cons["snapshot_date"].unique()))
    pool = pool.sort_values("date").copy()
    i = np.searchsorted(snap_dates.values, pool["date"].to_numpy(), side="right") - 1
    i = np.clip(i, 0, len(snap_dates) - 1)
    pool["snap_date"] = snap_dates.values[i]
    pool = pool.merge(cons, left_on=["snap_date", "code"],
                      right_on=["snapshot_date", "code"], how="inner")
    return pool.drop(columns=["snap_date", "snapshot_date"]).sort_values("date").reset_index(drop=True)
