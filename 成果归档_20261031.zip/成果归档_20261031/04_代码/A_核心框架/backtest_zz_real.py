"""中证500/1000 可执行口径回测(去水分版): 与旧口径并存对照。

新口径三处修正(见 zz_pool.py 与 评审_中证5001000_可提升方向.txt):
  1. t+1 开盘买入 / t+1+H 开盘卖出(旧口径是 T+0 收盘价成交)
  2. 退市/停牌股用最后可得价结算, 不再整条删除
  3. t+1 开盘封涨停的股票剔除(实盘买不进)

另加逐日盯市净值(旧口径只在调仓日取值, 回撤偏乐观)。

用法:
  python backtest_zz_real.py 1000                    # 默认持有30天, 无缓冲
  python backtest_zz_real.py 1000 --horizon 60 --buffer 0.5
  python backtest_zz_real.py 1000 --compare          # 与旧口径并排对照
"""
import argparse
import os
import sys
import time
import warnings

import numpy as np
import pandas as pd
import lightgbm as lgb

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

from config import RESULTS_DIR, SEED, EMBARGO_DAYS
from data import load_cached
from zz_pool import build_pool, apply_constituents, BASE_FEATURES

warnings.filterwarnings("ignore")

UNIVERSES = {
    "500": ("000905.SH", "cache_zz500", 0.004),
    "1000": ("000852.SH", "cache_zz1000", 0.005),
}
TEST_START = "2017-01-01"
TOP_FRAC = 0.2
LIQUIDITY_DROP = 0.2
MIN_TRAIN = 5000
MIN_CROSS = 30


def train_model(train, features):
    model = lgb.LGBMClassifier(
        n_estimators=150, learning_rate=0.10, num_leaves=63,
        subsample=0.8, colsample_bytree=0.8,
        random_state=SEED, verbosity=-1, n_jobs=-1,
    )
    model.fit(train[features].to_numpy(), train["target_rel"].to_numpy())
    return model


def run_real(pool, horizon, buffer_frac, cost_per_turn, use_tradable=True,
             keep_censored=True, features=None, weight_scheme="equal"):
    """可执行口径回测。

    buffer_frac: 换手缓冲带宽(占候选池比例)。等于 TOP_FRAC 时等价于无缓冲。
    keep_censored: True=退市股用最后可得价结算(新口径); False=直接删除(旧口径近似)。
    use_tradable: 是否剔除 t+1 开盘封涨停的股票。
    """
    features = features or BASE_FEATURES
    dates = sorted(pool["date"].unique())
    start_idx = next(i for i, d in enumerate(dates) if d >= pd.Timestamp(TEST_START))
    rebal_dates = dates[start_idx::horizon]

    net_list, gross_list, excess_list, turn_list, dates_used = [], [], [], [], []
    n_hold_list, cens_list, upskip_list, holds = [], [], [], []
    prev_hold = set()

    for t in rebal_dates:
        cutoff = t - pd.Timedelta(days=EMBARGO_DAYS)
        train = pool[pool["date"] < cutoff].dropna(subset=features)
        train = train[train["target_rel"].notna()]
        if not keep_censored:
            train = train[~train["censored"]]
        if len(train) < MIN_TRAIN:
            continue

        model = train_model(train, features)

        cross = pool[pool["date"] == t].dropna(subset=features)
        if keep_censored:
            cross = cross[cross["stock_fwd"].notna()]
        else:
            cross = cross[cross["stock_fwd"].notna() & (~cross["censored"])]
        if len(cross) < MIN_CROSS:
            continue

        # 流动性过滤
        if "turnover" in cross.columns and cross["turnover"].notna().sum() > 10:
            thresh = cross["turnover"].quantile(LIQUIDITY_DROP)
            cross = cross[cross["turnover"] >= thresh]

        n_liquid = len(cross)
        k = max(1, int(n_liquid * TOP_FRAC))
        buffer_k = max(k, int(n_liquid * buffer_frac))

        prob = model.predict_proba(cross[features].to_numpy())[:, 1]
        cross = cross.copy()
        cross["prob"] = prob
        cross = cross.sort_values("prob", ascending=False)

        # 可执行性: t+1 开盘封涨停的买不进
        if use_tradable:
            blocked = set(cross.loc[~cross["tradable_buy"].astype(bool), "code"])
            n_up = int((~cross["tradable_buy"].astype(bool)).sum())
        else:
            blocked, n_up = set(), 0
        buyable = cross[~cross["code"].isin(blocked)]

        # 换手缓冲: 旧持仓中仍排在 buffer_k 之内的保留
        buffer_codes = set(cross.head(buffer_k)["code"])
        keep = [c for c in prev_hold if c in buffer_codes and c not in blocked]
        final = keep[:k]
        for c in buyable["code"]:
            if len(final) >= k:
                break
            if c not in final:
                final.append(c)
        hold = set(final)

        held = cross[cross["code"].isin(hold)]
        if len(held) == 0:
            continue

        # 概率加权(实测优于等权): Q5 内部按概率映射到 [0.5,1.5] 再归一化
        if weight_scheme == "prob" and len(held) > 1:
            p = held["prob"].to_numpy(dtype=float)
            if p.max() > p.min():
                w = 0.5 + (p - p.min()) / (p.max() - p.min())
                w = w / w.sum()
            else:
                w = np.full(len(held), 1.0 / len(held))
        else:
            w = np.full(len(held), 1.0 / len(held))
        gross = float(np.dot(w, held["stock_fwd"].to_numpy()))
        excess = float(np.dot(w, held["excess_fwd"].to_numpy()))
        cens_share = held["censored"].mean()
        turnover = len(hold - prev_hold) / len(hold) if prev_hold else 1.0
        prev_hold = hold

        net = gross - turnover * cost_per_turn
        net_list.append(net)
        gross_list.append(gross)
        excess_list.append(excess)
        turn_list.append(turnover)
        dates_used.append(t)
        n_hold_list.append(len(held))
        cens_list.append(cens_share)
        upskip_list.append(n_up)
        holds.append(sorted(hold))

    return {
        "dates": dates_used, "holds": holds,
        "net": np.array(net_list), "gross": np.array(gross_list),
        "excess": np.array(excess_list), "turnover": np.array(turn_list),
        "n_hold": n_hold_list, "cens_share": np.array(cens_list),
        "n_blocked": upskip_list, "prev_hold": prev_hold,
    }


def daily_nav(cache_dir, r, cost_per_turn=0.0):
    """逐日盯市净值: 每期持仓等权, 期内按个股日收盘价相对期初盯市。

    旧口径只在调仓日取样(77 个点), 会低估回撤。这里还原日频曲线:
      - 调仓日 t 为基准, 期内每日计算 收盘价/基准价 - 1
      - 退市股票在其最后一日之后价格前向填充(等价于用最后可得价结算), 之后收益为 0
      - 期初扣一次换手成本
    返回 (日频净值 Series, 最大回撤, 日频年化夏普, 日频年化收益)。
    """
    dts = r["dates"]
    if len(dts) < 2:
        return None, np.nan, np.nan, np.nan
    t_start, t_end = dts[0], dts[-1] + pd.Timedelta(days=1)

    need = set()
    for h in r["holds"]:
        need.update(h)
    px = {}
    for code in need:
        df = load_cached(code, cache_dir)
        if df is None or len(df) == 0:
            continue
        df = df[(df["date"] >= t_start) & (df["date"] <= t_end)]
        if len(df) < 2:
            continue
        px[code] = df.set_index("date")["close"]
    if not px:
        return None, np.nan, np.nan, np.nan

    mat = pd.DataFrame(px).sort_index().ffill()
    rets = mat.pct_change()          # 日收益, 用日频复利(不能用"期初至今累计收益")

    segs = []
    for i, t in enumerate(dts[:-1]):
        t_next = dts[i + 1]
        hold = [c for c in r["holds"][i] if c in rets.columns]
        if not hold:
            continue
        win = rets.loc[(rets.index > t) & (rets.index <= t_next), hold]
        if len(win) == 0:
            continue
        port = win.mean(axis=1)      # 等权组合日收益
        port.iloc[0] -= r["turnover"][i] * cost_per_turn
        segs.append(port)
    if not segs:
        return None, np.nan, np.nan, np.nan
    port_ret = pd.concat(segs).sort_index()
    nav = (1 + port_ret).cumprod()
    dd = float((nav / nav.cummax() - 1).min())
    sh = (port_ret.mean() / port_ret.std(ddof=1) * np.sqrt(252)
          if port_ret.std(ddof=1) > 0 else np.nan)
    ann = (nav.iloc[-1] ** (252 / len(port_ret)) - 1) if len(port_ret) else np.nan
    return nav, dd, sh, ann


def report(universe, index_code, horizon, buffer_frac, r, cost_per_turn, cache_dir):
    net = r["net"]
    nav_vals = np.cumprod(1 + net)
    nav = float(nav_vals[-1])
    n = len(net)
    ann_abs = nav ** (252 / (n * horizon)) - 1
    ann_ex = (1 + r["excess"].mean()) ** (252 / horizon) - 1
    dd = float((nav_vals / np.maximum.accumulate(nav_vals) - 1).min())
    sh = (net.mean() / net.std(ddof=1) * np.sqrt(252 / horizon)) if net.std(ddof=1) > 0 else np.nan

    _, dd_d, sh_d, ann_d = daily_nav(cache_dir, r, cost_per_turn)

    lines = [
        f"=== 中证{universe} 可执行口径回测 ===",
        f"  指数 {index_code}, 持有/调仓 {horizon} 交易日, 缓冲带 {buffer_frac:.0%}, 期数 {n}",
        f"  成交口径: t+1 开盘买入 -> t+1+{horizon} 开盘卖出; embargo {EMBARGO_DAYS} 天",
        f"  单次换手成本 {cost_per_turn:.2%}",
        f"  平均持仓 {np.mean(r['n_hold']):.0f} 只, 平均换手率 {r['turnover'].mean():.1%}/期, "
        f"t+1 开盘涨停被剔除 {np.mean(r['n_blocked']):.1f} 只/期",
        f"  Q5 毛收益/期 : {r['gross'].mean():+.3%}",
        f"  Q5 净收益/期 : {net.mean():+.3%}",
        f"  累计净值     : {nav:.4f}  年化(调仓日) {ann_abs:+.2%}",
        f"  年化超额(几何): {ann_ex:+.2%}  (算术均值 {r['excess'].mean():+.3%}/期, "
        f"胜率 {(r['excess'] > 0).mean():.1%})",
        f"  夏普(调仓日) : {sh:.3f}   夏普(日频) {sh_d:.3f}",
        f"  最大回撤     : 调仓日采样 {dd:.2%}   逐日盯市 {dd_d:.2%}",
        f"  逐日盯市年化 : {ann_d:+.2%}",
        f"  持有期内退市收尾样本占比: {r['cens_share'].mean():.3%}/期",
    ]
    print("\n" + "\n".join(lines), flush=True)
    return lines, ann_abs, ann_ex, sh, dd_d


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("universe", nargs="?", default="1000", choices=["500", "1000"])
    ap.add_argument("--horizon", type=int, default=30)
    ap.add_argument("--buffer", type=float, default=0.2)
    ap.add_argument("--compare", action="store_true", help="与旧口径并排对照")
    args = ap.parse_args()

    universe = args.universe
    index_code, cache_dir, cost = UNIVERSES[universe]
    t0 = time.time()
    os.makedirs(RESULTS_DIR, exist_ok=True)

    print(f"构建可执行口径 pool (中证{universe}, H={args.horizon}) ...", flush=True)
    pool = build_pool(cache_dir, horizon=args.horizon)
    pool = apply_constituents(pool, cache_dir)
    print(f"  成分过滤后 {len(pool)} 条, {pool['code'].nunique()} 只", flush=True)

    all_lines = []
    r_real = run_real(pool, args.horizon, args.buffer, cost,
                      use_tradable=True, keep_censored=True)
    lines, ann_abs, ann_ex, sh, dd = report(universe, index_code, args.horizon,
                                            args.buffer, r_real, cost, cache_dir)
    all_lines += lines

    if args.compare:
        print("\n" + "-" * 70, flush=True)
        print("对照: 关闭两项修正(近似旧口径: T+0收盘成交 + 退市股直接删除)", flush=True)
        r_old = run_real(pool, args.horizon, args.buffer, cost,
                         use_tradable=False, keep_censored=False)
        lines_old, ann_abs_o, ann_ex_o, sh_o, dd_o = report(
            universe, index_code, args.horizon, args.buffer, r_old, cost, cache_dir)
        all_lines += ["", "=" * 70, "对照(关闭两项修正, 近似旧口径):", ""] + lines_old
        print("\n" + "=" * 70, flush=True)
        print("去水分影响:")
        print(f"  年化超额   {ann_ex_o:+.2%}  ->  {ann_ex:+.2%}   ({ann_ex - ann_ex_o:+.2%})")
        print(f"  年化绝对   {ann_abs_o:+.2%}  ->  {ann_abs:+.2%}   ({ann_abs - ann_abs_o:+.2%})")
        print(f"  回撤(日频) {dd_o:.2%}  ->  {dd:.2%}")
        all_lines += ["", f"去水分影响: 年化超额 {ann_ex_o:+.2%} -> {ann_ex:+.2%} "
                          f"({ann_ex - ann_ex_o:+.2%}), 年化绝对 {ann_abs_o:+.2%} -> {ann_abs:+.2%}, "
                          f"日频回撤 {dd_o:.2%} -> {dd:.2%}"]

    path = os.path.join(RESULTS_DIR,
                        f"backtest_zz{universe}_real_H{args.horizon}_b{int(args.buffer*100)}.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(all_lines) + "\n")
    print(f"\n报告已保存: {path}", flush=True)
    print(f"总耗时 {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
