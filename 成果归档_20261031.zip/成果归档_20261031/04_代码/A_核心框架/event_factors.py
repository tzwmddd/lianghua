"""事件型因子构建模块: 增减持 / 解禁 / 业绩预告 / 业绩快报。

独立成模块的原因: 因子构建 + 中性化耗时约 3 分钟, 而"逐个接入模型测净收益"
需要反复跑。抽出来之后可以构建一次、落盘缓存, 后续直接读。

设计原则:
  1. **点-in-time**: 一律用 ann_date 做 merge_asof(backward), 绝不用报告期。
     业绩预告/龙虎榜这类披露型数据尤其关键(公告日晚于报告期, 用报告期会前视)。
  2. **时间衰减**: 事件越久远权重越低(半衰期 HALFLIFE 天), 让"刚发生的"更重要。
  3. **比率化**: 用股本/市值归一化, 避免退化成 size 别名(项目已验证 size 是噪声)。
  4. **覆盖率**: 事件型因子天然稀疏(如解禁压力仅 4%), 评估时必须**逐因子独立
     取有效样本**, 不能对整个因子集 dropna。

用法:
    from event_factors import build_event_factors, EVENT_FEATURES
    pool = build_event_factors(pool, cache_dir)
"""
import os

import numpy as np
import pandas as pd

from cross_section import neutralize

HALFLIFE = 120              # 事件时间衰减半衰期(交易日)
FUTURE_WINDOW = 45          # 解禁压力: 向后看的窗口(自然日)

# 经实测筛选后启用的因子(见 报告 与 说明):
#   ht_* 有效(IC +0.018, ICIR +0.35, 与现有因子相关仅 -0.135)
#   fl_* 无效(IC 全在 ±0.003 内) —— 默认不启用, 保留代码备查
#   fc_* 待测
HT_FEATURES = ["ht_net_ratio", "ht_net_cnt"]
FL_FEATURES = ["fl_pressure", "fl_recent"]
FC_FEATURES = ["fc_type", "fc_pchg_mid", "fc_np_to_mv"]
EVENT_FEATURES = HT_FEATURES + FC_FEATURES      # 默认启用(解禁因子实测无效)

TYPE_SCORE = {
    "预增": 2.0, "略增": 1.0, "扭亏": 1.5, "续盈": 1.0,
    "不确定": 0.0,
    "略减": -1.0, "预减": -2.0, "首亏": -2.0, "续亏": -1.5,
}


def _asof(pool, ev, cols, ann="ann_date"):
    """把事件表按公告日点-in-time 合并到 pool(backward)。

    始终返回 ann_date —— 调用方要用它算事件年龄(时间衰减), 漏掉会 KeyError。
    """
    left = pool[["code", "date"]].sort_values("date")
    ev = ev.dropna(subset=[ann]).sort_values(ann)
    use = list(dict.fromkeys(cols + [ann]))
    return pd.merge_asof(left, ev, left_on="date", right_on=ann,
                         by="code", direction="backward")[use + ["code", "date"]]


def _decay(age_days):
    """自然日 -> 时间衰减权重(半衰期按交易日折算)。"""
    return 0.5 ** (age_days / (HALFLIFE * 365.0 / 252.0))


def build_holder_trade(cache_dir, pool):
    path = os.path.join(cache_dir, "_holder_trade.csv")
    if not os.path.exists(path):
        return pool, []
    ev = pd.read_csv(path, parse_dates=["ann_date"], dtype={"code": str})
    ev["change_vol"] = pd.to_numeric(ev["change_vol"], errors="coerce")
    ev = ev.dropna(subset=["change_vol"])
    up = ev["in_de"].astype(str).str.upper().str.startswith("IN")
    ev["signed_vol"] = np.where(up, ev["change_vol"], -ev["change_vol"])
    ev["buy_vol"] = np.where(up, ev["change_vol"], 0.0)

    m = _asof(pool, ev, ["signed_vol", "buy_vol", "ann_date"])
    age = (m["date"] - m["ann_date"]).dt.days
    w = _decay(age)
    # 临时列名必须带专属前缀: 多个 builder 都用 w_net 会导致 merge 时列名冲突,
    # pandas 会自动加 _x/_y 后缀, 后续按原名访问就 KeyError。
    m["ht_w_net"] = m["signed_vol"] * w
    m["ht_w_buy"] = m["buy_vol"] * w
    m["ht_w_cnt"] = np.sign(m["signed_vol"]) * w
    m = m[age <= 250]
    agg = m.groupby(["code", "date"], as_index=False)[
        ["ht_w_net", "ht_w_buy", "ht_w_cnt"]].sum()
    pool = pool.merge(agg, on=["code", "date"], how="left")

    if "mktcap" in pool.columns and "close" in pool.columns:
        shares = pool["mktcap"] * 1e8 / pool["close"].replace(0, np.nan)
        pool["ht_net_ratio"] = pool["ht_w_net"] / shares
        pool["ht_buy_ratio"] = pool["ht_w_buy"] / shares
    else:
        pool["ht_net_ratio"] = np.nan
        pool["ht_buy_ratio"] = np.nan
    pool["ht_net_cnt"] = pool["ht_w_cnt"]
    return pool, ["ht_net_ratio", "ht_buy_ratio", "ht_net_cnt"]


def build_share_float(cache_dir, pool):
    path = os.path.join(cache_dir, "_share_float.csv")
    if not os.path.exists(path):
        return pool, []
    ev = pd.read_csv(path, parse_dates=["ann_date", "float_date"], dtype={"code": str})
    # 注意: float_ratio 单位是**百分比**(22.38 表示 22.38%), 不是小数。
    # (float_date 用 parse_dates 解析是正确的; 之前用 dtype=str + to_datetime
    #  无 format, 会解析成 1970 年, 导致解禁过滤完全失效 —— 已修)
    ev["float_ratio"] = pd.to_numeric(ev["float_ratio"], errors="coerce") / 100.0
    ev = ev.dropna(subset=["float_date", "float_ratio"])

    # 未来解禁压力: 找 float_date 落在 (t, t+45] 的记录
    f = ev[["code", "float_date", "float_ratio"]].rename(
        columns={"float_date": "fdate", "float_ratio": "fratio"})
    m = pd.merge_asof(pool[["code", "date"]].sort_values("date"),
                      f.sort_values("fdate"), left_on="date", right_on="fdate",
                      by="code", direction="forward",
                      tolerance=pd.Timedelta(days=FUTURE_WINDOW))
    m["fl_pressure"] = m["fratio"]
    m["fl_days_away"] = (m["fdate"] - m["date"]).dt.days
    agg = m.groupby(["code", "date"], as_index=False)[["fl_pressure", "fl_days_away"]].min()
    pool = pool.merge(agg, on=["code", "date"], how="left")

    # 过去 90 天已解禁(注意: ann_date 之后才知道 -> 用 backward)
    p = ev[["code", "float_date", "float_ratio"]].rename(
        columns={"float_date": "pdate", "float_ratio": "pratio"})
    m2 = pd.merge_asof(pool[["code", "date"]].sort_values("date"),
                       p.sort_values("pdate"), left_on="date", right_on="pdate",
                       by="code", direction="backward",
                       tolerance=pd.Timedelta(days=120))
    m2["fl_recent"] = m2["pratio"]
    agg2 = m2.groupby(["code", "date"], as_index=False)[["fl_recent"]].sum()
    pool = pool.merge(agg2, on=["code", "date"], how="left")
    return pool, ["fl_pressure", "fl_days_away", "fl_recent"]


def build_forecast(cache_dir, pool):
    path = os.path.join(cache_dir, "_forecast.csv")
    if not os.path.exists(path):
        return pool, []
    ev = pd.read_csv(path, parse_dates=["ann_date"], dtype={"code": str})
    for c in ["p_change_min", "p_change_max", "net_profit_min", "net_profit_max"]:
        ev[c] = pd.to_numeric(ev[c], errors="coerce")
    ev["fc_type"] = ev["type"].map(TYPE_SCORE)
    ev["fc_pchg_mid"] = (ev["p_change_min"] + ev["p_change_max"]) / 2.0 / 100.0
    ev["fc_np_mid"] = (ev["net_profit_min"] + ev["net_profit_max"]) / 2.0   # 万元
    ev = ev.dropna(subset=["ann_date"]).sort_values(["code", "ann_date"])
    ev = ev.drop_duplicates(["code", "ann_date"], keep="last")

    m = _asof(pool, ev, ["fc_type", "fc_pchg_mid", "fc_np_mid", "ann_date"])
    age = (m["date"] - m["ann_date"]).dt.days
    w = _decay(age)
    m["fc_type"] = m["fc_type"] * w
    m["fc_pchg_mid"] = m["fc_pchg_mid"] * w
    m = m[age <= 250]
    agg = m.groupby(["code", "date"], as_index=False)[
        ["fc_type", "fc_pchg_mid", "fc_np_mid"]].last()
    pool = pool.merge(agg, on=["code", "date"], how="left")
    if "mktcap" in pool.columns:
        pool["fc_np_to_mv"] = pool["fc_np_mid"] / 1e4 / pool["mktcap"]
    else:
        pool["fc_np_to_mv"] = np.nan
    return pool, ["fc_type", "fc_pchg_mid", "fc_np_to_mv"]


def build_toplist(cache_dir, pool):
    """龙虎榜因子。

    **关键: 龙虎榜是盘后披露** —— trade_date 当天的席位数据在收盘后才公布,
    所以可交易时点是 t+1。这里把 trade_date 后移一个交易日再对齐(保守做法),
    否则会用到"当天还不知道的席位信息", 造成前视。

    因子:
      tl_net_ratio20  近 20 日均净买入额 / 成交额(龙虎榜资金净流入强度)
      tl_inst_net20   近 20 日均机构席位净买入 / 成交额
      tl_cnt60        近 60 天上榜次数(关注度; 次数多=博弈激烈)
      tl_buy_sell     近 20 日买卖席位金额比 - 1(正=买方更强)
    """
    p_list = os.path.join(cache_dir, "_top_list.csv")
    p_inst = os.path.join(cache_dir, "_top_inst.csv")
    if not os.path.exists(p_list):
        return pool, []
    # 统一用 parse_dates: 它会正确解析 8 位整数日期(20150105)。
    # 反例: pd.read_csv(dtype=str) + pd.to_datetime() 没有 format 时, 会把它
    # 当成纳秒时间戳解析成 1970 年 —— 这个坑在 share_float 上踩过一次。
    tl = pd.read_csv(p_list, parse_dates=["trade_date"], dtype={"code": str})
    tl = tl.dropna(subset=["trade_date"])
    for c in ["l_buy", "l_sell", "l_amount", "amount", "net_amount"]:
        if c in tl.columns:
            tl[c] = pd.to_numeric(tl[c], errors="coerce")
    # 盘后披露 -> 可用日 = trade_date 之后
    tl["avail"] = tl["trade_date"] + pd.Timedelta(days=1)
    tl = tl.sort_values("avail")

    cols = ["code", "avail"]
    m = _asof(pool, tl.rename(columns={"avail": "ann_date"}), ["l_buy", "l_sell", "amount"],
              ann="ann_date")
    age = (m["date"] - m["ann_date"]).dt.days
    w = _decay(age)
    m["tl_w_net"] = (m["l_buy"] - m["l_sell"]) * w          # 净买入(元)
    m["tl_w_amt"] = m["amount"] * w
    m["tl_w_bs"] = np.where(m["l_buy"] + m["l_sell"] > 0,
                            m["l_buy"] / (m["l_buy"] + m["l_sell"]).replace(0, np.nan) - 0.5,
                            0.0) * w
    m["tl_w_cnt"] = w
    m = m[age <= 60]
    agg = m.groupby(["code", "date"], as_index=False)[
        ["tl_w_net", "tl_w_amt", "tl_w_bs", "tl_w_cnt"]].sum()
    pool = pool.merge(agg, on=["code", "date"], how="left")
    pool["tl_net_ratio20"] = np.where(pool["tl_w_amt"] > 0,
                                      pool["tl_w_net"] / pool["tl_w_amt"], np.nan)
    pool["tl_buy_sell"] = pool["tl_w_bs"]
    pool["tl_cnt60"] = pool["tl_w_cnt"]

    # 机构席位
    if os.path.exists(p_inst):
        ti = pd.read_csv(p_inst, parse_dates=["trade_date"], dtype={"code": str})
        ti = ti.dropna(subset=["trade_date"])
        ti["net_buy"] = pd.to_numeric(ti["net_buy"], errors="coerce")
        ti["avail"] = ti["trade_date"] + pd.Timedelta(days=1)
        m2 = _asof(pool, ti.rename(columns={"avail": "ann_date"})[["code", "ann_date", "net_buy"]],
                   ["net_buy"], ann="ann_date")
        age2 = (m2["date"] - m2["ann_date"]).dt.days
        m2["tl_inst_net"] = m2["net_buy"] * _decay(age2)
        m2 = m2[age2 <= 60]
        agg2 = m2.groupby(["code", "date"], as_index=False)[["tl_inst_net"]].sum()
        pool = pool.merge(agg2, on=["code", "date"], how="left")
        pool["tl_inst_net20"] = pool["tl_inst_net"]
    else:
        pool["tl_inst_net20"] = np.nan
    return pool, ["tl_net_ratio20", "tl_inst_net20", "tl_cnt60", "tl_buy_sell"]


BUILDERS = [
    ("holder_trade", build_holder_trade),
    ("float", build_share_float),
    ("forecast", build_forecast),
    ("toplist", build_toplist),
]


def _cache_key(pool, cache_dir):
    """缓存标识: 事件源文件的时间戳 + pool 规模。

    否则数据更新后仍命中旧缓存, 或用子集构建的缓存被全量 pool 命中。
    """
    mt = []
    for fn in ("_holder_trade.csv", "_share_float.csv", "_forecast.csv"):
        p = os.path.join(cache_dir, fn)
        mt.append(str(int(os.path.getmtime(p))) if os.path.exists(p) else "0")
    d1 = str(pd.to_datetime(pool["date"].max()).date())
    return f"{d1}_{pool['code'].nunique()}_{'_'.join(mt)}"


def build_event_factors(pool, cache_dir, verbose=True, use_cache=True):
    """构建全部事件因子并做中性化。返回增强后的 pool(行数不变)。

    结果落盘缓存: 因子构建+中性化约 3 分钟, 而"逐因子测净收益"要反复跑。
    """
    pkl = os.path.join(cache_dir, f"_event_factors_{_cache_key(pool, cache_dir)}.pkl")
    if use_cache and os.path.exists(pkl):
        f = pd.read_pickle(pkl)
        if verbose:
            print(f"  复用事件因子缓存: {f.shape[1]-2} 列", flush=True)
        return pool.merge(f, on=["code", "date"], how="left")

    all_f = []
    for name, fn in BUILDERS:
        pool, fs = fn(cache_dir, pool)
        if verbose:
            print(f"  [{name}] {fs}", flush=True)
        all_f += fs
    avail = [f for f in all_f if f in pool.columns and pool[f].notna().mean() > 0.02]
    if not avail:
        if verbose:
            print("  无有效事件因子", flush=True)
        return pool
    pool = neutralize(pool, avail)
    if verbose:
        for f in avail:
            print(f"    {f:<16} 覆盖 {pool[f].notna().mean():6.2%}", flush=True)
    if use_cache:
        pool[["code", "date"] + avail].to_pickle(pkl)
    return pool
