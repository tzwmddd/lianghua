"""tushare 基础设施:token 管理、代码转换、限流重试。

token 读取顺序:环境变量 TUSHARE_TOKEN -> 本目录 tushare_token.txt。
不硬编码、不进 git(建议把 tushare_token.txt 加入 .gitignore)。
"""
import os
import random
import time


def _load_token():
    tok = os.environ.get("TUSHARE_TOKEN")
    if tok:
        return tok.strip()
    p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tushare_token.txt")
    if os.path.exists(p):
        with open(p, encoding="utf-8") as f:
            return f.read().strip()
    raise RuntimeError(
        "未找到 token: 请设置环境变量 TUSHARE_TOKEN, 或在本目录建 tushare_token.txt"
    )


def get_pro():
    """返回 tushare pro 接口对象。

    直接把 token 传给 pro_api, 不依赖 ts.set_token() 的全局缓存
    (set_token 会往用户目录写 tk.csv, 在受限环境下会失败)。
    """
    import tushare as ts
    token = _load_token()
    try:
        return ts.pro_api(token)
    except Exception:
        ts.set_token(token)
        return ts.pro_api()


def to_ts_code(code):
    """6 位数字代码 -> tushare ts_code(600000.SH / 000001.SZ / 8xxxxx.BJ)。"""
    code = str(code).zfill(6)
    if code.startswith("920"):
        return code + ".BJ"
    if code.startswith("6"):
        return code + ".SH"
    if code.startswith(("0", "3")):
        return code + ".SZ"
    if code.startswith(("4", "8")):
        return code + ".BJ"
    return code + ".SH"


def to_code(ts_code):
    """ts_code -> 6 位数字代码。"""
    return str(ts_code).split(".")[0].zfill(6)


def _retry(fn, retries=3, delay=(1.0, 2.0)):
    """随机延时 + 指数退避,缓解 tushare 限流。"""
    last = None
    for i in range(retries):
        try:
            return fn()
        except Exception as e:  # noqa: BLE001
            last = e
            if i < retries - 1:
                time.sleep(random.uniform(*delay) * (i + 1))
    raise last


def sleep(seconds):
    time.sleep(seconds)
