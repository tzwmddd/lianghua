"""可执行性审计:检验纯多头回测是否高估了收益。

检验三件事(全部只需现有缓存,不改任何模型):
  1. 涨停买不进:调仓日 Q5 里有多少比例的股票当日涨停/接近涨停
     (以 t 日收盘价买入 = 假设能在涨停板上成交,实盘买不到)。
  2. 退市股被系统性剔除:标签 stock_fwd = close.shift(-30)/close - 1,
     持仓期内退市 -> shift 得到 NaN -> dropna 把这条样本删掉,
     等于"退市股自动不持有",是幸存者偏差的残留。
  3. 停牌造成的收益断裂:持仓期内交易日缺口。

用法: python audit_executability_zz.py [500|1000]
"""
import os
import sys

import numpy as np
import pandas as pd

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

from config import FORECAST_HORIZON, RESULTS_DIR
from backtest_zz import load_pool, apply_constituents

UNIVERSES = {
    "500": ("000905.SH", "cache_zz500"),
    "1000": ("000852.SH", "cache_zz1000"),
}
LIMIT_TOL = 0.005  # 与理论涨跌停价相对误差 <0.5% 视为封板


def main():
    universe = sys.argv[1] if len(sys.argv) > 1 else "1000"
    index_code, cache_dir = UNIVERSES[universe]
    H = FORECAST_HORIZON

    pool = load_pool(cache_dir)
    pool = apply_constituents(pool, cache_dir)
    pool = pool.sort_values(["code", "date"]).reset_index(drop=True)

    # ---- 涨跌停标记(用 tushare 不复权原始价反推不现实,这里用前复权序列近似)----
    # 前复权价的比例关系与原始价一致(同一因子),涨跌幅不受影响。
    g = pool.groupby("code", group_keys=False)
    pool["pre_close"] = g["close"].shift(1)
    pool["high_limit"] = (pool["pre_close"] * 1.10).round(2)
    pool["low_limit"] = (pool["pre_close"] * 0.90).round(2)
    pool["up_limit"] = (pool["close"] - pool["high_limit"]).abs() / pool["high_limit"] < LIMIT_TOL
    pool["dn_limit"] = (pool["close"] - pool["low_limit"]).abs() / pool["low_limit"] < LIMIT_TOL

    # ---- 持仓期内交易日缺口 ----
    # 用个股自身在 pool 中的行号差衡量: 如果 t 之后 30 个交易日的记录存在, 行号差应为 H
    pool["row_in_code"] = pool.groupby("code").cumcount()
    pool["n_obs"] = pool.groupby("code")["date"].transform("size")
    pool["last_date"] = pool.groupby("code")["date"].transform("max")
    pool["is_last_obs"] = pool["row_in_code"] == pool["n_obs"] - 1

    # ---- 1. 调仓日 Q5 的涨停比例 ----
    # 用 target_rel 存在(= 有完整 30 日未来收益)的样本, 按日期看当日涨停占比
    valid = pool[pool["target_rel"].notna()]
    day = valid.groupby("date").agg(
        n=("code", "size"),
        up_ratio=("up_limit", "mean"),
        dn_ratio=("dn_limit", "mean"),
    )
    print(f"\n=== 中证{universe} 可执行性审计 ===", flush=True)
    print(f"池子 {len(pool)} 条, 成分过滤后, 覆盖 {pool['code'].nunique()} 只, "
          f"{valid['date'].nunique()} 个交易日", flush=True)
    print(f"\n[1] 全样本中当日涨停比例: {valid['up_limit'].mean():.2%}, "
          f"跌停比例: {valid['dn_limit'].mean():.2%}", flush=True)
    print(f"    平均每天有 {day['up_ratio'].mean():.2%} 的股票封涨停 "
          f"(横截面中位数 {day['up_ratio'].median():.2%})", flush=True)

    # ---- 2. 退市/长停牌: 持仓期内未来收益缺失 ----
    # 对每个 (code, t): 若 t 之后交易日不足 H 天 -> 标签 NaN -> 回测中该股被剔除
    print(f"\n[2] 退市/停牌股在持仓期内被静默剔除(幸存者偏差残留)", flush=True)
    pool["rows_left"] = pool["n_obs"] - 1 - pool["row_in_code"]
    # 真正的偏差: 该股后续没有数据可用(退市/长期停牌), 该调仓日样本被 dropna 删除。
    # 注意 pool 经 apply_constituents 过滤, 已退市股不会出现在退市后的快照里,
    # 所以这里统计的正是"退市前还挂着、买进去就再没有数据"的样本。
    trunc = pool[pool["rows_left"] < H].copy()
    trunc["last_month"] = trunc["last_date"].dt.to_period("M").astype(str)
    test_trunc = trunc[trunc["date"] >= pd.Timestamp("2017-01-01")]
    print(f"    全部被剔除样本(后续不足{H}个交易日): {len(trunc)} 条, "
          f"占池子 {len(trunc) / len(pool):.2%}, 涉及 {trunc['code'].nunique()} 只", flush=True)
    print(f"    其中落在回测期(2017 起): {len(test_trunc)} 条, "
          f"{test_trunc['code'].nunique()} 只", flush=True)

    # 按年看被剔除的"退市股末段"样本(最后记录日所在年)
    tail_codes = trunc.groupby("code")["date"].agg(["min", "max"])
    died = tail_codes[tail_codes["max"] < pool["date"].max() - pd.Timedelta(days=90)]
    print(f"    其中最后记录日早于数据末端 90 天(真退市/摘牌): {len(died)} 只", flush=True)
    if len(died):
        byyear = died["max"].dt.year.value_counts().sort_index()
        print(f"    退市只数按年: {dict(byyear)}", flush=True)

    # 6. 被剔除样本占比的年度趋势 + 反事实影响
    per_year = pool.groupby(pool["date"].dt.year).size()
    drop_year = trunc.groupby(trunc["date"].dt.year).size()
    print(f"    被剔除样本占当年池子比例:", flush=True)
    for y in sorted(set(per_year.index) & set(drop_year.index)):
        if y < 2017:
            continue
        print(f"      {y}: {drop_year[y] / per_year[y]:.2%} ({drop_year[y]} 条)", flush=True)

    # ---- 3. 停牌缺口 ----
    print(f"\n[3] 停牌缺口", flush=True)
    pool["gap"] = pool.groupby("code")["date"].diff().dt.days
    big_gap = pool[pool["gap"] > 10]
    print(f"    相邻记录间隔 >10 自然日的样本: {len(big_gap)} 条, "
          f"{big_gap['code'].nunique()} 只, 占比 {len(big_gap) / len(pool):.2%}", flush=True)

    # ---- 4. 数据起点: 训练集到底有多长 ----
    print(f"\n[4] 数据起点/训练窗", flush=True)
    print(f"    pool 日期范围 {pool['date'].min().date()} ~ {pool['date'].max().date()}", flush=True)
    per_date = pool.groupby("date").size()
    print(f"    横截面规模: 期初 {per_date.iloc[:5].mean():.0f} 只 -> "
          f"期末 {per_date.iloc[-5:].mean():.0f} 只", flush=True)
    print(f"    2017-01 之前(可用于首期训练)的交易日: "
          f"{(per_date.index < pd.Timestamp('2017-01-01')).sum()} 天", flush=True)

    # ---- 5. Q5 的涨停暴露 (需要模型, 这里用动量代理近似) ----
    print(f"\n[5] 提示: 涨停股在动量类因子上排名靠前, 会被 Q5 优先选中。", flush=True)
    print(f"    当日涨停股的平均未来{H}日收益: {valid.loc[valid['up_limit'], 'stock_fwd'].mean():+.3%} "
          f"vs 全体 {valid['stock_fwd'].mean():+.3%}", flush=True)
    print(f"    当日跌停股的平均未来{H}日收益: {valid.loc[valid['dn_limit'], 'stock_fwd'].mean():+.3%}", flush=True)

    # ---- 6. 缓存末日分布: 多少股票的数据没更到最新 ----
    print(f"\n[6] 个股缓存末日分布(pool 末端 {pool['date'].max().date()})", flush=True)
    ends = pool.groupby("code")["date"].max()
    last_year = ends.dt.year.value_counts().sort_index()
    print(f"    末日按年: {dict(last_year)}", flush=True)
    stale = int((ends < pool["date"].max() - pd.Timedelta(days=30)).sum())
    print(f"    末日早于全局末端 30 天以上的股票: {stale} / {len(ends)} 只", flush=True)

    # ---- 7. 每期在成分内、且有特征的股票数(评估用的横截面规模) ----
    per_date_n = pool.groupby("date")["code"].size()
    recent = per_date_n[per_date_n.index >= pd.Timestamp("2025-01-01")]
    print(f"\n[7] 2025 以来每期横截面只数: 均值 {recent.mean():.0f}, "
          f"最少 {recent.min()}, 最多 {recent.max()}", flush=True)
    tail_n = per_date_n.tail(8)
    print("    最后 8 个交易日横截面: "
          + ", ".join(f"{d.date()}:{n}" for d, n in tail_n.items()), flush=True)

    # ---- 8. 被剔除样本的年度成本(粗估, 用池内同月均值代理缺失收益) ----
    # 缺失样本无法知道真实收益; 但它集中在"退市/长停牌"前, 用同月同池全样本均值
    # (含成分股当月整体涨跌)做代理, 得到的是量级而非精确值。
    print(f"\n[8] 被剔除样本的隐含成本(粗估)", flush=True)
    mon_mean = valid.groupby(valid["date"].dt.to_period("M"))["stock_fwd"].mean()
    trunc = trunc.copy()
    trunc["ym"] = trunc["date"].dt.to_period("M")
    trunc["proxy"] = trunc["ym"].map(mon_mean)
    est = trunc.dropna(subset=["proxy"])
    if len(est):
        by_year = est.groupby(est["date"].dt.year)["proxy"].agg(["size", "mean"])
        print(f"    被剔除样本若按同月池内均值持有: 平均 {est['proxy'].mean():+.3%}/30日", flush=True)
        print(f"    逐年: " + ", ".join(
            f"{y}:{r['size']}条{r['mean']:+.2%}" for y, r in by_year.iterrows() if y >= 2017), flush=True)

    os.makedirs(RESULTS_DIR, exist_ok=True)
    path = os.path.join(RESULTS_DIR, f"audit_executability_zz{universe}.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"中证{universe} 可执行性审计\n")
        f.write(f"涨停占比 {valid['up_limit'].mean():.2%}, 跌停占比 {valid['dn_limit'].mean():.2%}\n")
        f.write(f"持仓期内无后续数据而被剔除的样本 {len(trunc)} 条 "
                f"({len(trunc) / len(pool):.2%}), 其中回测期 {len(test_trunc)} 条\n")
        f.write(f"真退市/摘牌股 {len(died)} 只\n")
        f.write(f"涨停股未来{H}日收益 {valid.loc[valid['up_limit'], 'stock_fwd'].mean():+.3%} "
                f"vs 全体 {valid['stock_fwd'].mean():+.3%}\n")
        f.write(f"缓存末日早于全局末端 30 天以上的股票: {stale} / {len(ends)} 只\n")
    print(f"\n报告已保存: {path}", flush=True)


if __name__ == "__main__":
    main()
