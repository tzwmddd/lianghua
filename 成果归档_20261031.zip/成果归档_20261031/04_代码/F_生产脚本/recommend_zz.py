"""中证500/1000 纯多头选股推荐:预测"是否跑赢自身指数",输出 Q5 买入榜。

只做多不做空。标签 = 个股未来30日收益是否跑赢中证500/1000 指数;pooled 全历史
训练(forward-30 标签天然留出 30 交易日 embargo,训练集与预测日零重叠),预测最新
交易日横截面,做多"跑赢概率"最高的 20%(Q5)。特征 = 技术22 + 超额3 + 估值2 + 财务6 + size。

用法: python recommend_zz.py [500|1000]
"""
import glob
import os
import sys
import time
import warnings

import numpy as np
import pandas as pd

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

from config import RESULTS_DIR, SEED, FORECAST_HORIZON
from data import load_cached
from features import build_features, FEATURE_COLS
from cross_section import neutralize
from fundamental_ts import attach_fundamentals_ts

warnings.filterwarnings("ignore")

UNIVERSES = {
    "500": ("000905.SH", "cache_zz500"),
    "1000": ("000852.SH", "cache_zz1000"),
}
Q_FRAC = 0.15              # 实测最优: top15%(118只) 优于 top20%(157只)
TOP_SHOW = 20
LIQUIDITY_DROP = 0.2       # 剔除近20日均换手率最低 20%(流动性过滤,小盘股滑点大)
TURNOVER_WINDOW = 20       # 换手率均值窗口(交易日)
EXCESS_WINDOWS = [5, 20, 60]
BASE_STYLE = FEATURE_COLS + [f"excess_{n}" for n in EXCESS_WINDOWS]
# 评估证实:技术面是唯一有效信号,财务/估值/size 都是噪声(会稀释 IC)。
# 故推荐特征只用纯技术面(tech_only 最优配置),不做 size/财务/估值。
#
# 2026-09 新增: 股东户数(hl_chg_4q) + 资金流(mf_*) 两个正交因子,
#   实测年化绝对 +5.83% -> +8.10%(+2.27 个点), 回撤 -43.31% -> -41.80%
#   数据缺失时自动降级为纯技术面, 不影响使用。
STYLE_COLS = BASE_STYLE

# 换手缓冲: 保留上期持仓中仍排在前 BUFFER_FRAC 的股票(而不是每期全换)。
# 实测年化绝对 +2.2 个点以上, 换手率 74% -> 44%。
#
# **最优值按市场区分**(实测于各自市场, 同口径):
#   中证1000: 0.5~0.6 最优(平台), 年化绝对 +4.13% -> +6.31~6.64%
#   中证500 : 0.35 最优, 年化绝对 +7.50% vs 当前 0.50 的 +6.75% (+0.75)
#             原因: 中证500 alpha 更弱(超额 +6.03% vs +9.67%),
#             保留旧持仓的代价更大, 所以缓冲带应该更窄。
BUFFER_FRAC_BY_UNIVERSE = {"1000": 0.5, "500": 0.35}
BUFFER_FRAC = 0.5          # 默认值(向后兼容)

# 持有期/标签窗口: 两个市场当前都是 30 天, 但**理由不同**, 记录备查。
#   中证1000: 沿用 30 天。你早期报告显示 30->60 天在旧口径下从 +2.23% 提到 +4.80%,
#             但那是在 T+0 收盘成交/无缓冲的旧口径下; 本项目未在新口径复核,
#             暂时不动(若后续要改, 需先做可执行口径的扫描)。
#   中证500 : 可执行口径实测 **30 天确实最优**, 拉长反而更差:
#             30天 年化+7.50% 回撤-36.68% 夏普0.436 超额+6.81%
#             45天 年化+5.10% 回撤-39.23% 夏普0.342 超额+4.01%
#             60天 年化+7.09% 回撤-39.45% 夏普0.428 超额+5.37%
#           关键发现: 拉长持有期**没有降低换手率**(55.2%->56.2%->59.8%),
#           因为换手由信号变化速度决定, 不是持有期的函数。
#           所以中证500 上延长持有期是"成本没省、信号却拿更久"(双输)。
#           机理: alpha 更弱(IC 0.057 vs 0.100), 信号衰减更快。
#           见 results/tune_horizon_zz500_report.txt


def get_names(universe):
    """tushare stock_basic 拿代码->名称(当前上市)。失败返回空。"""
    try:
        import tushare_common as tc
        pro = tc.get_pro()
        df = pro.stock_basic(list_status="L")
        return dict(zip(df["ts_code"].map(tc.to_code), df["name"]))
    except Exception:
        return {}


def load_index(cache_dir):
    idx = pd.read_csv(os.path.join(cache_dir, "index.csv"), parse_dates=["date"])
    return idx.set_index("date")["close"].sort_index()


def load_pool(cache_dir):
    idx = load_index(cache_dir)
    idx_ret = idx.pct_change()
    idx_fwd = idx.shift(-FORECAST_HORIZON) / idx - 1

    codes = sorted(
        os.path.splitext(os.path.basename(f))[0]
        for f in glob.glob(os.path.join(cache_dir, "*.csv"))
        if os.path.splitext(os.path.basename(f))[0].isdigit()
    )
    parts = []
    for code in codes:
        df = load_cached(code, cache_dir)
        if df is None or len(df) < 120:
            continue
        feat = build_features(df, FORECAST_HORIZON, keep_tail=True)
        feat["idx_ret"] = feat["date"].map(idx_ret)
        feat["idx_fwd"] = feat["date"].map(idx_fwd)
        feat["ret"] = feat["close"].pct_change()
        for n in EXCESS_WINDOWS:
            feat[f"excess_{n}"] = feat["ret"].rolling(n).sum() - feat["idx_ret"].rolling(n).sum()
        feat["stock_fwd"] = feat["close"].shift(-FORECAST_HORIZON) / feat["close"] - 1
        feat["excess_fwd"] = feat["stock_fwd"] - feat["idx_fwd"]
        feat["target_rel"] = (feat["excess_fwd"] > 0).astype(int)
        feat["code"] = code
        parts.append(feat)
    pool = pd.concat(parts, ignore_index=True)
    return pool.sort_values("date").reset_index(drop=True)


def load_turnover(cache_dir, window=TURNOVER_WINDOW):
    """读 daily_basic,算每只股票近 window 日平均换手率,返回最新一期 code->turnover。

    换手率是流动性代理:小盘股换手率过低会导致买入滑点大、涨跌停买不进。
    """
    path = os.path.join(cache_dir, "_daily_basic.csv")
    if not os.path.exists(path):
        return pd.DataFrame(columns=["code", "turnover"])
    db = pd.read_csv(path, parse_dates=["date"], dtype={"code": str})
    db = db.sort_values(["code", "date"])
    db["turnover"] = db.groupby("code")["turnover_rate"].transform(
        lambda s: s.rolling(window, min_periods=10).mean()
    )
    return db.drop_duplicates("code", keep="last")[["code", "turnover"]]


def check_data_freshness(cache_dir, tolerance_days=14):
    """数据新鲜度断言: 防止拿着过期缓存算出一个"看起来正常"的推荐榜。

    download_zz_daily.py 只下载缺失的股票, 已存在的文件永不更新 —— 所以这里必须
    显式校验, 否则某天会发现推荐榜用的是几个月前的数据。
    """
    idx_path = os.path.join(cache_dir, "index.csv")
    if not os.path.exists(idx_path):
        print(f"[警告] 缺少 {idx_path}, 跳过新鲜度校验", flush=True)
        return
    idx = pd.read_csv(idx_path, parse_dates=["date"])
    idx_last = idx["date"].max()
    today = pd.Timestamp.today().normalize()
    lag = (today - idx_last).days
    print(f"[新鲜度] 指数数据末日 {idx_last.date()}, 距今 {lag} 天 "
          f"(阈值 {tolerance_days} 天)", flush=True)
    if lag > tolerance_days:
        print(f"\n[错误] 数据已过期 {lag} 天。请先更新:", flush=True)
        print(f"       python update_data.py {sys.argv[1] if len(sys.argv) > 1 else '1000'}",
              flush=True)
        print(f"       若确认要基于旧数据出榜, 用 --allow-stale 跳过校验。", flush=True)
        raise SystemExit(1)


def main():
    universe = sys.argv[1] if len(sys.argv) > 1 else "500"
    if universe not in UNIVERSES:
        sys.exit("用法: python recommend_zz.py [500|1000] [--allow-stale]")
    index_code, cache_dir = UNIVERSES[universe]
    t0 = time.time()
    os.makedirs(RESULTS_DIR, exist_ok=True)

    if "--allow-stale" not in sys.argv:
        check_data_freshness(cache_dir)
    else:
        print("[新鲜度] 已用 --allow-stale 跳过校验", flush=True)

    pool = load_pool(cache_dir)
    pool = pool.dropna(subset=BASE_STYLE)
    pool = attach_fundamentals_ts(pool, cache_dir)
    pool = neutralize(pool, STYLE_COLS)
    # 正交因子(股东户数 + 资金流): 数据缺失时自动跳过
    try:
        from orthogonal_factors import attach_orthogonal_factors, ORTHO_FEATURES
        pool = attach_orthogonal_factors(pool, cache_dir)
        extra = [f for f in ORTHO_FEATURES if f in pool.columns]
    except Exception as e:  # noqa: BLE001
        print(f"[正交因子] 加载失败, 退回纯技术面: {str(e)[:80]}", flush=True)
        extra = []
    # 事件型因子(业绩预告): 两个市场的**最优组合不同**, 实测(同口径消融):
    #   中证1000: fc_type(+1.39) + fc_pchg_mid -> 合计 +1.61 个点, 回撤改善 2.78
    #             (单加 fc_pchg_mid 是 -0.41, 主力是 fc_type)
    #   中证500 : fc_np_to_mv(+0.86, 回撤改善 6.83) 最优;
    #             fc_type 在中证500 上是 -2.23 —— 同一因子在两个市场作用相反,
    #             原因是中证500 alpha 更弱(超额 +6.03% vs +9.67%), 撑不住更多因子。
    FC_BY_UNIVERSE = {
        "1000": ("fc_type", "fc_pchg_mid"),
        "500": ("fc_np_to_mv",),
    }
    try:
        from event_factors import build_event_factors
        pool = build_event_factors(pool, cache_dir)
        want = FC_BY_UNIVERSE.get(universe, ())
        fc = [f for f in want if f in pool.columns]
        extra += fc
        print(f"[业绩预告] 中证{universe} 启用: {fc}", flush=True)
    except Exception as e:  # noqa: BLE001
        print(f"[业绩预告] 加载失败, 跳过: {str(e)[:80]}", flush=True)
    features = STYLE_COLS + extra
    print(f"特征数 {len(features)}: {len(STYLE_COLS)} 技术面 + {len(extra)} 新因子",
          flush=True)
    train = pool[pool["target_rel"].notna()].dropna(subset=features)
    latest = pool["date"].max()
    today = pool[pool["date"] == latest].dropna(subset=features)
    # 预测截面只保留当前成分(最新 snapshot),不推荐已调出成分
    cons = pd.read_csv(os.path.join(cache_dir, "_constituents.csv"), dtype={"code": str})
    latest_snap = cons["snapshot_date"].max()
    current = set(cons.loc[cons["snapshot_date"] == latest_snap, "code"])
    today = today[today["code"].isin(current)]
    # 流动性过滤:剔除近20日均换手率最低 LIQUIDITY_DROP 的股票(小盘股滑点大、涨跌停买不进)
    turnover = load_turnover(cache_dir)
    today = today.merge(turnover, on="code", how="left")
    n_before = len(today)
    thresh = today["turnover"].quantile(LIQUIDITY_DROP)
    today = today[today["turnover"] >= thresh]
    print(f"流动性过滤: 剔除换手率最低 {LIQUIDITY_DROP:.0%} 的 {n_before - len(today)} 只"
          f"(阈值 {thresh:.2f}%),剩余 {len(today)} 只", flush=True)
    print(f"训练样本 {len(train)} 条({train['code'].nunique()} 只),"
          f"区间 {train['date'].min().date()} ~ {train['date'].max().date()}", flush=True)
    print(f"预测截面: {latest.date()},共 {len(today)} 只,标签=未来 {FORECAST_HORIZON} 日是否跑赢{index_code}", flush=True)

    import lightgbm as lgb
    model = lgb.LGBMClassifier(
        n_estimators=150, learning_rate=0.10, num_leaves=63,
        subsample=0.8, colsample_bytree=0.8,
        random_state=SEED, verbosity=-1, n_jobs=-1,
    )
    model.fit(train[features].to_numpy(), train["target_rel"].to_numpy())

    prob = model.predict_proba(today[features].to_numpy())[:, 1]
    res = today[["code", "date", "close", "turnover"]].copy()
    res["prob"] = prob

    name_map = get_names(universe)
    res["name"] = res["code"].map(name_map).fillna("")

    res = res.sort_values("prob", ascending=False).reset_index(drop=True)
    # 注意: k 必须在"当前成分股 + 流动性过滤"之后算。
    # 若用全体缓存股票(含历史上已调出的 ~2800 只)算分位, 持仓会多出 2~3 倍,
    # 与回测口径不一致。
    k = max(1, int(len(res) * Q_FRAC))

    # ---- 换手缓冲: 读上期推荐, 保留其中仍排在前 BUFFER_FRAC 的股票 ----
    prev_path = os.path.join(RESULTS_DIR, f"recommend_zz{universe}.csv")
    prev_hold = []
    if os.path.exists(prev_path):
        try:
            old = pd.read_csv(prev_path, dtype={"code": str})
            if "group" in old.columns:
                prev_hold = old.loc[old["group"] == "Q5_buy", "code"].tolist()
        except Exception:  # noqa: BLE001
            prev_hold = []
    buf_frac = BUFFER_FRAC_BY_UNIVERSE.get(universe, BUFFER_FRAC)
    n_buf = max(1, int(len(res) * buf_frac))
    buf_codes = set(res.head(n_buf)["code"])
    keep = [c for c in prev_hold if c in buf_codes]
    final = keep[:k]
    for _, r in res.iterrows():
        if len(final) >= k:
            break
        if r["code"] not in final:
            final.append(r["code"])
    # 把最终持仓打标(与"当期前15%"分开, 方便识别缓冲效果)
    res["in_buffer_keep"] = res["code"].isin(keep)
    res["suggest_hold"] = res["code"].isin(final)
    if prev_hold:
        n_new = max(0, k - min(len(keep), k))
        print(f"\n[换手缓冲] 上期持仓 {len(prev_hold)} 只, 其中 {len(keep)} 只仍在前 "
              f"{buf_frac:.0%} 内; 本期建议持仓 {len(final)} 只"
              f"(保留 {min(len(keep), k)} 只, 新买入 {n_new} 只)", flush=True)
    else:
        print(f"\n[换手缓冲] 无上期持仓记录(首次运行), 本期按当期排名直出 {len(final)} 只; "
              f"下期起自动启用缓冲", flush=True)

    # 概率加权: 实测比等权多约 +0.7 个点年化超额(见 results/tune_weight_zz1000_report.txt)。
    # 做法: 在最终持仓内按 (prob - min) 归一化, 再缩放到 [0.5, 1.5] —— 保留区分度但不走极端,
    # 避免单只股票权重过大(容量和个股风险都不允许)。
    res["weight"] = np.nan
    hold_df = res[res["suggest_hold"]].copy()
    p = hold_df["prob"].to_numpy(dtype=float)
    if len(p) > 1 and p.max() > p.min():
        z = (p - p.min()) / (p.max() - p.min())
        w = 0.5 + z                                   # 0.5 ~ 1.5
        res.loc[hold_df.index, "weight"] = w / w.sum()  # 归一化到和为 1
    elif len(p) == 1:
        res.loc[hold_df.index, "weight"] = 1.0
    else:
        res.loc[hold_df.index, "weight"] = 1.0 / max(len(p), 1)

    print(f"\n===== 中证{universe} 建议持仓(前 {Q_FRAC:.0%},共 {k} 只) =====", flush=True)
    print(f"{'代码':<8}{'名称':<10}{'收盘价':>10}{'换手率%':>8}{'跑赢概率':>10}{'建议权重':>10}{'来源':>6}",
          flush=True)
    for _, r in res.head(TOP_SHOW).iterrows():
        # 只有最终入选的才有权重; 被缓冲剔除/挤出 k 名的显示 "-"
        w_txt = f"{r['weight']:>9.2%}" if r["suggest_hold"] and pd.notna(r["weight"]) else f"{'—':>9}"
        src = "保留" if r["in_buffer_keep"] else "候选"
        print(f"{r['code']:<8}{r['name']:<10}{r['close']:>10.2f}{r['turnover']:>8.2f}"
              f"{r['prob']:>9.1%}{w_txt}{src:>6}", flush=True)
    print(f"  ... (共 {k} 只,完整见 CSV)", flush=True)
    wv = res.loc[res["suggest_hold"], "weight"].dropna()
    print(f"  权重说明: 按预测概率在持仓内线性映射到 [0.5, 1.5] 后归一化, "
          f"区间 {wv.min():.2%} ~ {wv.max():.2%}, 合计 {wv.sum():.1%}", flush=True)

    print(f"\n===== 回避参考(跑赢概率最低 {Q_FRAC:.0%},仅供参考不做空) =====", flush=True)
    for _, r in res.tail(10).iloc[::-1].iterrows():
        print(f"{r['code']:<8}{r['name']:<10}{r['close']:>10.2f}{r['turnover']:>8.2f}{r['prob']:>9.1%}", flush=True)

    res["group"] = "hold"
    res.loc[res["suggest_hold"], "group"] = "Q5_buy"
    res.loc[res.index >= len(res) - k, "group"] = "Q1_avoid"

    out = os.path.join(RESULTS_DIR, f"recommend_zz{universe}.csv")
    res.to_csv(out, index=False, encoding="utf-8-sig")
    print(f"\n完整结果已保存: {out}", flush=True)
    print(f"总耗时 {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
