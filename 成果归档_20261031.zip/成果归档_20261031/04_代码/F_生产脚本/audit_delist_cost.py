"""量化"退市/停牌股被 dropna 删除"这一偏差的隐含成本。

思路: 现有 pool 把"信号日之后不足 H 个交易日"的样本整条删掉, 等于假设这些股票
从不被持有。本脚本用这些股票**最后可得的收盘价**给它们结算一个收益, 看偏差多大。

只需要现有缓存, 不改任何模型。

用法: python audit_delist_cost.py [500|1000]
"""
import glob
import os
import sys

import numpy as np
import pandas as pd

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

from config import FORECAST_HORIZON, RESULTS_DIR
from data import load_cached

UNIVERSES = {
    "500": ("cache_zz500",),
    "1000": ("cache_zz1000",),
}
H = FORECAST_HORIZON


def main():
    universe = sys.argv[1] if len(sys.argv) > 1 else "1000"
    (cache_dir,) = UNIVERSES[universe]

    cons = pd.read_csv(os.path.join(cache_dir, "_constituents.csv"), dtype={"code": str})
    cons["snapshot_date"] = pd.to_datetime(cons["snapshot_date"])
    data_end = pd.read_csv(os.path.join(cache_dir, "index.csv"), usecols=["date"])["date"].max()

    codes = sorted(
        os.path.splitext(os.path.basename(f))[0]
        for f in glob.glob(os.path.join(cache_dir, "*.csv"))
        if os.path.splitext(os.path.basename(f))[0].isdigit()
    )

    # 每只股票: 最后交易日 + 最后 N 日收益 + 它最后一次出现在成分快照里的时间
    rows = []
    for code in codes:
        df = load_cached(code, cache_dir)
        if df is None or len(df) < H + 2:
            continue
        last = df["date"].iloc[-1]
        c = df["close"].to_numpy()
        # 最后 H 个交易日的收益(以最后一条记录收尾)
        tail_ret = c[-1] / c[-1 - H] - 1 if len(c) > H else np.nan
        # 最后 60 日
        tail_ret60 = c[-1] / c[-1 - 60] - 1 if len(c) > 60 else np.nan
        rows.append({"code": code, "last": last, "tail30": tail_ret, "tail60": tail_ret60,
                     "n": len(df)})
    d = pd.DataFrame(rows)
    d["last"] = pd.to_datetime(d["last"])

    print(f"\n=== 中证{universe} 退市/停牌股最后一段的跌幅 ===", flush=True)
    print(f"股票数 {len(d)}, 数据末端 {data_end}", flush=True)

    # 分类: 仍活跃(末日在末端附近) / 已停止(末日早于末端 90 天)
    cutoff = pd.Timestamp(data_end) - pd.Timedelta(days=90)
    dead = d[d["last"] < cutoff].copy()
    alive = d[d["last"] >= cutoff]
    print(f"仍活跃(末日在 {cutoff.date()} 之后): {len(alive)} 只", flush=True)
    print(f"已停止交易: {len(dead)} 只", flush=True)

    print(f"\n已停止交易股票的'最后30个交易日'收益分布:", flush=True)
    t = dead["tail30"].dropna()
    if len(t):
        print(f"  均值 {t.mean():+.2%}, 中位数 {t.median():+.2%}", flush=True)
        print(f"  分位: 10% {t.quantile(0.1):+.2%} / 25% {t.quantile(0.25):+.2%} / "
              f"75% {t.quantile(0.75):+.2%} / 90% {t.quantile(0.9):+.2%}", flush=True)
        print(f"  跌超 30% 的占比: {(t < -0.30).mean():.2%}", flush=True)
        print(f"  跌超 50% 的占比: {(t < -0.50).mean():.2%}", flush=True)
    t60 = dead["tail60"].dropna()
    if len(t60):
        print(f"  最后60日: 均值 {t60.mean():+.2%}, 中位数 {t60.median():+.2%}", flush=True)

    # 只保留回测期(2017 起)停止交易的
    dead_test = dead[dead["last"] >= pd.Timestamp("2017-01-01")]
    print(f"\n回测期内(2017起)停止交易: {len(dead_test)} 只, "
          f"其最后30日收益均值 {dead_test['tail30'].mean():+.2%}, "
          f"中位数 {dead_test['tail30'].median():+.2%}", flush=True)

    # 这些股票最后一次出现在成分快照的时间分布
    snap_max = cons.groupby("code")["snapshot_date"].max()
    dead_test = dead_test.copy()
    dead_test["last_snap"] = dead_test["code"].map(snap_max)
    lag = (dead_test["last"] - dead_test["last_snap"]).dt.days
    print(f"  '最后成分快照' 与 '最后交易日' 的间隔(天): "
          f"中位数 {lag.median():.0f}, 均值 {lag.mean():.0f}", flush=True)
    print(f"  即: 这些股票在调出指数后平均又交易了 {lag.median():.0f} 天才消失", flush=True)

    # ---- 关键: 用"最后可得收盘价收尾"重算这些样本 -> 每期成本 ----
    # 对每个调仓日 t, 找出"t 之后不足 H 个交易日"的样本, 用最后可得价结算
    print(f"\n=== 对回测的实际影响估计 ===", flush=True)
    # 用日线重建: 逐股算每个交易日 t 的 forward 收益(有数据用 open/close, 无数据用最后价)
    per_ep = []
    for code in dead_test["code"]:
        df = load_cached(code, cache_dir)
        if df is None or len(df) < H + 2:
            continue
        dates = df["date"].reset_index(drop=True)
        close = df["close"].reset_index(drop=True).to_numpy()
        n = len(df)
        # 对该股最后 H+1 条记录附近的信号日做检查
        for i in range(n - H - 1, n):
            if i < 0:
                continue
            t = dates.iloc[i]
            if t < pd.Timestamp("2017-01-01"):
                continue
            # 正常结算
            j = min(i + 1 + H, n - 1)
            norm = close[j] / close[min(i + 1, n - 1)] - 1
            # 若 i+1+H 越界 -> 就是被删掉的情形
            censored = (i + 1 + H) > (n - 1)
            if censored:
                per_ep.append({"date": t, "code": code, "ret": norm, "censored": True})
    if per_ep:
        pe = pd.DataFrame(per_ep)
        print(f"回测期内被删掉的(股票×信号日)样本: {len(pe)} 条, {pe['code'].nunique()} 只", flush=True)
        print(f"  用最后可得价结算, 这些样本的平均收益: {pe['ret'].mean():+.2%}/30日", flush=True)
        print(f"  中位数 {pe['ret'].median():+.2%}, 跌超30%占比 {(pe['ret'] < -0.3).mean():.2%}", flush=True)
        pe["year"] = pe["date"].dt.year
        print(f"  按年:", flush=True)
        for y, g in pe.groupby("year"):
            print(f"    {y}: {len(g)} 条, 均值 {g['ret'].mean():+.2%}", flush=True)

    os.makedirs(RESULTS_DIR, exist_ok=True)
    path = os.path.join(RESULTS_DIR, f"audit_delist_cost_zz{universe}.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"中证{universe} 退市/停牌股偏差量化\n")
        f.write(f"已停止交易 {len(dead)} 只, 回测期内 {len(dead_test)} 只\n")
        f.write(f"停止交易股票最后30日收益: 均值 {dead['tail30'].mean():+.2%}, "
                f"中位数 {dead['tail30'].median():+.2%}\n")
        if per_ep:
            f.write(f"被删样本 {len(pe)} 条, 收尾结算均值 {pe['ret'].mean():+.2%}\n")
    print(f"\n报告已保存: {path}", flush=True)


if __name__ == "__main__":
    main()
