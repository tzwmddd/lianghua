"""样本外验证: 参数是在 2017-2026 全样本上选的, 这里检验它们的稳健性。

做法(时间分割):
  内样本 IS : 2017-01 ~ 2022-12 (6 年)
  外样本 OOS: 2023-01 ~ 2026-05 (3.5 年)
对每个参数取值, 分别报 IS 和 OOS 的净收益, 看:
  1. 在 IS 上选出最优参数, 它在 OOS 上是否也是最优/接近最优
  2. 参数曲线是"平台"还是"尖峰"(尖峰 = 过拟合风险高)

检查三组参数: 缓冲带、选股范围、特征集(新因子)。

用法: python oos_validate.py [1000]
"""
import os
import sys
import time

import numpy as np
import pandas as pd

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

from config import RESULTS_DIR
from zz_pool import BASE_FEATURES
from orthogonal_factors import attach_orthogonal_factors, ORTHO_FEATURES
from final_combo import run, daily_metrics, UNIVERSES, H

IS_END = "2022-12-31"
OOS_START = "2023-01-01"


def slice_run(pool, features, cost, cache_dir, start, end, **kw):
    """只保留 [start, end] 的调仓期。"""
    rec = run(pool, features, cost, **kw)
    rec = [r for r in rec if pd.Timestamp(start) <= r["date"] <= pd.Timestamp(end)]
    if len(rec) < 6:
        return None
    return daily_metrics(rec, cache_dir, cost)


def main():
    u = sys.argv[1] if len(sys.argv) > 1 else "1000"
    cache_dir, cost = UNIVERSES[u]
    t0 = time.time()

    from _tune_model import get_pool
    pool, _, _ = get_pool(u, horizon=H)
    pool = attach_orthogonal_factors(pool, cache_dir)
    feats_new = [f for f in ORTHO_FEATURES if f in pool.columns]
    full_feats = BASE_FEATURES + feats_new
    print(f"pool {len(pool)} 条, 正交因子 {feats_new}", flush=True)

    results = {}

    def scan(title, param_name, values, feats, base_kw):
        print(f"\n=== {title} (参数: {param_name}) ===", flush=True)
        header = (f"{param_name:>10}{'IS年化':>10}{'IS回撤':>10}{'IS夏普':>9}"
                  f"{'OOS年化':>10}{'OOS回撤':>10}{'OOS夏普':>9}{'OOS换手':>9}")
        print(header, flush=True)
        print("-" * len(header), flush=True)
        rows = []
        for v in values:
            kw = dict(base_kw)
            kw[param_name] = v
            t1 = time.time()
            m_is = slice_run(pool, feats, cost, cache_dir, "2017-01-01", IS_END, **kw)
            m_oos = slice_run(pool, feats, cost, cache_dir, OOS_START, "2027-01-01", **kw)
            if m_is is None or m_oos is None:
                continue
            row = (f"{str(v):>10}{m_is['ann']:>+10.2%}{m_is['dd']:>10.2%}{m_is['sharpe']:>9.3f}"
                   f"{m_oos['ann']:>+10.2%}{m_oos['dd']:>10.2%}{m_oos['sharpe']:>9.3f}"
                   f"{m_oos['turn']:>9.1%}")
            print(row + f"  ({time.time() - t1:.0f}s)", flush=True)
            rows.append((v, m_is, m_oos))
        results[title] = rows
        # 找出 IS 最优和 OOS 最优
        if rows:
            best_is = max(rows, key=lambda r: r[1]["ann"])
            best_oos = max(rows, key=lambda r: r[2]["ann"])
            print(f"  IS 最优参数 {best_is[0]} (IS 年化 {best_is[1]['ann']:+.2%}) "
                  f"-> 它在 OOS 的年化 {best_is[2]['ann']:+.2%}", flush=True)
            print(f"  OOS 最优参数 {best_oos[0]} (OOS 年化 {best_oos[2]['ann']:+.2%})", flush=True)

    # 1. 缓冲带(固定 top15% + 新因子 + 概率加权)
    scan("缓冲带", "buffer_frac", [0.2, 0.35, 0.5, 0.6, 0.7], full_feats,
         dict(top_frac=0.15, use_weight=True))

    # 2. 选股范围(固定缓冲50% + 新因子 + 概率加权)
    scan("选股范围", "top_frac", [0.1, 0.15, 0.2, 0.3], full_feats,
         dict(buffer_frac=0.5, use_weight=True))

    # 3. 特征集(固定最优交易参数)
    print(f"\n=== 特征集 ===", flush=True)
    header = (f"{'特征集':>16}{'IS年化':>10}{'IS回撤':>10}{'IS夏普':>9}"
              f"{'OOS年化':>10}{'OOS回撤':>10}{'OOS夏普':>9}")
    print(header, flush=True)
    print("-" * len(header), flush=True)
    fs_rows = []
    for name, feats in [("仅技术面", BASE_FEATURES),
                        ("+hl_chg_4q", BASE_FEATURES + ["hl_chg_4q"]),
                        ("+新因子(全部可用)", full_feats)]:
        m_is = slice_run(pool, feats, cost, cache_dir, "2017-01-01", IS_END,
                         top_frac=0.15, buffer_frac=0.5, use_weight=True)
        m_oos = slice_run(pool, feats, cost, cache_dir, OOS_START, "2027-01-01",
                          top_frac=0.15, buffer_frac=0.5, use_weight=True)
        if m_is is None or m_oos is None:
            continue
        row = (f"{name:>16}{m_is['ann']:>+10.2%}{m_is['dd']:>10.2%}{m_is['sharpe']:>9.3f}"
               f"{m_oos['ann']:>+10.2%}{m_oos['dd']:>10.2%}{m_oos['sharpe']:>9.3f}")
        print(row, flush=True)
        fs_rows.append((name, m_is, m_oos))
    results["特征集"] = fs_rows

    path = os.path.join(RESULTS_DIR, f"oos_validate_zz{u}_report.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"中证{u} 样本外验证 (IS 2017-2022 / OOS 2023-2026)\n")
        f.write("口径: 可执行体系, H=30, 概率加权, 特征缺失保留NaN\n\n")
        for title, rows in results.items():
            f.write(f"\n### {title}\n")
            if title == "特征集":
                f.write("特征集            IS年化  IS回撤  IS夏普  OOS年化  OOS回撤  OOS夏普\n")
                for name, a, b in rows:
                    f.write(f"{name:>16}{a['ann']:>+10.2%}{a['dd']:>10.2%}{a['sharpe']:>9.3f}"
                            f"{b['ann']:>+10.2%}{b['dd']:>10.2%}{b['sharpe']:>9.3f}\n")
            else:
                f.write("参数  IS年化  IS回撤  IS夏普  OOS年化  OOS回撤  OOS夏普  OOS换手\n")
                for v, a, b in rows:
                    f.write(f"{str(v):>10}{a['ann']:>+10.2%}{a['dd']:>10.2%}{a['sharpe']:>9.3f}"
                            f"{b['ann']:>+10.2%}{b['dd']:>10.2%}{b['sharpe']:>9.3f}"
                            f"{b['turn']:>9.1%}\n")
    print(f"\n报告已保存: {path}", flush=True)
    print(f"总耗时 {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
