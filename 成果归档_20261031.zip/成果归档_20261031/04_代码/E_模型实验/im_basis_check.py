"""自查中证1000 股指期货(IM)的历史贴水, 验证"对冲是否可行"。

方法:
  1. 用 fut_daily 拉全部 IM 合约日线(含 oi 持仓量)
  2. 每个交易日取持仓量最大的合约作为主力
  3. 年化贴水 = (指数收盘价 / 期货收盘价 - 1) * 365 / 剩余天数
     (剩余天数用合约到期日 - 交易日; IM 到期日为每月第三个周五)
  4. 统计历史分布, 并落到最近的数值上

用法: python im_basis_check.py
"""
import os
import sys
import time

import numpy as np
import pandas as pd

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

import tushare_common as tc

INDEX = "000852.SH"
START, END = "20170101", "20261231"
CACHE = "cache_im_basis.csv"


def third_friday(year, month):
    """每月第三个周五(中金所股指期货最后交易日)。"""
    d = pd.Timestamp(year=year, month=month, day=1)
    # 第一个周五
    offset = (4 - d.dayofweek) % 7
    first_fri = d + pd.Timedelta(days=offset)
    return first_fri + pd.Timedelta(days=14)


def expiry_of(ts_code):
    """IM2401.CFX -> 2024-01-19 类型的到期日。"""
    s = ts_code.split(".")[0]          # IM2401
    yy = int(s[2:4])
    mm = int(s[4:6])
    year = 2000 + yy
    return third_friday(year, mm)


def main():
    pro = tc.get_pro()
    t0 = time.time()

    # 指数日线
    idx = pro.index_daily(ts_code=INDEX, start_date=START, end_date=END)
    idx["date"] = pd.to_datetime(idx["trade_date"])
    idx = idx.set_index("date")["close"].sort_index()
    print(f"指数 {INDEX}: {len(idx)} 个交易日, {idx.index.min().date()} ~ {idx.index.max().date()}",
          flush=True)

    # IM 合约列表
    basic = pro.fut_basic(exchange="CFFEX", fut_type="1")
    im_codes = sorted(c for c in basic["ts_code"].unique() if c.startswith("IM"))
    print(f"IM 合约 {len(im_codes)} 个: {im_codes[0]} ... {im_codes[-1]}", flush=True)

    # 逐合约拉日线(按月分段, 避免行数上限)
    rows = []
    for code in im_codes:
        if code.endswith(".CFX") is False:
            continue
        try:
            df = pro.fut_daily(ts_code=code, start_date=START, end_date=END)
            if df is not None and len(df):
                df["contract"] = code
                rows.append(df)
        except Exception as e:  # noqa: BLE001
            print(f"  {code} 失败: {str(e)[:50]}", flush=True)
        tc.sleep(0.25)
    if not rows:
        print("没有拿到任何 IM 数据")
        return
    fut = pd.concat(rows, ignore_index=True)
    fut["date"] = pd.to_datetime(fut["trade_date"])
    print(f"IM 日线合计 {len(fut)} 行, {fut['contract'].nunique()} 个合约", flush=True)

    # 每个交易日选持仓量最大的合约作为主力
    fut = fut.sort_values(["date", "oi"], ascending=[True, False])
    main_c = fut.drop_duplicates("date", keep="first").copy()
    main_c["expiry"] = main_c["contract"].map(lambda c: expiry_of(c))
    main_c = main_c.set_index("date")

    common = main_c.index.intersection(idx.index)
    print(f"重叠交易日 {len(common)}", flush=True)
    m = main_c.loc[common].copy()
    m["index_close"] = idx.reindex(common).to_numpy()
    m["days_left"] = (m["expiry"] - m.index).dt.days
    m = m[m["days_left"] > 0]
    # 年化贴水(正数 = 期货比指数便宜 = 做空要付的成本)
    m["basis_ann"] = (m["index_close"] / m["close"] - 1.0) * 365.0 / m["days_left"]
    m["basis_ann"] = m["basis_ann"].replace([np.inf, -np.inf], np.nan).dropna()

    print(f"\n=== IM 主力合约年化贴水(自查) ===", flush=True)
    print(f"  样本 {len(m)} 天, {m.index.min().date()} ~ {m.index.max().date()}", flush=True)
    print(f"  均值 {m['basis_ann'].mean():+.2%}, 中位数 {m['basis_ann'].median():+.2%}", flush=True)
    print(f"  分位: 10% {m['basis_ann'].quantile(0.1):+.2%} / 25% {m['basis_ann'].quantile(0.25):+.2%} "
          f"/ 75% {m['basis_ann'].quantile(0.75):+.2%} / 90% {m['basis_ann'].quantile(0.9):+.2%}",
          flush=True)

    by_year = m.groupby(m.index.year)["basis_ann"].agg(["size", "mean", "median"])
    print(f"\n  按年均值/中位数:", flush=True)
    for y, r in by_year.iterrows():
        print(f"    {y}: {r['mean']:+.2%} / {r['median']:+.2%}  ({int(r['size'])} 天)", flush=True)

    print(f"\n  最近 10 个交易日:", flush=True)
    for d, r in m.tail(10).iterrows():
        print(f"    {d.date()}  合约 {r['contract']}  期货 {r['close']:.1f}  "
              f"指数 {r['index_close']:.1f}  剩余 {int(r['days_left'])} 天  "
              f"年化贴水 {r['basis_ann']:+.2%}", flush=True)

    m[["contract", "close", "index_close", "days_left", "basis_ann"]].to_csv(CACHE)
    print(f"\n已保存 {CACHE}", flush=True)
    print(f"总耗时 {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
