"""诊断: 为中证500 的样本权重/特征筛选实验提供依据。

检查四件事:
  1. 标签分布(正例率) + 按时间/股票的变化 -> 是否需要类别平衡权重
  2. 特征重要性(全样本训练一次) -> 哪些因子是主力
  3. 因子间相关性 -> 找冗余, 为特征筛选提供候选
  4. 特征重要性是否随时间漂移 -> 判断固定特征集是否合理
"""
import os
import sys
import time

import numpy as np
import pandas as pd
import lightgbm as lgb

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

from config import SEED, RESULTS_DIR
from zz_pool import BASE_FEATURES
from orthogonal_factors import attach_orthogonal_factors, ORTHO_FEATURES
from event_factors import build_event_factors
from tune_horizon_500 import get_pool, UNIVERSES, FC

t0 = time.time()
cache_dir = UNIVERSES["500"][0]
pool, _ = get_pool("500", 30)
pool = attach_orthogonal_factors(pool, cache_dir)
pool = build_event_factors(pool, cache_dir)
feats = BASE_FEATURES + [f for f in ORTHO_FEATURES if f in pool.columns]
feats += [f for f in FC["500"] if f in pool.columns]
print(f"pool {len(pool)} 条, 特征 {len(feats)} 个", flush=True)

valid = pool[pool["target_rel"].notna()].copy()
print(f"\n{'='*70}\n1. 标签分布\n{'='*70}")
print(f"有标签样本: {len(valid)}")
print(f"整体正例率 (跑赢指数): {valid['target_rel'].mean():.4f}")
valid["year"] = valid["date"].dt.year
by_year = valid.groupby("year")["target_rel"].agg(["size", "mean"])
print(f"\n按年正例率:")
for y, r in by_year.iterrows():
    print(f"  {y}: {r['mean']:.4f}  ({int(r['size'])} 条)")

# 极端收益分布(用于判断"按极值加权"是否有意义)
print(f"\n超额收益(excess_fwd)分布:")
e = valid["excess_fwd"].dropna()
q = e.quantile([0.01, 0.05, 0.25, 0.5, 0.75, 0.95, 0.99])
print("  " + ", ".join(f"{k:.0%}={v:+.2%}" for k, v in q.items()))
print(f"  |超额| > 20% 的样本占比: {(e.abs() > 0.20).mean():.2%}")
print(f"  |超额| > 10% 的样本占比: {(e.abs() > 0.10).mean():.2%}")

# 波动率分层(用于判断"按波动率加权")
if "vol_60" in valid.columns:
    print(f"\n按 vol_60 分5档的正例率:")
    v = valid.dropna(subset=["vol_60"]).copy()
    v["vol_bucket"] = pd.qcut(v["vol_60"], 5, labels=False)
    print("  " + ", ".join(
        f"Q{int(b)+1}={g['target_rel'].mean():.3f}"
        for b, g in v.groupby("vol_bucket")))

# ---- 特征重要性 ----
print(f"\n{'='*70}\n2. 特征重要性 (全样本训练一次)\n{'='*70}")
print("训练中 ...", flush=True)
tr = valid.dropna(subset=feats)
X = tr[feats].to_numpy(dtype=float)
y = tr["target_rel"].to_numpy()
model = lgb.LGBMClassifier(n_estimators=150, learning_rate=0.10, num_leaves=63,
                           subsample=0.8, colsample_bytree=0.8,
                           random_state=SEED, verbosity=-1, n_jobs=-1)
model.fit(X, y)
imp_gain = pd.Series(model.booster_.feature_importance("gain"), index=feats).sort_values(
    ascending=False)
imp_split = pd.Series(model.booster_.feature_importance("split"), index=feats)
print(f"\nGain 重要性 Top 15:")
for f, v in imp_gain.head(15).items():
    print(f"  {f:<20} gain={v:>12,.0f}  split={int(imp_split[f])}")
print(f"\nGain 重要性 末 10 (候选剔除):")
for f, v in imp_gain.tail(10).items():
    print(f"  {f:<20} gain={v:>12,.0f}")
print(f"\n零增益(zero gain)特征: {[f for f in feats if imp_gain[f] == 0]}")

# ---- 因子相关性 ----
print(f"\n{'='*70}\n3. 因子间相关性 (找冗余)\n{'='*70}")
sub = tr[feats].dropna()
if len(sub) > 5000:
    sub = sub.sample(5000, random_state=SEED)
corr = sub.corr(method="spearman").abs()
np.fill_diagonal(corr.values, 0)
pairs = []
cols = corr.columns.tolist()
for i in range(len(cols)):
    for j in range(i + 1, len(cols)):
        pairs.append((cols[i], cols[j], corr.iloc[i, j]))
pairs.sort(key=lambda x: -x[2])
print(f"\n相关性最高的 15 对 (|Spearman| > 0.7 视为高度冗余):")
for a, b, c in pairs[:15]:
    print(f"  {a:<20} {b:<20} {c:.3f}")
print(f"\n|相关| > 0.8 的对数: {sum(1 for _, _, c in pairs if c > 0.8)}")
print(f"|相关| > 0.7 的对数: {sum(1 for _, _, c in pairs if c > 0.7)}")

# ---- 重要性漂移 ----
print(f"\n{'='*70}\n4. 特征重要性是否随时间漂移\n{'='*70}")
print("(用前后两段各训练一次, 比较排名)")
mid = valid["date"].quantile(0.5)
for name, seg in [("前50%", valid[valid["date"] <= mid]),
                  ("后50%", valid[valid["date"] > mid])]:
    s = seg.dropna(subset=feats)
    if len(s) < 10000:
        continue
    m = lgb.LGBMClassifier(n_estimators=150, learning_rate=0.10, num_leaves=63,
                           subsample=0.8, colsample_bytree=0.8,
                           random_state=SEED, verbosity=-1, n_jobs=-1)
    m.fit(s[feats].to_numpy(dtype=float), s["target_rel"].to_numpy())
    im = pd.Series(m.booster_.feature_importance("gain"), index=feats)
    print(f"\n  {name} Top 8: " + ", ".join(f"{f}" for f in im.sort_values(
        ascending=False).head(8).index))

print(f"\n总耗时 {time.time() - t0:.0f}s", flush=True)
# 落盘重要性, 供后续特征筛选用
imp_gain.to_csv(os.path.join(RESULTS_DIR, "feature_importance_zz500.csv"))
print(f"特征重要性已保存: results/feature_importance_zz500.csv", flush=True)
