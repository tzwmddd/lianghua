"""对冲可行性评估: 对冲能不能同时保住 alpha 又压住 -44.6% 的回撤?

背景(择时实验的结论):
  择时用"少亏"换"错过 alpha", 年化 +5.45% -> +4.32%, 只能二选一。
  对冲理论上可以两条都要 —— 组合 beta 被打掉, 只留 alpha。

本脚本用现有数据算清楚三件事:
  1. 组合对中证1000 的实际 beta(用逐日收益回归), 以及"完美对冲"后的净值形状
  2. 不同对冲比例的效果
  3. 扣掉期货实际成本(基差贴水 + 保证金占用)之后还剩多少

成本假设(中证1000 股指期货 IM):
  - 基差贴水: 历史上年化贴水约 5%~15%(远月更贵), 这里做敏感性扫描
  - 保证金: 约 15%(交易所 + 期货公司加收), 占用资金降低实际收益率
  - 手续费: 忽略(相对贴水很小)

用法: python hedge_eval.py [1000]
"""
import os
import sys

import numpy as np
import pandas as pd

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

from config import RESULTS_DIR
from data import load_cached

CACHE = {"500": "cache_zz500", "1000": "cache_zz1000"}
BASIS_RATES = [0.0, 0.05, 0.10, 0.1506, 0.15]   # 年化贴水假设(0.1506 = IM 实测值)
MARGIN = 0.15                               # 期货保证金比例
CASH_YIELD = 0.02                           # 未占用现金的年化收益(货币基金)
HEDGE_RATIOS = [0.0, 0.5, 0.8, 1.0, 1.2]


def build_daily(u, cost):
    """用逐期持仓还原组合日收益与指数日收益。"""
    cache_dir = CACHE[u]
    recs = pd.read_csv(os.path.join(RESULTS_DIR, f"compare_zz{u}_real_periods.csv"),
                       parse_dates=["date"]).sort_values("date").reset_index(drop=True)
    dts = list(recs["date"])
    holds = [eval(h) for h in recs["hold"]]

    need = sorted({c for h in holds for c in h})
    px = {}
    for code in need:
        df = load_cached(code, cache_dir)
        if df is None:
            continue
        df = df[(df["date"] >= dts[0]) & (df["date"] <= dts[-1] + pd.Timedelta(days=1))]
        if len(df) >= 2:
            px[code] = df.set_index("date")["close"]
    mat = pd.DataFrame(px).sort_index().ffill()
    rets = mat.pct_change()

    idx = pd.read_csv(os.path.join(cache_dir, "index.csv"), parse_dates=["date"])
    idx = idx.sort_values("date").set_index("date")["close"]

    segs = []
    for i, r in enumerate(recs.itertuples()):
        hold = [c for c in holds[i] if c in rets.columns]
        if not hold:
            continue
        t = r.date
        t_next = dts[i + 1] if i + 1 < len(dts) else mat.index[-1]
        win = rets.loc[(rets.index > t) & (rets.index <= t_next), hold]
        if len(win) == 0:
            continue
        port = win.mean(axis=1)
        port.iloc[0] -= r.turn * cost
        segs.append(port)
    port_ret = pd.concat(segs).sort_index()
    idx_ret = idx.pct_change().reindex(port_ret.index).ffill().fillna(0.0)
    return port_ret, idx_ret


def stats(pr):
    nav = (1 + pr).cumprod()
    return dict(
        ann=float(nav.iloc[-1] ** (252 / len(pr)) - 1),
        dd=float((nav / nav.cummax() - 1).min()),
        sharpe=float(pr.mean() / pr.std(ddof=1) * np.sqrt(252)) if pr.std(ddof=1) > 0 else np.nan,
        vol=float(pr.std(ddof=1) * np.sqrt(252)),
    )


def main():
    u = sys.argv[1] if len(sys.argv) > 1 else "1000"
    cost = {"500": 0.004, "1000": 0.005}[u]
    port_ret, idx_ret = build_daily(u, cost)

    beta = float(np.cov(port_ret, idx_ret)[0, 1] / np.var(idx_ret))
    corr = float(np.corrcoef(port_ret, idx_ret)[0, 1])
    alpha_d = port_ret.mean() - beta * idx_ret.mean()
    print(f"\n=== 中证{u} 组合对冲特征 (逐日, {len(port_ret)} 个交易日) ===", flush=True)
    print(f"  组合对指数 beta: {beta:.3f}   相关系数: {corr:.3f}", flush=True)
    print(f"  组合年化波动 {port_ret.std(ddof=1) * np.sqrt(252):.2%}, "
          f"指数年化波动 {idx_ret.std(ddof=1) * np.sqrt(252):.2%}", flush=True)

    lines = [f"中证{u} 对冲评估", "=" * 70, ""]
    lines.append(f"beta={beta:.3f}, 相关系数={corr:.3f}, 交易日 {len(port_ret)}")

    # ---- 不同对冲比例(不含成本) ----
    print(f"\n--- 不同对冲比例(先不含期货成本) ---", flush=True)
    header = f"{'对冲比例':>9}{'年化':>9}{'最大回撤':>10}{'夏普':>8}{'年化波动':>10}"
    print(header, flush=True)
    lines += ["", "不同对冲比例(不含期货成本):", header]
    for h in HEDGE_RATIOS:
        pr = port_ret - h * idx_ret
        s = stats(pr)
        row = f"{h:>9.0%}{s['ann']:>+9.2%}{s['dd']:>10.2%}{s['sharpe']:>8.3f}{s['vol']:>10.2%}"
        print(row, flush=True)
        lines.append(row)

    # ---- beta=1 对冲 + 基差成本 + 保证金 ----
    print(f"\n--- 完全对冲(h=beta) 扣除基差与保证金占用 ---", flush=True)
    print(f"  假设: 保证金 {MARGIN:.0%}(名义额口径), 现金端收益率 {CASH_YIELD:.0%}/年", flush=True)
    print(f"  说明: 对冲后组合仓位+x期货保证金 才是真实占用资金, 其余现金按 {CASH_YIELD:.0%} 计息", flush=True)
    header2 = (f"{'年化贴水':>10}{'对冲后年化':>12}{'最大回撤':>10}{'夏普':>8}"
               f"{'占满资金后年化':>16}")
    print(header2, flush=True)
    lines += ["", f"完全对冲(h={beta:.2f}) + 期货成本(保证金 {MARGIN:.0%}, "
                  f"现金端 {CASH_YIELD:.0%}):", header2]
    hedged = port_ret - beta * idx_ret
    for basis in BASIS_RATES:
        cost_d = beta * basis / 252
        pr = hedged - cost_d
        s = stats(pr)
        cash_d = CASH_YIELD / 252
        # 真实资金曲线: 占用 = 组合本金 + 期货保证金; 未占用现金计息
        real_pr = (1 + pr) * (1 - MARGIN * beta) + (1 + cash_d) * (MARGIN * beta) - 1
        nav_r = (1 + real_pr).cumprod()
        ann_r = float(nav_r.iloc[-1] ** (252 / len(real_pr)) - 1)
        dd_r = float((nav_r / nav_r.cummax() - 1).min())
        sh_r = float(real_pr.mean() / real_pr.std(ddof=1) * np.sqrt(252))
        row = (f"{basis:>10.1%}{s['ann']:>+12.2%}{dd_r:>10.2%}{sh_r:>8.3f}"
               f"{ann_r:>+16.2%}")
        print(row, flush=True)
        lines.append(row)

    # ---- 对比: 不对冲 / 择时 / 对冲 ----
    print(f"\n--- 三种方案的最终对比(都含各自成本) ---", flush=True)
    base = stats(port_ret)
    print(f"  不对冲              : 年化 {base['ann']:+.2%}, 回撤 {base['dd']:.2%}, 夏普 {base['sharpe']:.3f}", flush=True)
    lines.append(f"不对冲: 年化 {base['ann']:+.2%}, 回撤 {base['dd']:.2%}, 夏普 {base['sharpe']:.3f}")
    lines.append("择时(跌破MA20空仓): 年化 +4.32%, 回撤 -25.78%, 夏普 0.365 (见 timing_zz1000_report.txt)")
    for basis in [0.0, 0.05, 0.10]:
        pr = hedged - beta * basis / 252
        s = stats(pr)
        real_pr = (1 + pr) * (1 - MARGIN * beta) + (1 + CASH_YIELD / 252) * (MARGIN * beta) - 1
        nav_r = (1 + real_pr).cumprod()
        ann_r = float(nav_r.iloc[-1] ** (252 / len(real_pr)) - 1)
        dd_r = float((nav_r / nav_r.cummax() - 1).min())
        sh_r = float(real_pr.mean() / real_pr.std(ddof=1) * np.sqrt(252))
        print(f"  对冲(贴水{basis:.0%})     : 年化 {ann_r:+.2%}, 回撤 {dd_r:.2%}, 夏普 {sh_r:.3f}", flush=True)
        lines.append(f"对冲(贴水{basis:.0%}): 年化 {ann_r:+.2%}, 回撤 {dd_r:.2%}, 夏普 {sh_r:.3f}")

    path = os.path.join(RESULTS_DIR, f"hedge_zz{u}_report.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print(f"\n报告已保存: {path}", flush=True)


if __name__ == "__main__":
    main()
