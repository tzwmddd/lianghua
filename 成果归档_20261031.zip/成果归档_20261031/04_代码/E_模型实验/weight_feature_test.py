"""中证500: 样本权重 与 特征筛选 实验。

诊断依据(diag_features_500.py):
  1. 正例率 44.15%(逐年 40~49%) -> 类别不平衡不严重
  2. vol_60 分档正例率单调: Q1=46.5% -> Q5=40.5% (低波动更易跑赢)
  3. 因子冗余高: 14 对 |相关|>0.7, 7 对 >0.8
     - mf_main_ratio_20 ~ mf_divergence = 0.949
     - macd_dif ~ macd_dea = 0.930
     - ma_ratio_20 ~ rsi ~ boll = 0.86~0.87
     - **ret_lag1~20 全部 gain 最低(514~956)** <- 首要剔除候选
  4. 重要性稳定(前后两半 Top8 几乎一致)

实验设计(每次只变一个因素, 其余固定为已验证最优):
  基线: 30天标签 / 缓冲0.35 / top15% / 概率加权 / 全部30特征 / 等权

  A. 样本权重(4种)
     A1 类别平衡: weight = 1/类别频率 (正例44% -> 提高正例权重)
     A2 波动率倒数: weight ∝ 1/vol_60 (贴合"低波动更易跑赢"的观察)
     A3 极端样本: weight ∝ |excess_fwd| (聚焦信息量大的样本)
     A4 逐期平衡: 每个交易日内正负例权重拉平(消除期与期之间的正例率差异)

  B. 特征筛选(3种)
     B1 去低增益: 剔 ret_lag1~20 等 gain<1000 的 10 个
     B2 去高冗余: 从每对 |相关|>0.8 中保留 gain 高的
     B3 双管齐下: B1 + B2

用法: python weight_feature_test.py            # 全部
      python weight_feature_test.py --what weight
      python weight_feature_test.py --what feature
"""
import argparse
import os
import sys
import time

import numpy as np
import pandas as pd
import lightgbm as lgb

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

from config import SEED, RESULTS_DIR
from data import load_cached
from zz_pool import BASE_FEATURES
from orthogonal_factors import attach_orthogonal_factors, ORTHO_FEATURES
from event_factors import build_event_factors
from tune_horizon_500 import get_pool, UNIVERSES, FC

LIQUIDITY_DROP = 0.2
MIN_TRAIN = 5000
H = 30
TOP_FRAC = 0.15
BUFFER = 0.35

# 诊断得出的低增益特征(gain < 1000)
LOW_GAIN = ["ret_lag1", "ret_lag2", "ret_lag3", "ret_lag4", "ret_lag5",
            "ret_lag10", "ret_lag20", "ma_ratio_5", "volume_ratio", "excess_5"]
# 高冗余对(保留 gain 高的那个)
#   mf_main_ratio_20(10088) > mf_divergence(15880)? 诊断里 mf_divergence 更高
#   实际 gain: mf_divergence=15880, mf_main_ratio_20=10088 -> 保留 divergence
#   macd_dif(16450) vs macd_dea(17079) -> 保留 dea
#   ma_ratio_20/rsi/boll: rsi=7022, 其他更低 -> 保留 rsi
REDUNDANT_DROP = ["mf_main_ratio_20", "macd_dif", "ma_ratio_20", "boll",
                  "excess_20", "ma_ratio_60"]


def run(pool, features, cost, weight_mode="equal"):
    dates = sorted(pool["date"].unique())
    start = next(i for i, d in enumerate(dates) if d >= pd.Timestamp("2017-01-01"))
    rebal = dates[start::H]
    rec = []
    prev_hold = set()
    for t in rebal:
        cutoff = t - pd.Timedelta(days=45)
        train = pool[(pool["date"] < cutoff) & pool["target_rel"].notna()].copy()
        Xtr = train[features].to_numpy(dtype=float)
        keep = np.isfinite(Xtr).any(axis=1)
        train, Xtr = train[keep], Xtr[keep]
        if len(train) < MIN_TRAIN:
            continue
        cross = pool[(pool["date"] == t) & pool["stock_fwd"].notna()].copy()
        if len(cross) < 30:
            continue

        # ---- 样本权重 ----
        w = None
        if weight_mode == "class_balance":
            y = train["target_rel"].to_numpy()
            pos = y.mean()
            w = np.where(y > 0, 0.5 / max(pos, 1e-6), 0.5 / max(1 - pos, 1e-6))
            w = w / w.mean()
        elif weight_mode == "inv_vol":
            v = train["vol_60"].to_numpy(dtype=float)
            v = np.nan_to_num(v, nan=np.nanmedian(v))
            v = np.clip(v, np.percentile(v, 5), np.percentile(v, 95))
            w = 1.0 / np.maximum(v, 1e-6)
            w = w / w.mean()
        elif weight_mode == "extreme":
            e = np.abs(train["excess_fwd"].to_numpy(dtype=float))
            e = np.nan_to_num(e, nan=np.nanmedian(e))
            e = np.clip(e, 0, np.percentile(e, 95))
            w = e / max(e.mean(), 1e-9)
        elif weight_mode == "period_balance":
            # 逐期(每个交易日)把正负例权重拉平
            y = train["target_rel"].to_numpy()
            d = train["date"].to_numpy()
            w = np.ones(len(train))
            dfw = pd.DataFrame({"d": d, "y": y, "i": np.arange(len(train))})
            for _, g in dfw.groupby("d"):
                p = g["y"].mean()
                if p <= 0 or p >= 1:
                    continue
                w[g["i"].to_numpy()] = np.where(g["y"].to_numpy() > 0, 0.5 / p,
                                                0.5 / (1 - p))
            w = w / w.mean()

        model = lgb.LGBMClassifier(
            n_estimators=150, learning_rate=0.10, num_leaves=63,
            subsample=0.8, colsample_bytree=0.8,
            random_state=SEED, verbosity=-1, n_jobs=-1)
        model.fit(Xtr, train["target_rel"].to_numpy(), sample_weight=w)
        cross["prob"] = model.predict_proba(cross[features].to_numpy(dtype=float))[:, 1]

        if cross["turnover"].notna().sum() > 10:
            th = cross["turnover"].quantile(LIQUIDITY_DROP)
            cross = cross[cross["turnover"] >= th]
        n_liq = len(cross)
        k = max(1, int(n_liq * TOP_FRAC))
        buf_k = max(k, int(n_liq * BUFFER))
        cross = cross.sort_values("prob", ascending=False)
        buf_codes = set(cross.head(buf_k)["code"])
        buyable = cross[cross["tradable_buy"].astype(bool)]
        keep_h = [c for c in prev_hold if c in buf_codes]
        final = keep_h[:k]
        for c in buyable["code"]:
            if len(final) >= k:
                break
            if c not in final:
                final.append(c)
        if not final:
            continue
        hold = set(final)
        turn = len(hold - prev_hold) / len(hold) if prev_hold else 1.0
        prev_hold = hold
        q = cross[cross["code"].isin(hold)].copy()
        p = q["prob"].to_numpy(dtype=float)
        ww = (0.5 + (p - p.min()) / (p.max() - p.min())) if (len(p) > 1 and p.max() > p.min()) \
            else np.ones(len(p))
        ww = ww / ww.sum()
        rec.append({"date": t, "hold": sorted(hold), "turn": turn, "w": ww.tolist(),
                    "excess": float(np.dot(ww, q["excess_fwd"].to_numpy()))})
    return rec


def metrics(rec, cache_dir, cost):
    dts = [r["date"] for r in rec]
    need = {c for r in rec for c in r["hold"]}
    px = {}
    for code in need:
        df = load_cached(code, cache_dir)
        if df is None:
            continue
        df = df[(df["date"] >= dts[0]) & (df["date"] <= dts[-1] + pd.Timedelta(days=1))]
        if len(df) >= 2:
            px[code] = df.set_index("date")["close"]
    mat = pd.DataFrame(px).sort_index().ffill()
    rets = mat.pct_change()
    segs = []
    for i, r in enumerate(rec[:-1]):
        hold = [c for c in r["hold"] if c in rets.columns]
        if not hold:
            continue
        win = rets.loc[(rets.index > dts[i]) & (rets.index <= dts[i + 1]), hold]
        if len(win) == 0:
            continue
        wmap = dict(zip(r["hold"], r["w"]))
        wv = np.array([wmap.get(c, 0.0) for c in hold], dtype=float)
        wv = wv / wv.sum() if wv.sum() > 0 else np.full(len(hold), 1.0 / len(hold))
        port = pd.Series(win.to_numpy() @ wv, index=win.index)
        port.iloc[0] -= r["turn"] * cost
        segs.append(port)
    pr = pd.concat(segs).sort_index()
    nav = (1 + pr).cumprod()
    exc = np.array([r["excess"] for r in rec])
    return dict(n=len(rec), turn=np.mean([r["turn"] for r in rec]),
                ann=float(nav.iloc[-1] ** (252 / len(pr)) - 1),
                ann_ex=float((1 + exc.mean()) ** (252 / H) - 1),
                dd=float((nav / nav.cummax() - 1).min()),
                sharpe=float(pr.mean() / pr.std(ddof=1) * np.sqrt(252)))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--what", default="all", choices=["weight", "feature", "all"])
    args = ap.parse_args()
    _, cost = UNIVERSES["500"]
    t0 = time.time()

    pool, cache_dir = get_pool("500", H)
    pool = attach_orthogonal_factors(pool, cache_dir)
    pool = build_event_factors(pool, cache_dir)
    all_feats = BASE_FEATURES + [f for f in ORTHO_FEATURES if f in pool.columns]
    all_feats += [f for f in FC["500"] if f in pool.columns]
    all_feats = [f for f in all_feats if f in pool.columns]
    print(f"中证500: pool {len(pool)} 条, 特征 {len(all_feats)}", flush=True)

    feats_b1 = [f for f in all_feats if f not in LOW_GAIN]
    feats_b2 = [f for f in all_feats if f not in REDUNDANT_DROP]
    feats_b3 = [f for f in all_feats if f not in LOW_GAIN and f not in REDUNDANT_DROP]

    header = (f"{'配置':<26}{'特征数':>7}{'期数':>6}{'换手':>7}{'年化绝对':>9}"
              f"{'最大回撤':>9}{'日频夏普':>9}{'年化超额':>9}")
    print("\n" + header, flush=True)
    print("-" * len(header), flush=True)
    rows = []

    if args.what in ("weight", "all"):
        for name, wm in [("基线(等权)", "equal"),
                         ("A1 类别平衡", "class_balance"),
                         ("A2 波动率倒数", "inv_vol"),
                         ("A3 极端样本", "extreme"),
                         ("A4 逐期平衡", "period_balance")]:
            t1 = time.time()
            m = metrics(run(pool, all_feats, cost, wm), cache_dir, cost)
            row = (f"{name:<26}{len(all_feats):>7}{m['n']:>6}{m['turn']:>7.1%}{m['ann']:>+9.2%}"
                   f"{m['dd']:>9.2%}{m['sharpe']:>9.3f}{m['ann_ex']:>+9.2%}")
            print(row + f"  ({time.time() - t1:.0f}s)", flush=True)
            rows.append((name, len(all_feats), m))

    if args.what in ("feature", "all"):
        for name, fs in [("B1 去低增益(剔10个)", feats_b1),
                         ("B2 去高冗余(剔6个)", feats_b2),
                         ("B3 双管齐下(剔16个)", feats_b3)]:
            t1 = time.time()
            m = metrics(run(pool, fs, cost, "equal"), cache_dir, cost)
            row = (f"{name:<26}{len(fs):>7}{m['n']:>6}{m['turn']:>7.1%}{m['ann']:>+9.2%}"
                   f"{m['dd']:>9.2%}{m['sharpe']:>9.3f}{m['ann_ex']:>+9.2%}")
            print(row + f"  ({time.time() - t1:.0f}s)", flush=True)
            rows.append((name, len(fs), m))

    base = rows[0][1] if rows else None
    bm = rows[0][2] if rows else None
    if bm:
        print(f"\n相对基线的增量:", flush=True)
        for name, nf, m in rows[1:]:
            print(f"  {name:<26} 年化绝对 {m['ann'] - bm['ann']:+.2%}  "
                  f"年化超额 {m['ann_ex'] - bm['ann_ex']:+.2%}  "
                  f"夏普 {m['sharpe'] - bm['sharpe']:+.3f}", flush=True)

    path = os.path.join(RESULTS_DIR, "weight_feature_zz500_report.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write("中证500 样本权重 与 特征筛选 实验\n")
        f.write("基线: 30天标签/缓冲0.35/top15%/概率加权/等权/全部特征\n\n")
        f.write(header + "\n")
        for name, nf, m in rows:
            f.write(f"{name:<26}{nf:>7}{m['n']:>6}{m['turn']:>7.1%}{m['ann']:>+9.2%}"
                    f"{m['dd']:>9.2%}{m['sharpe']:>9.3f}{m['ann_ex']:>+9.2%}\n")
        if bm:
            f.write("\n相对基线:\n")
            for name, nf, m in rows[1:]:
                f.write(f"  {name}: 年化绝对 {m['ann'] - bm['ann']:+.2%}, "
                        f"年化超额 {m['ann_ex'] - bm['ann_ex']:+.2%}, "
                        f"夏普 {m['sharpe'] - bm['sharpe']:+.3f}\n")
    print(f"\n报告已保存: {path}", flush=True)
    print(f"总耗时 {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
