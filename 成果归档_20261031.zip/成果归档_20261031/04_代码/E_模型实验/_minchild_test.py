"""验证 model_capacity_scan 里发现的未利用优化: min_child_samples=500。

背景(用户早期实验 results/model_capacity_scan_report.txt, 沪深300, IC 口径):
    num_leaves  min_child      Rank IC    ICIR    IC>0
    63          20(当前默认)   +0.0297  +0.267   62.6%
    63          500            +0.0344  +0.312   67.0%   <- IC 最高
    31          20             +0.0344  +0.285   63.5%
    31          500            +0.0310  +0.264   61.7%

也就是说: 当前用的 num_leaves=63 + 默认 min_child_samples=20 是**IC 最低**的组合;
显式设 min_child_samples=500 应该提升 IC(+0.0047)。但 IC 不等于净收益,
必须用扣费净收益复核(在本项目上已多次出现"IC 提升但净收益下降")。

用法: python _minchild_test.py [1000|500]
"""
import os
import sys
import time

import numpy as np
import pandas as pd
import lightgbm as lgb

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

from config import SEED, EMBARGO_DAYS, RESULTS_DIR
from data import load_cached
from zz_pool import BASE_FEATURES
from orthogonal_factors import attach_orthogonal_factors, ORTHO_FEATURES
from event_factors import build_event_factors
from _tune_model import get_pool

UNIVERSES = {"500": ("cache_zz500", 0.004), "1000": ("cache_zz1000", 0.005)}
LIQUIDITY_DROP = 0.2
MIN_TRAIN = 5000
H = 30
TOP_FRAC = 0.15
BUFFER = 0.5
FC = {"1000": ["fc_type", "fc_pchg_mid"], "500": ["fc_np_to_mv"]}

# (名称, num_leaves, min_child_samples)
CONFIGS = [
    ("当前: leaves=63, mcs=20(默认)", 63, 20),
    ("leaves=63, mcs=500", 63, 500),
    ("leaves=31, mcs=20", 31, 20),
    ("leaves=31, mcs=500", 31, 500),
    ("leaves=63, mcs=200", 63, 200),
]


def run(pool, features, cost, num_leaves, mcs):
    dates = sorted(pool["date"].unique())
    start = next(i for i, d in enumerate(dates) if d >= pd.Timestamp("2017-01-01"))
    rebal = dates[start::H]
    rec = []
    prev_hold = set()
    for t in rebal:
        cutoff = t - pd.Timedelta(days=EMBARGO_DAYS)
        train = pool[(pool["date"] < cutoff) & pool["target_rel"].notna()]
        Xtr = train[features].to_numpy(dtype=float)
        keep = np.isfinite(Xtr).any(axis=1)
        train, Xtr = train[keep], Xtr[keep]
        if len(train) < MIN_TRAIN:
            continue
        cross = pool[(pool["date"] == t) & pool["stock_fwd"].notna()].copy()
        if len(cross) < 30:
            continue
        model = lgb.LGBMClassifier(
            n_estimators=150, learning_rate=0.10, num_leaves=num_leaves,
            min_child_samples=mcs,
            subsample=0.8, colsample_bytree=0.8,
            random_state=SEED, verbosity=-1, n_jobs=-1)
        model.fit(Xtr, train["target_rel"].to_numpy())
        cross["prob"] = model.predict_proba(cross[features].to_numpy(dtype=float))[:, 1]
        if cross["turnover"].notna().sum() > 10:
            th = cross["turnover"].quantile(LIQUIDITY_DROP)
            cross = cross[cross["turnover"] >= th]
        n_liq = len(cross)
        k = max(1, int(n_liq * TOP_FRAC))
        buf_k = max(k, int(n_liq * BUFFER))
        cross = cross.sort_values("prob", ascending=False)
        buf_codes = set(cross.head(buf_k)["code"])
        buyable = cross[cross["tradable_buy"].astype(bool)]
        keep_h = [c for c in prev_hold if c in buf_codes]
        final = keep_h[:k]
        for c in buyable["code"]:
            if len(final) >= k:
                break
            if c not in final:
                final.append(c)
        if not final:
            continue
        hold = set(final)
        turn = len(hold - prev_hold) / len(hold) if prev_hold else 1.0
        prev_hold = hold
        q = cross[cross["code"].isin(hold)].copy()
        p = q["prob"].to_numpy(dtype=float)
        w = (0.5 + (p - p.min()) / (p.max() - p.min())) if (len(p) > 1 and p.max() > p.min()) \
            else np.ones(len(p))
        w = w / w.sum()
        # 同期 Rank IC(与净收益一起报, 看两者是否一致)
        ic = cross["prob"].corr(cross["excess_fwd"], method="spearman")
        rec.append({"date": t, "hold": sorted(hold), "turn": turn, "w": w.tolist(),
                    "ic": float(ic),
                    "gross": float(np.dot(w, q["stock_fwd"].to_numpy())),
                    "excess": float(np.dot(w, q["excess_fwd"].to_numpy()))})
    return rec


def metrics(rec, cache_dir, cost):
    dts = [r["date"] for r in rec]
    need = {c for r in rec for c in r["hold"]}
    px = {}
    for code in need:
        df = load_cached(code, cache_dir)
        if df is None:
            continue
        df = df[(df["date"] >= dts[0]) & (df["date"] <= dts[-1] + pd.Timedelta(days=1))]
        if len(df) >= 2:
            px[code] = df.set_index("date")["close"]
    mat = pd.DataFrame(px).sort_index().ffill()
    rets = mat.pct_change()
    segs = []
    for i, r in enumerate(rec[:-1]):
        hold = [c for c in r["hold"] if c in rets.columns]
        if not hold:
            continue
        win = rets.loc[(rets.index > dts[i]) & (rets.index <= dts[i + 1]), hold]
        if len(win) == 0:
            continue
        wmap = dict(zip(r["hold"], r["w"]))
        wv = np.array([wmap.get(c, 0.0) for c in hold], dtype=float)
        wv = wv / wv.sum() if wv.sum() > 0 else np.full(len(hold), 1.0 / len(hold))
        port = pd.Series(win.to_numpy() @ wv, index=win.index)
        port.iloc[0] -= r["turn"] * cost
        segs.append(port)
    pr = pd.concat(segs).sort_index()
    nav = (1 + pr).cumprod()
    net = np.array([r["gross"] for r in rec]) - np.array([r["turn"] for r in rec]) * cost
    exc = np.array([r["excess"] for r in rec])
    ics = np.array([r["ic"] for r in rec])
    return dict(n=len(rec), turn=np.mean([r["turn"] for r in rec]),
                net=net.mean(), ann=float(nav.iloc[-1] ** (252 / len(pr)) - 1),
                ann_ex=float((1 + exc.mean()) ** (252 / H) - 1),
                dd=float((nav / nav.cummax() - 1).min()),
                sharpe=float(pr.mean() / pr.std(ddof=1) * np.sqrt(252)),
                ic=float(np.nanmean(ics)),
                icir=float(np.nanmean(ics) / np.nanstd(ics)) if np.nanstd(ics) > 0 else np.nan)


def main():
    u = sys.argv[1] if len(sys.argv) > 1 else "1000"
    cache_dir, cost = UNIVERSES[u]
    t0 = time.time()
    pool, _, _ = get_pool(u, horizon=H)
    pool = attach_orthogonal_factors(pool, cache_dir)
    pool = build_event_factors(pool, cache_dir)
    feats = BASE_FEATURES + [f for f in ORTHO_FEATURES if f in pool.columns]
    feats += [f for f in FC[u] if f in pool.columns]
    print(f"中证{u} 特征数 {len(feats)}", flush=True)

    header = (f"{'配置':<28}{'RankIC':>9}{'ICIR':>8}{'换手':>7}{'净收益/期':>10}"
              f"{'年化绝对':>9}{'最大回撤':>9}{'日频夏普':>9}{'年化超额':>9}")
    print("\n" + header, flush=True)
    print("-" * len(header), flush=True)
    rows = []
    for name, nl, mcs in CONFIGS:
        t1 = time.time()
        m = metrics(run(pool, feats, cost, nl, mcs), cache_dir, cost)
        row = (f"{name:<28}{m['ic']:>+9.4f}{m['icir']:>+8.3f}{m['turn']:>7.1%}{m['net']:>+10.3%}"
               f"{m['ann']:>+9.2%}{m['dd']:>9.2%}{m['sharpe']:>9.3f}{m['ann_ex']:>+9.2%}")
        print(row + f"  ({time.time() - t1:.0f}s)", flush=True)
        rows.append((name, m))

    base = rows[0][1]
    print(f"\n相对当前配置的增量:", flush=True)
    for name, m in rows[1:]:
        print(f"  {name:<28} RankIC {m['ic'] - base['ic']:+.4f}  "
              f"年化绝对 {m['ann'] - base['ann']:+.2%}  "
              f"年化超额 {m['ann_ex'] - base['ann_ex']:+.2%}  "
              f"夏普 {m['sharpe'] - base['sharpe']:+.3f}", flush=True)

    path = os.path.join(RESULTS_DIR, f"minchild_zz{u}_report.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"中证{u} min_child_samples / num_leaves 复核(以扣费净收益为准)\n")
        f.write("动机: 用户早期 model_capacity_scan(沪深300, IC 口径)显示 mcs=500 的 IC 最高,\n")
        f.write("      而当前配置用的是默认 mcs=20(该扫描里 IC 最低)。需用净收益复核。\n\n")
        f.write(header + "\n" + "-" * len(header) + "\n")
        for name, m in rows:
            f.write(f"{name:<28}{m['ic']:>+9.4f}{m['icir']:>+8.3f}{m['turn']:>7.1%}{m['net']:>+10.3%}"
                    f"{m['ann']:>+9.2%}{m['dd']:>9.2%}{m['sharpe']:>9.3f}{m['ann_ex']:>+9.2%}\n")
        f.write("\n相对当前配置:\n")
        for name, m in rows[1:]:
            f.write(f"  {name}: RankIC {m['ic'] - base['ic']:+.4f}, "
                    f"年化绝对 {m['ann'] - base['ann']:+.2%}, "
                    f"年化超额 {m['ann_ex'] - base['ann_ex']:+.2%}\n")
    print(f"\n报告已保存: {path}", flush=True)
    print(f"总耗时 {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
