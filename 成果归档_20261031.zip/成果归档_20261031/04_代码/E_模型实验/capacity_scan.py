"""资金容量分析: 这套中证1000 策略能吃多少资金?

思路:
  1. 用 volume × close 近似成交额(前复权价格与成交量同比例缩放, 乘积口径一致)
  2. 每只股票的单日可交易量按"占 20 日均成交额的比例"约束
  3. 扫描资金量, 看多少比例的持仓会超过约束(超了就要么放弃、要么承担冲击成本)
  4. 顺带对比"换手率过滤"与"成交额过滤"选出的股票差异

注意: 这里的成交额是近似值(tushare daily 接口的 amount 更准, 但缓存里当初没存)。
绝对值可能有偏差, 用于比较不同资金量的相对可行性是可靠的。

用法: python capacity_scan.py [1000] [资金量万元...]
"""
import os
import sys

import numpy as np
import pandas as pd

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

from config import RESULTS_DIR
from data import load_cached

CACHE = {"500": "cache_zz500", "1000": "cache_zz1000"}
ADV_WINDOW = 20
# 单只股票单日最多吃掉其成交额的比例(冲击成本约束)
IMPACT_CAPS = [0.05, 0.10, 0.20]
# 默认扫描的资金量(万元)
CAPITALS = [100, 300, 500, 1000, 2000, 5000, 10000]


def adv_panel(cache_dir, codes, dts):
    """构造调仓日的 20 日均成交额面板(万元)。"""
    rows = {}
    for code in codes:
        df = load_cached(code, cache_dir)
        if df is None or len(df) < ADV_WINDOW + 5:
            continue
        df = df.sort_values("date").reset_index(drop=True)
        # 近似成交额: 成交量(手) × 收盘价 × 100(股/手) / 1e4 -> 万元
        amt = df["volume"].to_numpy() * df["close"].to_numpy() * 100 / 1e4
        s = pd.Series(amt, index=df["date"]).rolling(ADV_WINDOW, min_periods=10).mean()
        rows[code] = s
    panel = pd.DataFrame(rows).sort_index()
    return panel.reindex(dts, method="ffill").reindex(dts)


def main():
    u = sys.argv[1] if len(sys.argv) > 1 else "1000"
    cache_dir = CACHE[u]
    caps = [float(x) for x in sys.argv[2:]] or CAPITALS

    recs = pd.read_csv(os.path.join(RESULTS_DIR, f"compare_zz{u}_real_periods.csv"),
                       parse_dates=["date"]).sort_values("date").reset_index(drop=True)
    dts = list(recs["date"])
    holds = [eval(h) for h in recs["hold"]]
    print(f"复用逐期持仓 {len(recs)} 期, {dts[0].date()} ~ {dts[-1].date()}", flush=True)
    print(f"平均持仓 {np.mean([len(h) for h in holds]):.0f} 只", flush=True)

    all_codes = sorted({c for h in holds for c in h})
    panel = adv_panel(cache_dir, all_codes, dts)
    print(f"成交额面板 {panel.shape}, 覆盖 {panel.notna().all().sum()} 只", flush=True)

    # 每期每只持仓的 ADV
    adv_list, hold_list = [], []
    for t, h in zip(dts, holds):
        if t not in panel.index:
            continue
        row = panel.loc[t]
        advs = np.array([row.get(c, np.nan) for c in h], dtype=float)
        ok = np.isfinite(advs) & (advs > 0)
        if ok.sum() == 0:
            continue
        adv_list.append(advs[ok])
        hold_list.append(len(h))
    print(f"有效期数 {len(adv_list)}", flush=True)

    all_adv = np.concatenate(adv_list)
    print(f"\n持仓股票 20 日均成交额(万元): 中位数 {np.median(all_adv):,.0f}, "
          f"25% {np.percentile(all_adv, 25):,.0f}, 75% {np.percentile(all_adv, 75):,.0f}", flush=True)
    print(f"  最小 {all_adv.min():,.0f}, 最大 {all_adv.max():,.0f}", flush=True)

    print(f"\n=== 资金容量扫描 (约束: 单只股票单日成交不超过其 ADV 的一定比例) ===", flush=True)
    header = f"{'资金量(万)':>12}" + "".join(f"{f'占比<={c:.0%} 超限数/占比':>22}" for c in IMPACT_CAPS)
    print(header, flush=True)
    print("-" * len(header), flush=True)
    lines = [header, "-" * len(header)]

    for cap_w in caps:
        cap = cap_w * 1e4                     # 元
        row = f"{cap_w:>12,.0f}"
        for lim in IMPACT_CAPS:
            n_over = []
            for advs, nh in zip(adv_list, hold_list):
                pos_per_stock = cap / nh
                adv_yuan = advs * 1e4
                n_over.append(int(((pos_per_stock / adv_yuan) > lim).sum()))
            n_over = np.array(n_over)
            row += f"{n_over.mean():>14.1f}/{n_over.mean() / np.mean(hold_list):>6.1%}"
        print(row, flush=True)
        lines.append(row)

    # 最大可行资金量: 让 95% 分位的单只占比 <= lim
    print(f"\n=== 最大可行资金量(按 95% 分位不超限) ===", flush=True)
    for lim in IMPACT_CAPS:
        ok_caps = []
        for cap_w in [100, 200, 300, 500, 800, 1000, 1500, 2000, 3000, 5000, 8000, 10000, 20000]:
            cap = cap_w * 1e4
            ratios = np.concatenate([
                (cap / nh) / (advs * 1e4) for advs, nh in zip(adv_list, hold_list)
            ])
            if np.percentile(ratios, 95) <= lim:
                ok_caps.append(cap_w)
        max_cap = max(ok_caps) if ok_caps else 0
        line = f"  单只上限 {lim:.0%}: 最大约 {max_cap:,} 万元 (95% 持仓满足)"
        print(line, flush=True)
        lines.append(line)

    # 换手率过滤 vs 成交额过滤 的差异
    db = pd.read_csv(os.path.join(cache_dir, "_daily_basic.csv"),
                     parse_dates=["date"], dtype={"code": str})
    db = db.sort_values(["code", "date"])
    db["turn"] = db.groupby("code")["turnover_rate"].transform(
        lambda s: s.rolling(ADV_WINDOW, min_periods=10).mean())
    last_db = db["date"].max()
    snap = db[db["date"] == last_db].set_index("code")["turn"]
    common = [c for c in all_codes if c in snap.index and c in panel.columns]
    if common:
        turn_v = snap.reindex(common).to_numpy(dtype=float)
        adv_v = panel[common].iloc[-1].to_numpy(dtype=float)
        ok = np.isfinite(turn_v) & np.isfinite(adv_v) & (adv_v > 0)
        r = pd.Series(turn_v[ok]).corr(pd.Series(adv_v[ok]), method="spearman")
        print(f"\n换手率 与 成交额的横截面相关(Spearman): {r:.3f}", flush=True)
        print(f"  (换手率已在项目里被证明是 size 别名; 成交额是更直接的容量约束)", flush=True)
        lines.append(f"换手率 vs 成交额 秩相关 {r:.3f}")

    path = os.path.join(RESULTS_DIR, f"capacity_zz{u}_report.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"中证{u} 资金容量分析(成交额用 volume×close 近似)\n\n")
        f.write("\n".join(lines) + "\n")
    print(f"\n报告已保存: {path}", flush=True)


if __name__ == "__main__":
    main()
