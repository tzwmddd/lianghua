"""模型层调优: 多 seed 集成 + 时间衰减样本权重 + 目标函数, 全部以"扣费净超额"为准。

为什么用净超额而不是 IC 选参:
  这个项目的目标是收益, 而 IC 与扣费后净收益并不等价 —— 一个把 IC 提高 0.005
  但同时把换手从 47% 推到 75% 的改动, 净收益是负的。所以这里所有配置都用
  同一套可执行口径(zz_pool) + 同一套交易规则, 直接比最终净收益。

用真实中间价标注训练样本(改动 4):
  分类标签只看"是否跑赢", 对"赢 6 个点"和"赢 0.1 个点"一视同仁, 模型会把容量
  浪费在难以区分的边界样本上。这里改用 lambdarank 直接优化横截面排序,
  并对比它是否真的能改善净收益。

用法:
  python _tune_model.py 1000            # 跑核心配置
  python _tune_model.py 1000 --quick    # 只跑基准 + 两个配置
"""
import argparse
import os
import pickle
import sys
import time

import lightgbm as lgb
import numpy as np
import pandas as pd

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

from config import SEED, EMBARGO_DAYS, RESULTS_DIR
from data import load_cached
from zz_pool import build_pool, apply_constituents, BASE_FEATURES

UNIVERSES = {"500": ("cache_zz500", 0.004), "1000": ("cache_zz1000", 0.005)}
TEST_START = "2017-01-01"
TOP_FRAC = 0.2
LIQUIDITY_DROP = 0.2
MIN_TRAIN = 5000
H = 30
# 每次重训的交易日间隔(与主对照一致, 保证可比)
REBAL_STEP = 30


def get_pool(u, horizon=H):
    cache_dir, cost = UNIVERSES[u]
    pkl = os.path.join(RESULTS_DIR, f"_pool_zz{u}_H{horizon}_v2.pkl")
    if os.path.exists(pkl):
        return pd.read_pickle(pkl), cache_dir, cost
    pool = build_pool(cache_dir, horizon=horizon)
    pool = apply_constituents(pool, cache_dir)
    pool.to_pickle(pkl)
    return pool, cache_dir, cost


def rebal_calendar(pool, horizon):
    """各 horizon 共用的月末调仓日历。

    直接取 dates[start::horizon] 会让不同 horizon 落在完全不同的日子上,
    导致参数之间不可比。这里固定用"每月最后一个交易日"作为调仓日,
    horizon 只影响标签(未来多少天收益)与调仓间隔天数。
    """
    dates = sorted(pool["date"].unique())
    s = pd.Series(pd.to_datetime(dates))
    month_end = s.groupby(s.dt.to_period("M")).max()
    out = [d for d in month_end if d >= pd.Timestamp(TEST_START)]
    return sorted(out)


def train_predict(train, cross, features, n_seeds=1, base_seed=SEED,
                  half_life=None, objective="binary", rank_scheme="prob"):
    """训练(可多 seed 集成)并预测。

    half_life: 样本权重半衰期(交易日), None 表示等权。
    objective: binary(默认) / lambdarank(直接优化横截面排序)。
    rank_scheme: 对 lambdarank, 用 score 还是 prob 排序。
    """
    dates = np.sort(train["date"].unique())
    # 样本权重: 按"距最新训练日的交易日数"指数衰减, half_life 单位为交易日
    if half_life:
        last = train["date"].max()
        date_idx = pd.DatetimeIndex(dates)
        age = (last - date_idx).days.to_numpy() / 365.0 * 252.0   # 自然日 -> 交易日
        wser = pd.Series(0.5 ** (age / half_life), index=date_idx)
        w = train["date"].map(wser).to_numpy(dtype=float)
        w = w / w.mean()
    else:
        w = None

    preds = np.zeros(len(cross))
    for k in range(n_seeds):
        seed = base_seed + 17 * k
        if objective == "lambdarank":
            # 按日期分组, 标签 = 当期超额的横截面分位(0~9), 直接优化横截面排序
            tr = train.copy()
            tr["_g"] = tr.groupby("date")["excess_fwd"].transform(
                lambda s: pd.qcut(s.rank(method="first"), 10, labels=False))
            tr = tr[tr["_g"].notna()]
            wmap = None if w is None else dict(zip(train["date"], w))
            tr = tr.sort_values("date")
            groups = tr.groupby("date", sort=True).size().to_numpy()
            ds = lgb.Dataset(
                tr[BASE_FEATURES].to_numpy(),
                label=tr["_g"].to_numpy().astype(int),
                group=groups,
                weight=None if wmap is None else tr["date"].map(wmap).to_numpy(dtype=float),
            )
            params = dict(objective="lambdarank", metric="ndcg", ndcg_eval_at=[20],
                          learning_rate=0.10, num_leaves=63, subsample=0.8,
                          colsample_bytree=0.8, random_state=seed, verbose=-1,
                          num_threads=-1)
            booster = lgb.train(params, ds, num_boost_round=150)
            preds += booster.predict(cross[features].to_numpy())
        else:
            if objective == "regression":
                model = lgb.LGBMRegressor(
                    n_estimators=150, learning_rate=0.10, num_leaves=63,
                    subsample=0.8, colsample_bytree=0.8,
                    random_state=seed, verbosity=-1, n_jobs=-1)
                model.fit(train[BASE_FEATURES].to_numpy(),
                          train["target_rel"].to_numpy(dtype=float), sample_weight=w)
                preds += model.predict(cross[BASE_FEATURES].to_numpy())
            else:
                model = lgb.LGBMClassifier(
                    n_estimators=150, learning_rate=0.10, num_leaves=63,
                    subsample=0.8, colsample_bytree=0.8,
                    random_state=seed, verbosity=-1, n_jobs=-1)
                model.fit(train[BASE_FEATURES].to_numpy(), train["target_rel"].to_numpy(),
                          sample_weight=w)
                preds += model.predict_proba(cross[BASE_FEATURES].to_numpy())[:, 1]
    return preds / n_seeds


def run(pool, cache_dir, cost, n_seeds=1, half_life=None, objective="binary",
        weight_scheme="equal"):
    """weight_scheme: equal(等权) / prob(按预测概率加权) / rank(按排名加权)。

    等权假设"选中即同等看好", 但模型给出的概率本身有区分度 —— 概率 0.75 和 0.52
    被一视同仁, 等于丢掉了这部分信息。
    """
    dates = sorted(pool["date"].unique())
    start = next(i for i, d in enumerate(dates) if d >= pd.Timestamp(TEST_START))
    rebal = dates[start::REBAL_STEP]

    rec = []
    prev_hold = set()
    for t in rebal:
        cutoff = t - pd.Timedelta(days=EMBARGO_DAYS)
        train = pool[(pool["date"] < cutoff) & pool["target_rel"].notna()].dropna(subset=BASE_FEATURES)
        if len(train) < MIN_TRAIN:
            continue
        cross = pool[(pool["date"] == t) & pool["stock_fwd"].notna()].dropna(subset=BASE_FEATURES)
        if len(cross) < 30:
            continue
        cross = cross.copy()
        cross["prob"] = train_predict(train, cross, BASE_FEATURES, n_seeds,
                                      half_life=half_life, objective=objective)

        if cross["turnover"].notna().sum() > 10:
            th = cross["turnover"].quantile(LIQUIDITY_DROP)
            cross = cross[cross["turnover"] >= th]
        k = max(1, int(len(cross) * TOP_FRAC))
        cross = cross[cross["tradable_buy"].astype(bool)]
        if len(cross) < 30:
            continue
        q5 = cross.sort_values("prob", ascending=False).head(k).copy()
        hold = list(q5["code"])
        turn = len(set(hold) - prev_hold) / len(hold) if prev_hold else 1.0
        prev_hold = set(hold)

        if weight_scheme == "prob":
            w = q5["prob"].to_numpy(dtype=float)
            w = np.clip(w - w.min() + 1e-6, 1e-6, None)
            w = w / w.sum()
        elif weight_scheme == "rank":
            r = np.arange(len(q5), 0, -1, dtype=float)
            w = r / r.sum()
        else:
            w = np.full(len(q5), 1.0 / len(q5))
        rec.append({"date": t, "hold": hold, "turn": turn,
                    "w": w.tolist(),
                    "gross": float(np.dot(w, q5["stock_fwd"].to_numpy())),
                    "excess": float(np.dot(w, q5["excess_fwd"].to_numpy()))})
    return rec


def daily_metrics(rec, cache_dir, cost):
    """逐日盯市: 返回 年化绝对/最大回撤/日频夏普/年化超额。"""
    dts = [r["date"] for r in rec]
    need = set()
    for r in rec:
        need.update(r["hold"])
    px = {}
    for code in need:
        df = load_cached(code, cache_dir)
        if df is None:
            continue
        df = df[(df["date"] >= dts[0]) & (df["date"] <= dts[-1] + pd.Timedelta(days=1))]
        if len(df) >= 2:
            px[code] = df.set_index("date")["close"]
    mat = pd.DataFrame(px).sort_index().ffill()
    rets = mat.pct_change()
    segs = []
    for i, r in enumerate(rec[:-1]):
        hold = [c for c in r["hold"] if c in rets.columns]
        if not hold:
            continue
        win = rets.loc[(rets.index > dts[i]) & (rets.index <= dts[i + 1]), hold]
        if len(win) == 0:
            continue
        port = win.mean(axis=1)
        port.iloc[0] -= r["turn"] * cost
        segs.append(port)
    pr = pd.concat(segs).sort_index()
    nav = (1 + pr).cumprod()
    net = np.array([r["gross"] for r in rec]) - np.array([r["turn"] for r in rec]) * cost
    exc = np.array([r["excess"] for r in rec])
    return dict(
        n=len(rec),
        gross=np.mean([r["gross"] for r in rec]),
        net=net.mean(),
        ann=float(nav.iloc[-1] ** (252 / len(pr)) - 1),
        ann_ex=float((1 + exc.mean()) ** (252 / H) - 1),
        dd=float((nav / nav.cummax() - 1).min()),
        sharpe=float(pr.mean() / pr.std(ddof=1) * np.sqrt(252)),
        turn=np.mean([r["turn"] for r in rec]),
    )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("universe", nargs="?", default="1000", choices=["500", "1000"])
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--weight", action="store_true", help="只比较持仓加权方案")
    args = ap.parse_args()
    u = args.universe

    t0 = time.time()
    pool, cache_dir, cost = get_pool(u)
    print(f"pool {len(pool)} 条, {pool['code'].nunique()} 只", flush=True)

    if args.weight:
        configs = [
            ("等权", dict(n_seeds=1, weight_scheme="equal")),
            ("按概率加权", dict(n_seeds=1, weight_scheme="prob")),
            ("按排名加权", dict(n_seeds=1, weight_scheme="rank")),
        ]
    else:
        configs = [
            ("基准 1seed 等权", dict(n_seeds=1)),
            ("1seed+衰减500日", dict(n_seeds=1, half_life=500)),
            ("1seed+衰减250日", dict(n_seeds=1, half_life=250)),
            ("1seed+衰减125日", dict(n_seeds=1, half_life=125)),
            ("1seed+回归目标", dict(n_seeds=1, objective="regression")),
            ("1seed+衰减250+lambdarank", dict(n_seeds=1, half_life=250, objective="lambdarank")),
        ]
    if args.quick:
        configs = configs[:3]

    rows = []
    header = (f"{'配置':<22}{'期数':>5}{'换手':>7}{'毛收益/期':>10}{'净收益/期':>10}"
              f"{'年化绝对':>9}{'最大回撤':>9}{'日频夏普':>9}{'年化超额':>9}")
    print("\n" + header, flush=True)
    print("-" * len(header), flush=True)
    for name, kw in configs:
        t1 = time.time()
        rec = run(pool, cache_dir, cost, **kw)
        m = daily_metrics(rec, cache_dir, cost)
        row = (f"{name:<22}{m['n']:>5}{m['turn']:>7.1%}{m['gross']:>+10.3%}"
               f"{m['net']:>+10.3%}{m['ann']:>+9.2%}{m['dd']:>9.2%}"
               f"{m['sharpe']:>9.3f}{m['ann_ex']:>+9.2%}")
        print(row + f"   ({time.time() - t1:.0f}s)", flush=True)
        rows.append((name, m))
        pd.DataFrame(rec).to_csv(
            os.path.join(RESULTS_DIR, f"_tune_{u}_{name.split()[0]}.csv"),
            index=False, encoding="utf-8-sig")

    path = os.path.join(RESULTS_DIR, f"tune_model_zz{u}_report.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"中证{u} 模型层调优(全部以扣费净收益为准)\n")
        f.write(f"可执行口径, H={H}, 每 {REBAL_STEP} 交易日调仓, 成分过滤\n\n")
        f.write(header + "\n" + "-" * len(header) + "\n")
        for name, m in rows:
            f.write(f"{name:<22}{m['n']:>5}{m['turn']:>7.1%}{m['gross']:>+10.3%}"
                    f"{m['net']:>+10.3%}{m['ann']:>+9.2%}{m['dd']:>9.2%}"
                    f"{m['sharpe']:>9.3f}{m['ann_ex']:>+9.2%}\n")
    print(f"\n报告已保存: {path}", flush=True)
    print(f"总耗时 {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
