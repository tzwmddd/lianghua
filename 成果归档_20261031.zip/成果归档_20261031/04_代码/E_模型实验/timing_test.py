"""择时实验: 用逐日盯市净值评估指数均线择时的真实效果。

背景: 中证1000 可执行口径下年化超额 +7.85%, 但逐日盯市最大回撤 -44.6%。
      -44% 的回撤对 +5.4% 的年化绝对收益, 风险收益比不合格。
      择时的价值就是压这个回撤 —— 但必须用逐日净值来评估(调仓日采样会低估回撤)。

规则(全部只用当日及以前的指数数据, 无未来信息):
  A. 指数收盘 < MA20  -> 下期空仓
  B. 指数收盘 < MA60  -> 下期空仓
  C. 指数收盘 < MA20  -> 下期半仓; < MA60 -> 空仓
  D. 指数距 60 日高点回撤 > 10% -> 空仓(跟踪止损)
  E. 以上都不做(基准)

评估: 逐日净值、最大回撤、日频夏普、年化绝对、年化超额(相对指数)、
      以及择时带来的额外换手成本(降仓/回仓各算一次)。

用法: python timing_test.py [1000|500]
"""
import os
import sys
import time

import numpy as np
import pandas as pd

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

from config import RESULTS_DIR
from data import load_cached

CACHE = {"1000": "cache_zz1000", "500": "cache_zz500"}
H = 30
COST_SWITCH = 0.0015   # 一次"全仓进出"的成本(降仓+回仓, 仅仓位变动的部分)


def load_index(cache_dir):
    idx = pd.read_csv(os.path.join(cache_dir, "index.csv"), parse_dates=["date"])
    return idx.sort_values("date").set_index("date")["close"]


def build_signals(idx):
    """择时信号: 每个交易日给出"下期是否持有"的仓位建议(0/0.5/1)。"""
    ma20 = idx.rolling(20).mean()
    ma60 = idx.rolling(60).mean()
    hi60 = idx.rolling(60).max()
    sig = pd.DataFrame(index=idx.index)
    sig["below20"] = (idx < ma20)
    sig["below60"] = (idx < ma60)
    sig["dd10"] = (idx / hi60 - 1) < -0.10
    return sig


def positions(sig, name, idx=None):
    """按规则名生成每日目标仓位(0~1)。全部只用当日及以前的指数数据。"""
    if name == "none":
        return pd.Series(1.0, index=sig.index)
    if name == "below20":
        return (~sig["below20"]).astype(float)
    if name == "below60":
        return (~sig["below60"]).astype(float)
    if name == "half_below20":
        pos = pd.Series(1.0, index=sig.index)
        pos[sig["below20"]] = 0.5
        pos[sig["below60"]] = 0.0
        return pos
    if name == "dd10":
        return (~sig["dd10"]).astype(float)
    if name == "combine":
        pos = pd.Series(1.0, index=sig.index)
        pos[sig["below20"]] = 0.5
        pos[sig["below60"]] = 0.0
        pos[sig["dd10"]] = 0.0
        return pos
    if name == "ma20_scale":
        # 在 MA20 上方满仓; 下方按偏离程度线性降仓(偏离 -5% 时降到 0)
        dev = idx / idx.rolling(20).mean() - 1.0
        return (1.0 + dev / 0.05).clip(0.0, 1.0)
    if name == "ma20_scale_half":
        # 更温和: 偏离 -10% 才降到 0
        dev = idx / idx.rolling(20).mean() - 1.0
        return (1.0 + dev / 0.10).clip(0.0, 1.0)
    if name == "dd_scale":
        # 回撤越深仓位越低: 距 60 日高点 -5% 起降, -20% 降到 0
        dd = idx / idx.rolling(60).max() - 1.0
        return (1.0 + (dd + 0.05) / 0.15).clip(0.0, 1.0)
    raise ValueError(name)


def main():
    u = sys.argv[1] if len(sys.argv) > 1 else "1000"
    cache_dir = CACHE[u]
    t0 = time.time()

    # 复用 _compare_final 落盘的逐期持仓记录
    recs = pd.read_csv(os.path.join(RESULTS_DIR, f"compare_zz{u}_real_periods.csv"),
                       parse_dates=["date"])
    recs = recs.sort_values("date").reset_index(drop=True)
    dts = list(recs["date"])
    print(f"复用逐期持仓 {len(recs)} 期, {dts[0].date()} ~ {dts[-1].date()}", flush=True)

    idx = load_index(cache_dir)
    sig = build_signals(idx)

    # 逐日价格矩阵
    need = set()
    for h in recs["hold"]:
        need.update(eval(h) if isinstance(h, str) else h)
    px = {}
    for code in need:
        df = load_cached(code, cache_dir)
        if df is None:
            continue
        df = df[(df["date"] >= dts[0]) & (df["date"] <= dts[-1] + pd.Timedelta(days=1))]
        if len(df) >= 2:
            px[code] = df.set_index("date")["close"]
    mat = pd.DataFrame(px).sort_index().ffill()
    rets = mat.pct_change()
    idx_al = idx.reindex(mat.index).ffill()
    print(f"价格矩阵 {mat.shape}, 股票 {mat.shape[1]} 只", flush=True)

    results = []
    for name in ["none", "below20", "below60", "half_below20", "dd10", "combine",
                 "ma20_scale", "ma20_scale_half", "dd_scale"]:
        pos = positions(sig, name, idx).reindex(mat.index).ffill()
        # 调仓日之间的仓位: 用调仓日的信号决定整段(避免用到未来信息)
        segs = []
        prev_pos = 1.0
        switch_cost = []
        pos_used = []
        for i, r in recs.iterrows():
            t = r["date"]
            hold = [c for c in eval(r["hold"]) if c in rets.columns]
            if not hold:
                continue
            # 本期的目标仓位 = 调仓日当天收盘信号(只用当日及以前)
            p = float(pos.loc[pos.index <= t].iloc[-1]) if (pos.index <= t).any() else 1.0
            t_next = dts[i + 1] if i + 1 < len(dts) else mat.index[-1]
            win = rets.loc[(rets.index > t) & (rets.index <= t_next), hold]
            if len(win) == 0:
                continue
            port = win.mean(axis=1) * p
            if len(port):
                port.iloc[0] -= r["turn"] * 0.005 * p          # 换股成本按仓位缩放
                port.iloc[0] -= abs(p - prev_pos) * COST_SWITCH  # 仓位调整成本
            switch_cost.append(abs(p - prev_pos))
            pos_used.append(p)
            prev_pos = p
            segs.append(port)
        pr = pd.concat(segs).sort_index()
        nav = (1 + pr).cumprod()
        dd = float((nav / nav.cummax() - 1).min())
        sh = float(pr.mean() / pr.std(ddof=1) * np.sqrt(252))
        ann = float(nav.iloc[-1] ** (252 / len(pr)) - 1)
        # 相对指数的超额(同区间 buy&hold 指数)
        idx_ret = idx_al.pct_change().reindex(pr.index).fillna(0.0)
        ex = ((1 + pr).prod() / (1 + idx_ret).prod()) ** (252 / len(pr)) - 1
        results.append({
            "rule": name, "ann": ann, "dd": dd, "sharpe": sh, "excess": ex,
            "switch": float(np.mean(switch_cost)), "n_days": len(pr),
            "avg_pos": float(np.mean(pos_used)),
        })
        print(f"  完成 {name}", flush=True)

    print(f"\n=== 中证{u} 择时实验 (逐日盯市, 持有 {H} 天) ===", flush=True)
    header = (f"{'规则':<16}{'年化绝对':>10}{'最大回撤':>10}{'日频夏普':>10}"
              f"{'年化超额':>10}{'平均仓位':>9}{'仓位变动':>9}")
    print(header, flush=True)
    print("-" * len(header), flush=True)
    lines = [header, "-" * len(header)]
    for r in results:
        row = (f"{r['rule']:<16}{r['ann']:>+10.2%}{r['dd']:>10.2%}{r['sharpe']:>10.3f}"
               f"{r['excess']:>+10.2%}{r['avg_pos']:>9.1%}{r['switch']:>9.1%}")
        print(row, flush=True)
        lines.append(row)

    base = next(r for r in results if r["rule"] == "none")
    best = max((r for r in results if r["rule"] != "none"), key=lambda x: x["sharpe"])
    lines += ["", f"基准(不择时): 年化 {base['ann']:+.2%}, 回撤 {base['dd']:.2%}, 夏普 {base['sharpe']:.3f}",
              f"最优规则 {best['rule']}: 年化 {best['ann']:+.2%}, 回撤 {best['dd']:.2%}, "
              f"夏普 {best['sharpe']:.3f}",
              f"回撤改善 {best['dd'] - base['dd']:+.2%}, 夏普改善 {best['sharpe'] - base['sharpe']:+.3f}"]
    print("\n" + "\n".join(lines[-3:]), flush=True)

    path = os.path.join(RESULTS_DIR, f"timing_zz{u}_report.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"中证{u} 指数均线择时实验(逐日盯市)\n")
        f.write("仓位调整成本按一次全仓进出 0.15% 计\n\n")
        f.write("\n".join(lines) + "\n")
    print(f"\n报告已保存: {path}", flush=True)
    print(f"总耗时 {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
