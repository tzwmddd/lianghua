"""中证500 持有期(horizon)扫描 —— 可执行口径下的首次测试。

为什么这项最重要:
  你早期报告里有明确证据: 持有期 30 -> 60 天, 年化绝对 +2.23% -> +4.80%
  (+2.57 个点)。但那是**旧口径**(T+0 收盘成交、无退市收尾、无换手缓冲),
  而中证500 从没在可执行口径下单独测过持有期 —— 一直固定用 30 天。
  这项的潜在空间比缓冲带优化(+0.75)大得多。

口径:
  交易层用中证500 已验证的最优参数: 缓冲带 0.35 / top15% / 概率加权
  特征集用中证500 已验证的最优组合:
    技术面25 + 超额3 + 股东户数 + 资金流 + fc_np_to_mv
  调仓间隔 = horizon(持仓不重叠), 与早期实验一致。
  注意: 超额的年化换算用各自的 horizon, 所以不同 horizon 的"年化超额"可比;
        但因为复利基数不同, 建议同时看"净收益/期"和"年化绝对"。

用法: python tune_horizon_500.py            # 30/45/60
      python tune_horizon_500.py --h 30 90   # 自定义
"""
import argparse
import os
import sys
import time

import numpy as np
import pandas as pd
import lightgbm as lgb

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

from config import SEED, EMBARGO_DAYS, RESULTS_DIR
from data import load_cached
from zz_pool import BASE_FEATURES, build_pool, apply_constituents
from orthogonal_factors import attach_orthogonal_factors, ORTHO_FEATURES
from event_factors import build_event_factors

UNIVERSES = {"500": ("cache_zz500", 0.004), "1000": ("cache_zz1000", 0.005)}
LIQUIDITY_DROP = 0.2
MIN_TRAIN = 5000
TOP_FRAC = 0.15
BUFFER = {"500": 0.35, "1000": 0.5}
FC = {"500": ("fc_np_to_mv",), "1000": ("fc_type", "fc_pchg_mid")}


def get_pool(u, horizon):
    """按 horizon 构建/复用 pool。不同 horizon 的标签窗口不同, 必须分别构建。"""
    cache_dir, _ = UNIVERSES[u]
    pkl = os.path.join(RESULTS_DIR, f"_pool_zz{u}_H{horizon}_v2.pkl")
    if os.path.exists(pkl):
        return pd.read_pickle(pkl), cache_dir
    print(f"  构建 H={horizon} 的 pool ...", flush=True)
    pool = build_pool(cache_dir, horizon=horizon)
    pool = apply_constituents(pool, cache_dir)
    pool.to_pickle(pkl)
    return pool, cache_dir


def run(pool, features, cost, horizon, buffer_frac):
    dates = sorted(pool["date"].unique())
    start = next(i for i, d in enumerate(dates) if d >= pd.Timestamp("2017-01-01"))
    rebal = dates[start::horizon]
    rec = []
    prev_hold = set()
    for t in rebal:
        cutoff = t - pd.Timedelta(days=EMBARGO_DAYS)
        train = pool[(pool["date"] < cutoff) & pool["target_rel"].notna()]
        Xtr = train[features].to_numpy(dtype=float)
        keep = np.isfinite(Xtr).any(axis=1)
        train, Xtr = train[keep], Xtr[keep]
        if len(train) < MIN_TRAIN:
            continue
        cross = pool[(pool["date"] == t) & pool["stock_fwd"].notna()].copy()
        if len(cross) < 30:
            continue
        model = lgb.LGBMClassifier(
            n_estimators=150, learning_rate=0.10, num_leaves=63,
            subsample=0.8, colsample_bytree=0.8,
            random_state=SEED, verbosity=-1, n_jobs=-1)
        model.fit(Xtr, train["target_rel"].to_numpy())
        cross["prob"] = model.predict_proba(cross[features].to_numpy(dtype=float))[:, 1]
        if cross["turnover"].notna().sum() > 10:
            th = cross["turnover"].quantile(LIQUIDITY_DROP)
            cross = cross[cross["turnover"] >= th]
        n_liq = len(cross)
        k = max(1, int(n_liq * TOP_FRAC))
        buf_k = max(k, int(n_liq * buffer_frac))
        cross = cross.sort_values("prob", ascending=False)
        buf_codes = set(cross.head(buf_k)["code"])
        buyable = cross[cross["tradable_buy"].astype(bool)]
        keep_h = [c for c in prev_hold if c in buf_codes]
        final = keep_h[:k]
        for c in buyable["code"]:
            if len(final) >= k:
                break
            if c not in final:
                final.append(c)
        if not final:
            continue
        hold = set(final)
        turn = len(hold - prev_hold) / len(hold) if prev_hold else 1.0
        prev_hold = hold
        q = cross[cross["code"].isin(hold)].copy()
        p = q["prob"].to_numpy(dtype=float)
        w = (0.5 + (p - p.min()) / (p.max() - p.min())) if (len(p) > 1 and p.max() > p.min()) \
            else np.ones(len(p))
        w = w / w.sum()
        rec.append({"date": t, "hold": sorted(hold), "turn": turn, "w": w.tolist(),
                    "n": len(q),
                    "gross": float(np.dot(w, q["stock_fwd"].to_numpy())),
                    "excess": float(np.dot(w, q["excess_fwd"].to_numpy()))})
    return rec


def metrics(rec, cache_dir, cost, horizon):
    if not rec:
        return None
    dts = [r["date"] for r in rec]
    need = {c for r in rec for c in r["hold"]}
    px = {}
    for code in need:
        df = load_cached(code, cache_dir)
        if df is None:
            continue
        df = df[(df["date"] >= dts[0]) & (df["date"] <= dts[-1] + pd.Timedelta(days=1))]
        if len(df) >= 2:
            px[code] = df.set_index("date")["close"]
    mat = pd.DataFrame(px).sort_index().ffill()
    rets = mat.pct_change()
    segs = []
    for i, r in enumerate(rec[:-1]):
        hold = [c for c in r["hold"] if c in rets.columns]
        if not hold:
            continue
        win = rets.loc[(rets.index > dts[i]) & (rets.index <= dts[i + 1]), hold]
        if len(win) == 0:
            continue
        wmap = dict(zip(r["hold"], r["w"]))
        wv = np.array([wmap.get(c, 0.0) for c in hold], dtype=float)
        wv = wv / wv.sum() if wv.sum() > 0 else np.full(len(hold), 1.0 / len(hold))
        port = pd.Series(win.to_numpy() @ wv, index=win.index)
        port.iloc[0] -= r["turn"] * cost
        segs.append(port)
    pr = pd.concat(segs).sort_index()
    nav = (1 + pr).cumprod()
    net = np.array([r["gross"] for r in rec]) - np.array([r["turn"] for r in rec]) * cost
    exc = np.array([r["excess"] for r in rec])
    return dict(n=len(rec), hold=np.mean([r["n"] for r in rec]),
                turn=np.mean([r["turn"] for r in rec]),
                net=net.mean(), ann=float(nav.iloc[-1] ** (252 / len(pr)) - 1),
                ann_ex=float((1 + exc.mean()) ** (252 / horizon) - 1),
                dd=float((nav / nav.cummax() - 1).min()),
                sharpe=float(pr.mean() / pr.std(ddof=1) * np.sqrt(252)))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("universe", nargs="?", default="500", choices=["500", "1000"])
    ap.add_argument("--h", type=int, nargs="*", default=[30, 45, 60])
    args = ap.parse_args()
    u = args.universe
    _, cost = UNIVERSES[u]
    t0 = time.time()

    header = (f"{'持有期':>7}{'期数':>6}{'持仓':>6}{'换手':>7}{'净收益/期':>10}{'毛收益/期':>10}"
              f"{'年化绝对':>9}{'最大回撤':>9}{'日频夏普':>9}{'年化超额':>9}")
    print(f"\n=== 中证{u} 持有期扫描 (可执行口径, 缓冲带 {BUFFER[u]}, top{TOP_FRAC:.0%}) ===",
          flush=True)
    print(header, flush=True)
    print("-" * len(header), flush=True)
    rows = []
    for h in args.h:
        t1 = time.time()
        pool, cache_dir = get_pool(u, h)
        pool = attach_orthogonal_factors(pool, cache_dir)
        pool = build_event_factors(pool, cache_dir)
        feats = BASE_FEATURES + [f for f in ORTHO_FEATURES if f in pool.columns]
        feats += [f for f in FC[u] if f in pool.columns]
        m = metrics(run(pool, feats, cost, h, BUFFER[u]), cache_dir, cost, h)
        if m is None:
            print(f"{h:>6}天  无有效结果", flush=True)
            continue
        gross_avg = m["net"] + m["turn"] * cost
        row = (f"{h:>6}天{m['n']:>6}{m['hold']:>6.0f}{m['turn']:>7.1%}{m['net']:>+10.3%}"
               f"{gross_avg:>+10.3%}"
               f"{m['ann']:>+9.2%}{m['dd']:>9.2%}{m['sharpe']:>9.3f}{m['ann_ex']:>+9.2%}")
        print(row + f"  ({time.time() - t1:.0f}s)", flush=True)
        rows.append((h, m))

    if rows:
        best = max(rows, key=lambda r: r[1]["ann"])
        cur = [r for r in rows if r[0] == 30]
        print(f"\n  最优持有期 {best[0]} 天: 年化绝对 {best[1]['ann']:+.2%}, "
              f"夏普 {best[1]['sharpe']:.3f}", flush=True)
        if cur:
            print(f"  相对当前(30天): 年化绝对 {best[1]['ann'] - cur[0][1]['ann']:+.2%}, "
                  f"夏普 {best[1]['sharpe'] - cur[0][1]['sharpe']:+.3f}", flush=True)

    path = os.path.join(RESULTS_DIR, f"tune_horizon_zz{u}_report.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"中证{u} 持有期扫描(可执行口径)\n")
        f.write(f"缓冲带 {BUFFER[u]} / top{TOP_FRAC:.0%} / 概率加权\n\n")
        f.write(header + "\n")
        for h, m in rows:
            f.write(f"{h}天\t{m['n']}期\t持{m['hold']:.0f}\t换手{m['turn']:.1%}\t"
                    f"净{m['net']:+.3%}\t年化{m['ann']:+.2%}\t回撤{m['dd']:.2%}\t"
                    f"夏普{m['sharpe']:.3f}\t超额{m['ann_ex']:+.2%}\n")
    print(f"\n报告已保存: {path}", flush=True)
    print(f"总耗时 {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
