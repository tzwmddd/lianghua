"""交易层参数联合优化: 持有期 × 换手缓冲带, 目标 = 扣费净超额。

为什么单独做这一层:
  你之前的实验是分开做的(先扫持有期、再在 60 天上扫缓冲带), 而两者会互相影响:
  缓冲带的效果取决于信号衰减速度, 而信号衰减速度又取决于持有期。
  这里做二维联合扫描, 并且用统一的可执行口径(t+1 开盘成交 + 退市收尾 + 剔涨停)。

另外把"净收益/期"和"年化"分开看 —— 换手缓冲降低换手率, 但如果同时把信号质量
也砍掉了, 净收益/期 会下降, 只是年化因调仓频率下降而好看。两个口径都要报。

用法: python _tune_trade.py 1000
"""
import argparse
import os
import sys
import time

import numpy as np
import pandas as pd
import lightgbm as lgb

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

from config import SEED, EMBARGO_DAYS, RESULTS_DIR
from data import load_cached
from zz_pool import BASE_FEATURES
from _tune_model import get_pool

TEST_START = "2017-01-01"

UNIVERSES = {"500": ("cache_zz500", 0.004), "1000": ("cache_zz1000", 0.005)}
TOP_FRAC = 0.2
LIQUIDITY_DROP = 0.2
MIN_TRAIN = 5000
HORIZONS = [30, 45, 60]
BUFFERS = [0.5, 0.6, 0.7, 0.8]   # 缓冲带占候选池比例; 0.2 == 无缓冲(等于 TOP_FRAC)


def rebal_fixed(pool, horizon):
    """固定间隔调仓: 每 horizon 个交易日调一次, 与标签窗口对齐(不重叠)。

    原本想用月末调仓(更贴近实操), 但月末间隔约 21 个交易日, 而标签是未来 30 天,
    会造成调仓频率与标签窗口不匹配(每期标签重叠), 参数之间不可比。
    这里统一用固定间隔, 与主对照口径一致。
    """
    dates = sorted(pool["date"].unique())
    start = next(i for i, d in enumerate(dates) if d >= pd.Timestamp(TEST_START))
    return dates[start::horizon]


def run(pool, horizon, buffer_frac, cost, cal, weight_scheme="equal"):
    """单次回测。缓冲逻辑: 旧持仓中仍在 top buffer_frac 内的保留, 再用新高分填满。"""
    rec = []
    prev_hold = set()
    tgt_col = "target_rel"
    for t in cal:
        cutoff = t - pd.Timedelta(days=EMBARGO_DAYS)
        train = pool[(pool["date"] < cutoff) & pool[tgt_col].notna()].dropna(subset=BASE_FEATURES)
        if len(train) < MIN_TRAIN:
            continue
        cross = pool[(pool["date"] == t) & pool["stock_fwd"].notna()].dropna(subset=BASE_FEATURES)
        if len(cross) < 30:
            continue
        model = lgb.LGBMClassifier(
            n_estimators=150, learning_rate=0.10, num_leaves=63,
            subsample=0.8, colsample_bytree=0.8,
            random_state=SEED, verbosity=-1, n_jobs=-1)
        model.fit(train[BASE_FEATURES].to_numpy(), train[tgt_col].to_numpy())

        cross = cross.copy()
        cross["prob"] = model.predict_proba(cross[BASE_FEATURES].to_numpy())[:, 1]
        if cross["turnover"].notna().sum() > 10:
            th = cross["turnover"].quantile(LIQUIDITY_DROP)
            cross = cross[cross["turnover"] >= th]
        n_liq = len(cross)
        k = max(1, int(n_liq * TOP_FRAC))
        buf_k = max(k, int(n_liq * buffer_frac))
        cross = cross.sort_values("prob", ascending=False)
        buf_codes = set(cross.head(buf_k)["code"])
        buyable = cross[cross["tradable_buy"].astype(bool)]

        keep = [c for c in prev_hold if c in buf_codes]
        final = keep[:k]
        for c in buyable["code"]:
            if len(final) >= k:
                break
            if c not in final:
                final.append(c)
        if not final:
            continue
        hold = set(final)
        turn = len(hold - prev_hold) / len(hold) if prev_hold else 1.0
        prev_hold = hold
        held = cross[cross["code"].isin(hold)].copy()
        if weight_scheme == "prob":
            w = held["prob"].to_numpy(dtype=float)
            w = np.clip(w - w.min() + 1e-6, 1e-6, None)
            w = w / w.sum()
        elif weight_scheme == "rank":
            r = np.arange(len(held), 0, -1, dtype=float)
            w = r / r.sum()
        else:
            w = np.full(len(held), 1.0 / len(held))
        rec.append({"date": t, "hold": sorted(hold), "turn": turn, "w": w.tolist(),
                    "gross": float(np.dot(w, held["stock_fwd"].to_numpy())),
                    "excess": float(np.dot(w, held["excess_fwd"].to_numpy()))})
    return rec


def metrics(rec, cache_dir, cost, horizon):
    dts = [r["date"] for r in rec]
    need = {c for r in rec for c in r["hold"]}
    px = {}
    for code in need:
        df = load_cached(code, cache_dir)
        if df is None:
            continue
        df = df[(df["date"] >= dts[0]) & (df["date"] <= dts[-1] + pd.Timedelta(days=1))]
        if len(df) >= 2:
            px[code] = df.set_index("date")["close"]
    mat = pd.DataFrame(px).sort_index().ffill()
    rets = mat.pct_change()
    segs = []
    for i, r in enumerate(rec[:-1]):
        hold = [c for c in r["hold"] if c in rets.columns]
        if not hold:
            continue
        win = rets.loc[(rets.index > dts[i]) & (rets.index <= dts[i + 1]), hold]
        if len(win) == 0:
            continue
        wmap = dict(zip(r["hold"], r["w"]))
        wv = np.array([wmap.get(c, 0.0) for c in hold], dtype=float)
        wv = wv / wv.sum() if wv.sum() > 0 else np.full(len(hold), 1.0 / len(hold))
        port = win.to_numpy() @ wv
        port = pd.Series(port, index=win.index)
        port.iloc[0] -= r["turn"] * cost
        segs.append(port)
    pr = pd.concat(segs).sort_index()
    nav = (1 + pr).cumprod()
    net = np.array([r["gross"] for r in rec]) - np.array([r["turn"] for r in rec]) * cost
    exc = np.array([r["excess"] for r in rec])
    return dict(
        n=len(rec), turn=np.mean([r["turn"] for r in rec]),
        gross=np.mean([r["gross"] for r in rec]), net=net.mean(),
        ann=float(nav.iloc[-1] ** (252 / len(pr)) - 1),
        ann_ex=float((1 + exc.mean()) ** (252 / horizon) - 1),
        dd=float((nav / nav.cummax() - 1).min()),
        sharpe=float(pr.mean() / pr.std(ddof=1) * np.sqrt(252)),
    )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("universe", nargs="?", default="1000", choices=["500", "1000"])
    ap.add_argument("--weight", action="store_true",
                    help="只做加权方案对比(固定 H=30, 无缓冲), 快很多")
    args = ap.parse_args()
    u = args.universe
    cache_dir, cost = UNIVERSES[u]
    t0 = time.time()

    if args.weight:
        pool, _, _ = get_pool(u, horizon=30)
        cal = rebal_fixed(pool, 30)
        print(f"加权方案对比: pool {len(pool)} 条, 调仓 {len(cal)} 期", flush=True)
        header = (f"{'加权方案':>10}{'期数':>6}{'换手':>7}{'毛收益/期':>10}"
                  f"{'净收益/期':>10}{'年化绝对':>9}{'最大回撤':>9}{'日频夏普':>9}{'年化超额':>9}")
        print("\n" + header, flush=True)
        print("-" * len(header), flush=True)
        rows = []
        for ws in ["equal", "prob", "rank"]:
            rec = run(pool, 30, 0.2, cost, cal, weight_scheme=ws)
            m = metrics(rec, cache_dir, cost, 30)
            row = (f"{ws:>10}{m['n']:>6}{m['turn']:>7.1%}{m['gross']:>+10.3%}"
                   f"{m['net']:>+10.3%}{m['ann']:>+9.2%}{m['dd']:>9.2%}"
                   f"{m['sharpe']:>9.3f}{m['ann_ex']:>+9.2%}")
            print(row, flush=True)
            rows.append((ws, m))
        path = os.path.join(RESULTS_DIR, f"tune_weight_zz{u}_report.txt")
        with open(path, "w", encoding="utf-8") as f:
            f.write(f"中证{u} 持仓加权方案对比(可执行口径, H=30, 无缓冲)\n\n")
            f.write(header + "\n" + "-" * len(header) + "\n")
            for ws, m in rows:
                f.write(f"{ws:>10}{m['n']:>6}{m['turn']:>7.1%}{m['gross']:>+10.3%}"
                        f"{m['net']:>+10.3%}{m['ann']:>+9.2%}{m['dd']:>9.2%}"
                        f"{m['sharpe']:>9.3f}{m['ann_ex']:>+9.2%}\n")
        print(f"\n报告已保存: {path}", flush=True)
        print(f"总耗时 {time.time() - t0:.0f}s", flush=True)
        return

    pools, cals = {}, {}
    for h in HORIZONS:
        p, _, _ = get_pool(u, horizon=h)
        pools[h] = p
        cals[h] = rebal_fixed(p, h)
        print(f"H={h}: pool {len(p)} 条, 调仓 {len(cals[h])} 期", flush=True)

    header = (f"{'持有期':>7}{'缓冲带':>8}{'期数':>6}{'换手':>7}{'毛收益/期':>10}"
              f"{'净收益/期':>10}{'年化绝对':>9}{'最大回撤':>9}{'日频夏普':>9}{'年化超额':>9}")
    print("\n" + header, flush=True)
    print("-" * len(header), flush=True)
    rows = []
    for h in HORIZONS:
        for bf in BUFFERS:
            t1 = time.time()
            rec = run(pools[h], h, bf, cost, cals[h])
            if not rec:
                continue
            m = metrics(rec, cache_dir, cost, h)
            row = (f"{h:>6}天{bf:>8.0%}{m['n']:>6}{m['turn']:>7.1%}{m['gross']:>+10.3%}"
                   f"{m['net']:>+10.3%}{m['ann']:>+9.2%}{m['dd']:>9.2%}"
                   f"{m['sharpe']:>9.3f}{m['ann_ex']:>+9.2%}")
            print(row + f"  ({time.time() - t1:.0f}s)", flush=True)
            rows.append((h, bf, m))

    path = os.path.join(RESULTS_DIR, f"tune_trade_zz{u}_report.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"中证{u} 交易层参数联合优化(持有期 × 换手缓冲带)\n")
        f.write("可执行口径(t+1开盘成交 + 退市收尾 + 剔涨停), 月末调仓\n\n")
        f.write(header + "\n" + "-" * len(header) + "\n")
        for h, bf, m in rows:
            f.write(f"{h:>6}天{bf:>8.0%}{m['n']:>6}{m['turn']:>7.1%}{m['gross']:>+10.3%}"
                    f"{m['net']:>+10.3%}{m['ann']:>+9.2%}{m['dd']:>9.2%}"
                    f"{m['sharpe']:>9.3f}{m['ann_ex']:>+9.2%}\n")
    print(f"\n报告已保存: {path}", flush=True)
    print(f"总耗时 {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()

