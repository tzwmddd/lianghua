"""选股范围优化: TOP_FRAC (Q5/Q10/Q3) 在可执行口径下的净收益对比。

动机: 157 只等权(Q5) 是最常见的做法, 但不一定最优。缩小到 Q10/Q20 会:
  优点 —— 集中持有模型最看好的股票, alpha 更浓;
  缺点 —— 分散度下降, 个股风险上升, 组合波动变大。
反过来放大到 Q3 会更稳但 alpha 更淡。哪个净收益更高要用数据说话。

同时报告"平均单只超额"(=组合超额 / 持仓数)以看清 alpha 浓度。

用法: python q_frac_test.py [1000]
"""
import os
import sys
import time

import numpy as np
import pandas as pd
import lightgbm as lgb

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

from config import SEED, EMBARGO_DAYS, RESULTS_DIR
from data import load_cached
from zz_pool import BASE_FEATURES
from _tune_model import get_pool, TEST_START, REBAL_STEP

UNIVERSES = {"500": ("cache_zz500", 0.004), "1000": ("cache_zz1000", 0.005)}
LIQUIDITY_DROP = 0.2
MIN_TRAIN = 5000
H = 30
TOP_FRACS = [0.1, 0.15, 0.2, 0.3]
BUFFER = 0.5        # 用已找到的最优缓冲带


def run_combined(pool, top_frac, buffer, cost, use_weight):
    """组合最优化的最终验证: 选股范围 + 缓冲带 + 概率加权 三项一起上。"""
    dates = sorted(pool["date"].unique())
    start = next(i for i, d in enumerate(dates) if d >= pd.Timestamp(TEST_START))
    rebal = dates[start::REBAL_STEP]

    rec = []
    prev_hold = set()
    for t in rebal:
        cutoff = t - pd.Timedelta(days=EMBARGO_DAYS)
        train = pool[(pool["date"] < cutoff) & pool["target_rel"].notna()].dropna(subset=BASE_FEATURES)
        if len(train) < MIN_TRAIN:
            continue
        cross = pool[(pool["date"] == t) & pool["stock_fwd"].notna()].dropna(subset=BASE_FEATURES)
        if len(cross) < 30:
            continue
        model = lgb.LGBMClassifier(
            n_estimators=150, learning_rate=0.10, num_leaves=63,
            subsample=0.8, colsample_bytree=0.8,
            random_state=SEED, verbosity=-1, n_jobs=-1)
        model.fit(train[BASE_FEATURES].to_numpy(), train["target_rel"].to_numpy())
        cross = cross.copy()
        cross["prob"] = model.predict_proba(cross[BASE_FEATURES].to_numpy())[:, 1]
        if cross["turnover"].notna().sum() > 10:
            th = cross["turnover"].quantile(LIQUIDITY_DROP)
            cross = cross[cross["turnover"] >= th]
        n_liq = len(cross)
        k = max(1, int(n_liq * top_frac))
        buf_k = max(k, int(n_liq * buffer))
        cross = cross.sort_values("prob", ascending=False)
        buf_codes = set(cross.head(buf_k)["code"])
        buyable = cross[cross["tradable_buy"].astype(bool)]
        keep = [c for c in prev_hold if c in buf_codes]
        final = keep[:k]
        for c in buyable["code"]:
            if len(final) >= k:
                break
            if c not in final:
                final.append(c)
        if not final:
            continue
        hold = set(final)
        turn = len(hold - prev_hold) / len(hold) if prev_hold else 1.0
        prev_hold = hold
        q = cross[cross["code"].isin(hold)].copy()
        p = q["prob"].to_numpy(dtype=float)
        if use_weight and len(p) > 1 and p.max() > p.min():
            w = 0.5 + (p - p.min()) / (p.max() - p.min())
            w = w / w.sum()
        else:
            w = np.full(len(q), 1.0 / len(q))
        rec.append({"date": t, "hold": sorted(hold), "turn": turn, "w": w.tolist(),
                    "n": len(q),
                    "gross": float(np.dot(w, q["stock_fwd"].to_numpy())),
                    "excess": float(np.dot(w, q["excess_fwd"].to_numpy()))})
    return rec


def run(pool, top_frac, cost, weight_scheme="prob"):
    dates = sorted(pool["date"].unique())
    start = next(i for i, d in enumerate(dates) if d >= pd.Timestamp(TEST_START))
    rebal = dates[start::REBAL_STEP]

    rec = []
    prev_hold = set()
    for t in rebal:
        cutoff = t - pd.Timedelta(days=EMBARGO_DAYS)
        train = pool[(pool["date"] < cutoff) & pool["target_rel"].notna()].dropna(subset=BASE_FEATURES)
        if len(train) < MIN_TRAIN:
            continue
        cross = pool[(pool["date"] == t) & pool["stock_fwd"].notna()].dropna(subset=BASE_FEATURES)
        if len(cross) < 30:
            continue
        model = lgb.LGBMClassifier(
            n_estimators=150, learning_rate=0.10, num_leaves=63,
            subsample=0.8, colsample_bytree=0.8,
            random_state=SEED, verbosity=-1, n_jobs=-1)
        model.fit(train[BASE_FEATURES].to_numpy(), train["target_rel"].to_numpy())

        cross = cross.copy()
        cross["prob"] = model.predict_proba(cross[BASE_FEATURES].to_numpy())[:, 1]
        if cross["turnover"].notna().sum() > 10:
            th = cross["turnover"].quantile(LIQUIDITY_DROP)
            cross = cross[cross["turnover"] >= th]
        n_liq = len(cross)
        k = max(1, int(n_liq * top_frac))
        buf_k = max(k, int(n_liq * BUFFER))
        cross = cross.sort_values("prob", ascending=False)
        buf_codes = set(cross.head(buf_k)["code"])
        buyable = cross[cross["tradable_buy"].astype(bool)]
        keep = [c for c in prev_hold if c in buf_codes]
        final = keep[:k]
        for c in buyable["code"]:
            if len(final) >= k:
                break
            if c not in final:
                final.append(c)
        if not final:
            continue
        hold = set(final)
        turn = len(hold - prev_hold) / len(hold) if prev_hold else 1.0
        prev_hold = hold
        q = cross[cross["code"].isin(hold)].copy()
        p = q["prob"].to_numpy(dtype=float)
        if weight_scheme == "prob" and len(p) > 1 and p.max() > p.min():
            w = 0.5 + (p - p.min()) / (p.max() - p.min())
            w = w / w.sum()
        else:
            w = np.full(len(q), 1.0 / len(q))
        rec.append({"date": t, "hold": sorted(hold), "turn": turn, "w": w.tolist(),
                    "n": len(q),
                    "gross": float(np.dot(w, q["stock_fwd"].to_numpy())),
                    "excess": float(np.dot(w, q["excess_fwd"].to_numpy())),
                    "excess_eq": float(q["excess_fwd"].mean())})
    return rec


def metrics(rec, cache_dir, cost):
    dts = [r["date"] for r in rec]
    need = {c for r in rec for c in r["hold"]}
    px = {}
    for code in need:
        df = load_cached(code, cache_dir)
        if df is None:
            continue
        df = df[(df["date"] >= dts[0]) & (df["date"] <= dts[-1] + pd.Timedelta(days=1))]
        if len(df) >= 2:
            px[code] = df.set_index("date")["close"]
    mat = pd.DataFrame(px).sort_index().ffill()
    rets = mat.pct_change()
    segs = []
    for i, r in enumerate(rec[:-1]):
        hold = [c for c in r["hold"] if c in rets.columns]
        if not hold:
            continue
        win = rets.loc[(rets.index > dts[i]) & (rets.index <= dts[i + 1]), hold]
        if len(win) == 0:
            continue
        wmap = dict(zip(r["hold"], r["w"]))
        wv = np.array([wmap.get(c, 0.0) for c in hold], dtype=float)
        wv = wv / wv.sum() if wv.sum() > 0 else np.full(len(hold), 1.0 / len(hold))
        port = pd.Series(win.to_numpy() @ wv, index=win.index)
        port.iloc[0] -= r["turn"] * cost
        segs.append(port)
    pr = pd.concat(segs).sort_index()
    nav = (1 + pr).cumprod()
    net = np.array([r["gross"] for r in rec]) - np.array([r["turn"] for r in rec]) * cost
    exc = np.array([r["excess"] for r in rec])
    return dict(
        n=len(rec), hold=np.mean([r["n"] for r in rec]),
        turn=np.mean([r["turn"] for r in rec]),
        gross=np.mean([r["gross"] for r in rec]), net=net.mean(),
        ann=float(nav.iloc[-1] ** (252 / len(pr)) - 1),
        ann_ex=float((1 + exc.mean()) ** (252 / H) - 1),
        per_stock=float(exc.mean() / np.mean([r["n"] for r in rec])),
        dd=float((nav / nav.cummax() - 1).min()),
        sharpe=float(pr.mean() / pr.std(ddof=1) * np.sqrt(252)),
        vol=float(pr.std(ddof=1) * np.sqrt(252)),
    )


def compare_final(u):
    """最终验证: 三条优化路径能否叠加。"""
    cache_dir, cost = UNIVERSES[u]
    t0 = time.time()
    pool, _, _ = get_pool(u, horizon=H)
    configs = [
        ("原始基准(top20/无缓冲/等权)", dict(top_frac=0.2, buffer=0.2, use_weight=False)),
        ("+缓冲50%", dict(top_frac=0.2, buffer=0.5, use_weight=False)),
        ("+缓冲50%+概率加权", dict(top_frac=0.2, buffer=0.5, use_weight=True)),
        ("最终(收窄15%+缓冲50%+加权)", dict(top_frac=0.15, buffer=0.5, use_weight=True)),
    ]
    header = (f"{'配置':<26}{'持仓':>6}{'换手':>7}{'净收益/期':>10}{'年化绝对':>9}"
              f"{'最大回撤':>9}{'日频夏普':>9}{'年化超额':>9}")
    print("\n" + header, flush=True)
    print("-" * len(header), flush=True)
    rows = []
    for name, kw in configs:
        rec = run_combined(pool, **kw, cost=cost)
        m = metrics(rec, cache_dir, cost)
        row = (f"{name:<26}{m['hold']:>6.0f}{m['turn']:>7.1%}{m['net']:>+10.3%}"
               f"{m['ann']:>+9.2%}{m['dd']:>9.2%}{m['sharpe']:>9.3f}{m['ann_ex']:>+9.2%}")
        print(row, flush=True)
        rows.append((name, m))
    base = rows[0][1]
    fin = rows[-1][1]
    print(f"\n叠加效果: 年化绝对 {base['ann']:+.2%} -> {fin['ann']:+.2%} "
          f"({fin['ann'] - base['ann']:+.2%}), 年化超额 {base['ann_ex']:+.2%} -> "
          f"{fin['ann_ex']:+.2%} ({fin['ann_ex'] - base['ann_ex']:+.2%})", flush=True)
    print(f"          换手 {base['turn']:.1%} -> {fin['turn']:.1%}, "
          f"夏普 {base['sharpe']:.3f} -> {fin['sharpe']:.3f}, 回撤 {base['dd']:.2%} -> {fin['dd']:.2%}",
          flush=True)
    path = os.path.join(RESULTS_DIR, f"final_optimize_zz{u}_report.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"中证{u} 最终优化验证(三条路径叠加)\n\n")
        f.write(header + "\n" + "-" * len(header) + "\n")
        for name, m in rows:
            f.write(f"{name:<26}{m['hold']:>6.0f}{m['turn']:>7.1%}{m['net']:>+10.3%}"
                    f"{m['ann']:>+9.2%}{m['dd']:>9.2%}{m['sharpe']:>9.3f}{m['ann_ex']:>+9.2%}\n")
        f.write(f"\n叠加效果: 年化绝对 {base['ann']:+.2%} -> {fin['ann']:+.2%}, "
                f"年化超额 {base['ann_ex']:+.2%} -> {fin['ann_ex']:+.2%}\n")
    print(f"\n报告已保存: {path}", flush=True)
    print(f"总耗时 {time.time() - t0:.0f}s", flush=True)


def main():
    u = sys.argv[1] if len(sys.argv) > 1 else "1000"
    if "--final" in sys.argv:
        compare_final(u)
        return
    cache_dir, cost = UNIVERSES[u]
    t0 = time.time()
    pool, _, _ = get_pool(u, horizon=H)
    print(f"pool {len(pool)} 条, 缓冲带固定 {BUFFER:.0%}, 概率加权", flush=True)

    header = (f"{'选股比例':>9}{'持仓':>6}{'期数':>6}{'换手':>7}{'毛收益/期':>10}"
              f"{'净收益/期':>10}{'年化绝对':>9}{'年化波动':>9}{'最大回撤':>9}"
              f"{'日频夏普':>9}{'年化超额':>9}{'单只超额':>10}")
    print("\n" + header, flush=True)
    print("-" * len(header), flush=True)
    rows = []
    for tf in TOP_FRACS:
        t1 = time.time()
        rec = run(pool, tf, cost)
        m = metrics(rec, cache_dir, cost)
        row = (f"{tf:>9.0%}{m['hold']:>6.0f}{m['n']:>6}{m['turn']:>7.1%}{m['gross']:>+10.3%}"
               f"{m['net']:>+10.3%}{m['ann']:>+9.2%}{m['vol']:>9.2%}{m['dd']:>9.2%}"
               f"{m['sharpe']:>9.3f}{m['ann_ex']:>+9.2%}{m['per_stock']:>+10.2%}")
        print(row + f"  ({time.time() - t1:.0f}s)", flush=True)
        rows.append((tf, m))

    path = os.path.join(RESULTS_DIR, f"qfrac_zz{u}_report.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"中证{u} 选股范围优化(TOP_FRAC)\n")
        f.write(f"可执行口径, 概率加权, 缓冲带 {BUFFER:.0%}, H={H}\n\n")
        f.write(header + "\n" + "-" * len(header) + "\n")
        for tf, m in rows:
            f.write(f"{tf:>9.0%}{m['hold']:>6.0f}{m['n']:>6}{m['turn']:>7.1%}{m['gross']:>+10.3%}"
                    f"{m['net']:>+10.3%}{m['ann']:>+9.2%}{m['vol']:>9.2%}{m['dd']:>9.2%}"
                    f"{m['sharpe']:>9.3f}{m['ann_ex']:>+9.2%}{m['per_stock']:>+10.2%}\n")
    print(f"\n报告已保存: {path}", flush=True)
    print(f"总耗时 {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
