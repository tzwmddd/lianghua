"""最终组合优化: 交易层三项 + 新因子, 全部用最优参数一次跑通。

关键改动: 特征缺失**不做 dropna**, 直接喂 NaN 给 LightGBM(它原生支持缺失值)。
上一版用 dropna(subset=features) 导致新因子 3% 缺失时损失样本, 把基准也从
+7.62% 压到 +5.88%, 这是评估口径的错误。

用法: python final_combo.py [1000]
"""
import os
import sys
import time

import numpy as np
import pandas as pd
import lightgbm as lgb

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

from config import SEED, EMBARGO_DAYS, RESULTS_DIR
from zz_pool import BASE_FEATURES
from cross_section import neutralize
from _tune_model import get_pool
from holder_factor_test import build_holder_factors, FACTORS as HL_FACTORS

UNIVERSES = {"500": ("cache_zz500", 0.004), "1000": ("cache_zz1000", 0.005)}
LIQUIDITY_DROP = 0.2
MIN_TRAIN = 5000
H = 30
TOP_FRAC = 0.15
BUFFER = 0.5


def run(pool, features, cost, fillna=None, top_frac=TOP_FRAC, buffer_frac=BUFFER,
        use_weight=True):
    """指定交易参数 + 特征集。fillna: None=保留NaN(LightGBM 原生处理)。"""
    dates = sorted(pool["date"].unique())
    start = next(i for i, d in enumerate(dates) if d >= pd.Timestamp("2017-01-01"))
    rebal = dates[start::H]

    rec = []
    prev_hold = set()
    dates_used = []
    for t in rebal:
        cutoff = t - pd.Timedelta(days=EMBARGO_DAYS)
        train = pool[(pool["date"] < cutoff) & pool["target_rel"].notna()]
        # 只要求特征"至少有一个非缺失", 不因个别因子缺失丢样本
        tr_x = train[features]
        keep = tr_x.notna().any(axis=1).to_numpy()
        train = train[keep]
        if len(train) < MIN_TRAIN:
            continue
        cross = pool[(pool["date"] == t) & pool["stock_fwd"].notna()].copy()
        model = lgb.LGBMClassifier(
            n_estimators=150, learning_rate=0.10, num_leaves=63,
            subsample=0.8, colsample_bytree=0.8,
            random_state=SEED, verbosity=-1, n_jobs=-1)
        Xtr = train[features].to_numpy(dtype=float)
        Xcr = cross[features].to_numpy(dtype=float)
        if fillna is not None:
            Xtr = np.nan_to_num(Xtr, nan=fillna)
            Xcr = np.nan_to_num(Xcr, nan=fillna)
        model.fit(Xtr, train["target_rel"].to_numpy())
        cross["prob"] = model.predict_proba(Xcr)[:, 1]
        # 候选池口径: 先用全部有特征的股票定 k, 再叠加"有未来收益"与流动性过滤
        # (q_frac_test 用的是有 stock_fwd 的池子; 这里保持一致才能对齐)
        quality = cross[cross["turnover"].notna() | cross["turnover"].isna()].copy()
        if cross["turnover"].notna().sum() > 10:
            th = cross["turnover"].quantile(LIQUIDITY_DROP)
            quality = cross[cross["turnover"] >= th].copy()
        n_liq = len(quality)
        k = max(1, int(n_liq * top_frac))
        buf_k = max(k, int(n_liq * buffer_frac))
        cross = cross.sort_values("prob", ascending=False)
        buf_codes = set(cross.head(buf_k)["code"])
        buyable = cross[cross["tradable_buy"].astype(bool)]
        keep_h = [c for c in prev_hold if c in buf_codes]
        final = keep_h[:k]
        for c in buyable["code"]:
            if len(final) >= k:
                break
            if c not in final:
                final.append(c)
        if not final:
            continue
        hold = set(final)
        turn = len(hold - prev_hold) / len(hold) if prev_hold else 1.0
        prev_hold = hold
        q = cross[cross["code"].isin(hold)].copy()
        p = q["prob"].to_numpy(dtype=float)
        if use_weight and len(p) > 1 and p.max() > p.min():
            w = 0.5 + (p - p.min()) / (p.max() - p.min())
            w = w / w.sum()
        else:
            w = np.full(len(q), 1.0 / len(q))
        rec.append({"date": t, "hold": sorted(hold), "turn": turn, "w": w.tolist(),
                    "n": len(q),
                    "gross": float(np.dot(w, q["stock_fwd"].to_numpy())),
                    "excess": float(np.dot(w, q["excess_fwd"].to_numpy()))})
        dates_used.append(t)
    return rec


def daily_metrics(rec, cache_dir, cost):
    from data import load_cached
    if not rec:
        return {}
    dts = [r["date"] for r in rec]
    need = {c for r in rec for c in r["hold"]}
    px = {}
    for code in need:
        df = load_cached(code, cache_dir)
        if df is None:
            continue
        df = df[(df["date"] >= dts[0]) & (df["date"] <= dts[-1] + pd.Timedelta(days=1))]
        if len(df) >= 2:
            px[code] = df.set_index("date")["close"]
    mat = pd.DataFrame(px).sort_index().ffill()
    rets = mat.pct_change()
    segs = []
    for i, r in enumerate(rec[:-1]):
        hold = [c for c in r["hold"] if c in rets.columns]
        if not hold:
            continue
        win = rets.loc[(rets.index > dts[i]) & (rets.index <= dts[i + 1]), hold]
        if len(win) == 0:
            continue
        wmap = dict(zip(r["hold"], r["w"]))
        wv = np.array([wmap.get(c, 0.0) for c in hold], dtype=float)
        wv = wv / wv.sum() if wv.sum() > 0 else np.full(len(hold), 1.0 / len(hold))
        port = pd.Series(win.to_numpy() @ wv, index=win.index)
        port.iloc[0] -= r["turn"] * cost
        segs.append(port)
    pr = pd.concat(segs).sort_index()
    nav = (1 + pr).cumprod()
    net = np.array([r["gross"] for r in rec]) - np.array([r["turn"] for r in rec]) * cost
    exc = np.array([r["excess"] for r in rec])
    return dict(n=len(rec), hold=np.mean([r["n"] for r in rec]),
                turn=np.mean([r["turn"] for r in rec]),
                net=net.mean(), ann=float(nav.iloc[-1] ** (252 / len(pr)) - 1),
                ann_ex=float((1 + exc.mean()) ** (252 / H) - 1),
                dd=float((nav / nav.cummax() - 1).min()),
                sharpe=float(pr.mean() / pr.std(ddof=1) * np.sqrt(252)))


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("universe", nargs="?", default="1000", choices=["500", "1000"])
    ap.add_argument("--best", action="store_true", help="只跑基准/单因子/双因子三个")
    ap.add_argument("--no-mf", action="store_true", help="不加载资金流(只测股东户数)")
    ap.add_argument("--total", action="store_true", help="端到端总验证: 全关 vs 全开")
    args = ap.parse_args()
    u = args.universe
    cache_dir, cost = UNIVERSES[u]
    t0 = time.time()
    pool, _, _ = get_pool(u, horizon=H)
    pool = build_holder_factors(cache_dir, pool)
    hl = [f for f in HL_FACTORS if pool[f].notna().mean() > 0.5]
    pool = neutralize(pool, hl)
    print(f"pool {len(pool)} 条, 股东户数因子 {hl}", flush=True)

    # 资金流因子(如果数据已就绪)
    mf_feats = []
    try:
        from moneyflow_factor_test import build_moneyflow_factors, FACTORS as MF_FACTORS
        pool = build_moneyflow_factors(cache_dir, pool)
        mf_feats = [f for f in MF_FACTORS if pool[f].notna().mean() > 0.5]
        pool = neutralize(pool, mf_feats)
        print(f"资金流因子 {mf_feats}", flush=True)
    except Exception as e:  # noqa: BLE001
        print(f"资金流因子不可用: {str(e)[:80]}", flush=True)

    configs = [
        ("原始基准(收窄15%/缓冲50%/加权)", BASE_FEATURES),
        ("最终(+股东户数+资金流)", BASE_FEATURES + ["hl_chg_4q"] + (mf_feats[:3] if mf_feats else [])),
    ]
    if args.best:
        configs = [
            ("基准(仅技术面)", BASE_FEATURES),
            ("+hl_chg_4q", BASE_FEATURES + ["hl_chg_4q"]),
            ("+hl_chg_4q+资金流", BASE_FEATURES + ["hl_chg_4q"] + (mf_feats[:3] if mf_feats else [])),
        ]
    if args.no_mf:
        configs = [
            ("基准(仅技术面)", BASE_FEATURES),
            ("+hl_chg_4q", BASE_FEATURES + ["hl_chg_4q"]),
        ]
    if args.total:
        configs = [
            ("A 无优化(无缓冲/等权/不加因子)", BASE_FEATURES),
            ("B 最终(缓冲50%+加权+新因子)", BASE_FEATURES + ["hl_chg_4q"] + (mf_feats[:3] if mf_feats else [])),
        ]

    header = (f"{'特征集':<20}{'持仓':>6}{'换手':>7}{'净收益/期':>10}{'年化绝对':>9}"
              f"{'最大回撤':>9}{'日频夏普':>9}{'年化超额':>9}")
    print("\n" + header, flush=True)
    print("-" * len(header), flush=True)
    rows = []
    for i, (name, feats) in enumerate(configs):
        # 端到端总验证: A 组关掉全部优化, B 组全开
        kw = {}
        if args.total and name.startswith("A "):
            kw = dict(top_frac=0.2, buffer_frac=0.2, use_weight=False)
        t1 = time.time()
        rec = run(pool, feats, cost, fillna=None, **kw)
        m = daily_metrics(rec, cache_dir, cost)
        row = (f"{name:<20}{m['hold']:>6.0f}{m['turn']:>7.1%}{m['net']:>+10.3%}"
               f"{m['ann']:>+9.2%}{m['dd']:>9.2%}{m['sharpe']:>9.3f}{m['ann_ex']:>+9.2%}")
        print(row + f"  ({time.time() - t1:.0f}s)", flush=True)
        rows.append((name, m))
        pd.DataFrame(rec).to_csv(
            os.path.join(RESULTS_DIR, f"_final_{u}_{i}.csv"), index=False, encoding="utf-8-sig")

    path = os.path.join(RESULTS_DIR, f"final_combo_zz{u}_report.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"中证{u} 最终组合(交易层最优参数 + 新因子)\n")
        f.write(f"参数: top{TOP_FRAC:.0%} / 缓冲{BUFFER:.0%} / 概率加权 / H={H} / 特征缺失保留NaN\n\n")
        f.write(header + "\n" + "-" * len(header) + "\n")
        for name, m in rows:
            f.write(f"{name:<20}{m['hold']:>6.0f}{m['turn']:>7.1%}{m['net']:>+10.3%}"
                    f"{m['ann']:>+9.2%}{m['dd']:>9.2%}{m['sharpe']:>9.3f}{m['ann_ex']:>+9.2%}\n")
        base = rows[0][1]
        f.write("\n相对基准:\n")
        for name, m in rows[1:]:
            f.write(f"  {name}: 年化绝对 {m['ann'] - base['ann']:+.2%}, "
                    f"年化超额 {m['ann_ex'] - base['ann_ex']:+.2%}, "
                    f"夏普 {m['sharpe'] - base['sharpe']:+.3f}\n")
    print(f"\n报告已保存: {path}", flush=True)
    base = rows[0][1]
    for name, m in rows[1:]:
        print(f"  {name}: 年化绝对 {m['ann'] - base['ann']:+.2%}, "
              f"年化超额 {m['ann_ex'] - base['ann_ex']:+.2%}, "
              f"夏普 {m['sharpe'] - base['sharpe']:+.3f}", flush=True)
    print(f"总耗时 {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
