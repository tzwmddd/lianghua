"""中证500 调仓间隔细扫。

依据(解耦实验, results/decouple_zz500_report.txt):
  拆开"标签窗口"与"调仓间隔"两个因素后:
    标签 30->60 (间隔固定30天): 年化 -0.06%   -> 标签窗口几乎无关
    间隔 30->60 (标签固定60天): 年化 -0.70%   -> **调仓间隔才是主因**
  之前只测过 30/45/60 三档, 从没测过比 30 更短的间隔。

设计(干净隔离"调仓频率"):
  **标签窗口固定 30 天、embargo 固定 45 天**, 只变调仓间隔。
  这样 embargo 不是变量(硬规则: embargo >= 标签窗口), 且各档用的模型完全一致,
  差异纯粹来自"多久重新排序一次"。

为什么短间隔不一定更好:
  - 好处: 反应更快, 更早换掉已经走弱的股票
  - 代价: 换手率上升 -> 成本上升(30天时换手已 55%)
  最终看频率收益 vs 成本上升的净效果。

用法: python tune_rebal_500.py                 # 20/25/30/35/40
      python tune_rebal_500.py --r 15 20 25 30  # 自定义
"""
import argparse
import os
import sys
import time

import numpy as np
import pandas as pd
import lightgbm as lgb

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

from config import SEED, EMBARGO_DAYS, RESULTS_DIR
from data import load_cached
from zz_pool import BASE_FEATURES
from orthogonal_factors import attach_orthogonal_factors, ORTHO_FEATURES
from event_factors import build_event_factors
from tune_horizon_500 import get_pool, UNIVERSES, TOP_FRAC, BUFFER, FC, LIQUIDITY_DROP, MIN_TRAIN

LABEL_H = 30           # 标签窗口固定 30 天
EMB = 45               # embargo 固定 45 天(>= 30天标签, 不成为变量)


def run(pool, features, cost, rebal_h):
    dates = sorted(pool["date"].unique())
    start = next(i for i, d in enumerate(dates) if d >= pd.Timestamp("2017-01-01"))
    rebal = dates[start::rebal_h]
    rec = []
    prev_hold = set()
    for t in rebal:
        cutoff = t - pd.Timedelta(days=EMB)
        train = pool[(pool["date"] < cutoff) & pool["target_rel"].notna()]
        Xtr = train[features].to_numpy(dtype=float)
        keep = np.isfinite(Xtr).any(axis=1)
        train, Xtr = train[keep], Xtr[keep]
        if len(train) < MIN_TRAIN:
            continue
        cross = pool[(pool["date"] == t) & pool["stock_fwd"].notna()].copy()
        if len(cross) < 30:
            continue
        model = lgb.LGBMClassifier(
            n_estimators=150, learning_rate=0.10, num_leaves=63,
            subsample=0.8, colsample_bytree=0.8,
            random_state=SEED, verbosity=-1, n_jobs=-1)
        model.fit(Xtr, train["target_rel"].to_numpy())
        cross["prob"] = model.predict_proba(cross[features].to_numpy(dtype=float))[:, 1]
        if cross["turnover"].notna().sum() > 10:
            th = cross["turnover"].quantile(LIQUIDITY_DROP)
            cross = cross[cross["turnover"] >= th]
        n_liq = len(cross)
        k = max(1, int(n_liq * TOP_FRAC))
        buf_k = max(k, int(n_liq * BUFFER["500"]))
        cross = cross.sort_values("prob", ascending=False)
        buf_codes = set(cross.head(buf_k)["code"])
        buyable = cross[cross["tradable_buy"].astype(bool)]
        keep_h = [c for c in prev_hold if c in buf_codes]
        final = keep_h[:k]
        for c in buyable["code"]:
            if len(final) >= k:
                break
            if c not in final:
                final.append(c)
        if not final:
            continue
        hold = set(final)
        turn = len(hold - prev_hold) / len(hold) if prev_hold else 1.0
        prev_hold = hold
        q = cross[cross["code"].isin(hold)].copy()
        p = q["prob"].to_numpy(dtype=float)
        w = (0.5 + (p - p.min()) / (p.max() - p.min())) if (len(p) > 1 and p.max() > p.min()) \
            else np.ones(len(p))
        w = w / w.sum()
        rec.append({"date": t, "hold": sorted(hold), "turn": turn, "w": w.tolist(),
                    "excess": float(np.dot(w, q["excess_fwd"].to_numpy()))})
    return rec


def metrics(rec, cache_dir, cost, rebal_h):
    """逐日盯市: 用真实日收益, 与标签窗口无关。"""
    dts = [r["date"] for r in rec]
    need = {c for r in rec for c in r["hold"]}
    px = {}
    for code in need:
        df = load_cached(code, cache_dir)
        if df is None:
            continue
        df = df[(df["date"] >= dts[0]) & (df["date"] <= dts[-1] + pd.Timedelta(days=1))]
        if len(df) >= 2:
            px[code] = df.set_index("date")["close"]
    mat = pd.DataFrame(px).sort_index().ffill()
    rets = mat.pct_change()
    segs = []
    for i, r in enumerate(rec[:-1]):
        hold = [c for c in r["hold"] if c in rets.columns]
        if not hold:
            continue
        win = rets.loc[(rets.index > dts[i]) & (rets.index <= dts[i + 1]), hold]
        if len(win) == 0:
            continue
        wmap = dict(zip(r["hold"], r["w"]))
        wv = np.array([wmap.get(c, 0.0) for c in hold], dtype=float)
        wv = wv / wv.sum() if wv.sum() > 0 else np.full(len(hold), 1.0 / len(hold))
        port = pd.Series(win.to_numpy() @ wv, index=win.index)
        port.iloc[0] -= r["turn"] * cost
        segs.append(port)
    pr = pd.concat(segs).sort_index()
    nav = (1 + pr).cumprod()
    exc = np.array([r["excess"] for r in rec])
    return dict(n=len(rec), turn=np.mean([r["turn"] for r in rec]),
                ann=float(nav.iloc[-1] ** (252 / len(pr)) - 1),
                ann_ex=float((1 + exc.mean()) ** (252 / rebal_h) - 1),
                dd=float((nav / nav.cummax() - 1).min()),
                sharpe=float(pr.mean() / pr.std(ddof=1) * np.sqrt(252)),
                # 年化成本 = 每期换手 × 成本 × 年调仓次数
                cost_ann=float(np.mean([r["turn"] for r in rec]) * cost * 252 / rebal_h))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("universe", nargs="?", default="500", choices=["500", "1000"])
    ap.add_argument("--r", type=int, nargs="*", default=[20, 25, 30, 35, 40])
    args = ap.parse_args()
    u = args.universe
    _, cost = UNIVERSES[u]
    t0 = time.time()

    pool, cache_dir = get_pool(u, LABEL_H)      # 固定 30 天标签
    pool = attach_orthogonal_factors(pool, cache_dir)
    pool = build_event_factors(pool, cache_dir)
    feats = BASE_FEATURES + [f for f in ORTHO_FEATURES if f in pool.columns]
    feats += [f for f in FC[u] if f in pool.columns]
    print(f"中证{u}: pool {len(pool)} 条(标签窗口固定 {LABEL_H} 天), 特征 {len(feats)}",
          flush=True)

    header = (f"{'调仓间隔':>9}{'期数':>6}{'换手':>7}{'年化成本':>9}{'年化绝对':>9}"
              f"{'最大回撤':>9}{'日频夏普':>9}{'年化超额':>9}")
    print(f"\n=== 中证{u} 调仓间隔扫描 (标签固定 {LABEL_H} 天, 缓冲带 {BUFFER[u]}) ===")
    print(header)
    print("-" * len(header))
    rows = []
    for rh in args.r:
        t1 = time.time()
        m = metrics(run(pool, feats, cost, rh), cache_dir, cost, rh)
        row = (f"{rh:>8}天{m['n']:>6}{m['turn']:>7.1%}{m['cost_ann']:>9.2%}{m['ann']:>+9.2%}"
               f"{m['dd']:>9.2%}{m['sharpe']:>9.3f}{m['ann_ex']:>+9.2%}")
        print(row + f"  ({time.time() - t1:.0f}s)", flush=True)
        rows.append((rh, m))

    cur = [r for r in rows if r[0] == 30]
    best = max(rows, key=lambda r: r[1]["ann"])
    print(f"\n  最优调仓间隔 {best[0]} 天: 年化绝对 {best[1]['ann']:+.2%}, "
          f"夏普 {best[1]['sharpe']:.3f}, 换手 {best[1]['turn']:.1%}", flush=True)
    if cur:
        print(f"  相对当前(30天): 年化 {best[1]['ann'] - cur[0][1]['ann']:+.2%}, "
              f"夏普 {best[1]['sharpe'] - cur[0][1]['sharpe']:+.3f}", flush=True)
    print(f"\n  成本-频率对比(看短间隔的代价):", flush=True)
    for rh, m in rows:
        print(f"    {rh}天: 换手 {m['turn']:.1%}, 年化成本 {m['cost_ann']:.2%}, "
              f"年调仓 {252/rh:.1f} 次", flush=True)

    path = os.path.join(RESULTS_DIR, f"tune_rebal_zz{u}_report.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"中证{u} 调仓间隔扫描(标签窗口固定 {LABEL_H} 天, embargo {EMB} 天)\n")
        f.write(f"缓冲带 {BUFFER[u]} / top{TOP_FRAC:.0%} / 概率加权\n\n")
        for rh, m in rows:
            f.write(f"调仓{rh}天: 期数{m['n']} 换手{m['turn']:.1%} 年化成本{m['cost_ann']:.2%} "
                    f"年化{m['ann']:+.2%} 回撤{m['dd']:.2%} 夏普{m['sharpe']:.3f} "
                    f"超额{m['ann_ex']:+.2%}\n")
    print(f"\n报告已保存: {path}", flush=True)
    print(f"总耗时 {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
