"""中证500 交易层参数优化: 换手缓冲带 × 选股范围。

背景:
  中证500 之前的交易层参数是从中证1000 直接沿用的(top15% / 缓冲50% / 概率加权),
  从未在 500 上单独优化过。而中证500 的 alpha 明显更弱
  (基准年化超额 +6.03% vs 中证1000 的 +9.67%), 最优参数很可能不同。

  另外样本外验证曾显示: 中证500 的缓冲带 IS 最优 0.35 / OOS 最优 0.5,
  而中证1000 是 0.6/0.6 —— 即两个市场的最优缓冲带确实不一样。

做法:
  逐参数扫描, 每次只变一个参数; 其余固定在当前配置。
  特征集固定为"中证500 已确定的最优组合":
    技术面25 + 超额3 + 股东户数 + 资金流 + fc_np_to_mv
  评估: 逐日盯市 / 年化绝对 / 年化超额 / 最大回撤 / 日频夏普 / 换手

用法:
  python tune_zz500.py                # 全部(缓冲带 + 选股范围 + 加权)
  python tune_zz500.py --what buffer  # 只扫缓冲带
  python tune_zz500.py --what top     # 只扫选股范围
  python tune_zz500.py --what weight  # 只测加权方案
"""
import argparse
import os
import sys
import time

import numpy as np
import pandas as pd
import lightgbm as lgb

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

from config import SEED, EMBARGO_DAYS, RESULTS_DIR
from data import load_cached
from zz_pool import BASE_FEATURES
from orthogonal_factors import attach_orthogonal_factors, ORTHO_FEATURES
from event_factors import build_event_factors
from _tune_model import get_pool

UNIVERSES = {"500": ("cache_zz500", 0.004), "1000": ("cache_zz1000", 0.005)}
LIQUIDITY_DROP = 0.2
MIN_TRAIN = 5000
H = 30
# 中证500 已确定的因子组合
FC_500 = ("fc_np_to_mv",)
# 当前(沿用中证1000 的)默认值
DEF_TOP = 0.15
DEF_BUFFER = 0.5


def run(pool, features, cost, top_frac=DEF_TOP, buffer_frac=DEF_BUFFER,
        weight_scheme="prob"):
    dates = sorted(pool["date"].unique())
    start = next(i for i, d in enumerate(dates) if d >= pd.Timestamp("2017-01-01"))
    rebal = dates[start::H]
    rec = []
    prev_hold = set()
    for t in rebal:
        cutoff = t - pd.Timedelta(days=EMBARGO_DAYS)
        train = pool[(pool["date"] < cutoff) & pool["target_rel"].notna()]
        Xtr = train[features].to_numpy(dtype=float)
        keep = np.isfinite(Xtr).any(axis=1)
        train, Xtr = train[keep], Xtr[keep]
        if len(train) < MIN_TRAIN:
            continue
        cross = pool[(pool["date"] == t) & pool["stock_fwd"].notna()].copy()
        if len(cross) < 30:
            continue
        model = lgb.LGBMClassifier(
            n_estimators=150, learning_rate=0.10, num_leaves=63,
            subsample=0.8, colsample_bytree=0.8,
            random_state=SEED, verbosity=-1, n_jobs=-1)
        model.fit(Xtr, train["target_rel"].to_numpy())
        cross["prob"] = model.predict_proba(cross[features].to_numpy(dtype=float))[:, 1]
        if cross["turnover"].notna().sum() > 10:
            th = cross["turnover"].quantile(LIQUIDITY_DROP)
            cross = cross[cross["turnover"] >= th]
        n_liq = len(cross)
        k = max(1, int(n_liq * top_frac))
        buf_k = max(k, int(n_liq * buffer_frac))
        cross = cross.sort_values("prob", ascending=False)
        buf_codes = set(cross.head(buf_k)["code"])
        buyable = cross[cross["tradable_buy"].astype(bool)]
        keep_h = [c for c in prev_hold if c in buf_codes]
        final = keep_h[:k]
        for c in buyable["code"]:
            if len(final) >= k:
                break
            if c not in final:
                final.append(c)
        if not final:
            continue
        hold = set(final)
        turn = len(hold - prev_hold) / len(hold) if prev_hold else 1.0
        prev_hold = hold
        q = cross[cross["code"].isin(hold)].copy()
        p = q["prob"].to_numpy(dtype=float)
        if weight_scheme == "prob" and len(p) > 1 and p.max() > p.min():
            w = 0.5 + (p - p.min()) / (p.max() - p.min())
            w = w / w.sum()
        else:
            w = np.full(len(q), 1.0 / len(q))
        rec.append({"date": t, "hold": sorted(hold), "turn": turn, "w": w.tolist(),
                    "n": len(q),
                    "gross": float(np.dot(w, q["stock_fwd"].to_numpy())),
                    "excess": float(np.dot(w, q["excess_fwd"].to_numpy()))})
    return rec


def metrics(rec, cache_dir, cost):
    dts = [r["date"] for r in rec]
    need = {c for r in rec for c in r["hold"]}
    px = {}
    for code in need:
        df = load_cached(code, cache_dir)
        if df is None:
            continue
        df = df[(df["date"] >= dts[0]) & (df["date"] <= dts[-1] + pd.Timedelta(days=1))]
        if len(df) >= 2:
            px[code] = df.set_index("date")["close"]
    mat = pd.DataFrame(px).sort_index().ffill()
    rets = mat.pct_change()
    segs = []
    for i, r in enumerate(rec[:-1]):
        hold = [c for c in r["hold"] if c in rets.columns]
        if not hold:
            continue
        win = rets.loc[(rets.index > dts[i]) & (rets.index <= dts[i + 1]), hold]
        if len(win) == 0:
            continue
        wmap = dict(zip(r["hold"], r["w"]))
        wv = np.array([wmap.get(c, 0.0) for c in hold], dtype=float)
        wv = wv / wv.sum() if wv.sum() > 0 else np.full(len(hold), 1.0 / len(hold))
        port = pd.Series(win.to_numpy() @ wv, index=win.index)
        port.iloc[0] -= r["turn"] * cost
        segs.append(port)
    pr = pd.concat(segs).sort_index()
    nav = (1 + pr).cumprod()
    net = np.array([r["gross"] for r in rec]) - np.array([r["turn"] for r in rec]) * cost
    exc = np.array([r["excess"] for r in rec])
    return dict(n=len(rec), hold=np.mean([r["n"] for r in rec]),
                turn=np.mean([r["turn"] for r in rec]),
                net=net.mean(), ann=float(nav.iloc[-1] ** (252 / len(pr)) - 1),
                ann_ex=float((1 + exc.mean()) ** (252 / H) - 1),
                dd=float((nav / nav.cummax() - 1).min()),
                sharpe=float(pr.mean() / pr.std(ddof=1) * np.sqrt(252)))


HEADER = (f"{'参数':<22}{'持仓':>6}{'换手':>7}{'净收益/期':>10}{'年化绝对':>9}"
          f"{'最大回撤':>9}{'日频夏普':>9}{'年化超额':>9}")


def scan(pool, feats, cache_dir, cost, title, param, values, fixed):
    print(f"\n=== {title} ===", flush=True)
    print(HEADER, flush=True)
    print("-" * len(HEADER), flush=True)
    rows = []
    for v in values:
        kw = dict(fixed)
        kw[param] = v
        m = metrics(run(pool, feats, cost, **kw), cache_dir, cost)
        mark = "  ← 当前" if abs(v - (DEF_BUFFER if param == "buffer_frac" else DEF_TOP)) < 1e-9 \
            else ""
        row = (f"{param}={v:<14.2f}{m['hold']:>6.0f}{m['turn']:>7.1%}{m['net']:>+10.3%}"
               f"{m['ann']:>+9.2%}{m['dd']:>9.2%}{m['sharpe']:>9.3f}{m['ann_ex']:>+9.2%}{mark}")
        print(row, flush=True)
        rows.append((v, m))
    best = max(rows, key=lambda r: r[1]["ann"])
    cur = [r for r in rows if abs(r[0] - (DEF_BUFFER if param == "buffer_frac"
                                         else DEF_TOP)) < 1e-9]
    print(f"  最优 {param}={best[0]}: 年化绝对 {best[1]['ann']:+.2%}, "
          f"夏普 {best[1]['sharpe']:.3f}", flush=True)
    if cur:
        print(f"  相对当前配置: 年化绝对 {best[1]['ann'] - cur[0][1]['ann']:+.2%}, "
              f"夏普 {best[1]['sharpe'] - cur[0][1]['sharpe']:+.3f}", flush=True)
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("universe", nargs="?", default="500", choices=["500", "1000"])
    ap.add_argument("--what", default="all", choices=["buffer", "top", "weight", "all"])
    args = ap.parse_args()
    u = args.universe
    cache_dir, cost = UNIVERSES[u]
    t0 = time.time()

    pool, _, _ = get_pool(u, horizon=H)
    pool = attach_orthogonal_factors(pool, cache_dir)
    pool = build_event_factors(pool, cache_dir)
    feats = BASE_FEATURES + [f for f in ORTHO_FEATURES if f in pool.columns]
    fc = FC_500 if u == "500" else ("fc_type", "fc_pchg_mid")
    feats += [f for f in fc if f in pool.columns]
    print(f"中证{u}: pool {len(pool)} 条, 特征数 {len(feats)}", flush=True)

    out_lines = []
    if args.what in ("buffer", "all"):
        rows = scan(pool, feats, cache_dir, cost, "换手缓冲带", "buffer_frac",
                    [0.2, 0.35, 0.5, 0.6, 0.7], dict(top_frac=DEF_TOP))
        out_lines.append(("换手缓冲带", rows))
    if args.what in ("top", "all"):
        rows = scan(pool, feats, cache_dir, cost, "选股范围", "top_frac",
                    [0.1, 0.15, 0.2, 0.3], dict(buffer_frac=DEF_BUFFER))
        out_lines.append(("选股范围", rows))
    if args.what in ("weight", "all"):
        print(f"\n=== 持仓加权方案 ===", flush=True)
        print(HEADER, flush=True)
        print("-" * len(HEADER), flush=True)
        rows = []
        for ws in ["equal", "prob"]:
            m = metrics(run(pool, feats, cost, weight_scheme=ws), cache_dir, cost)
            row = (f"{ws:<22}{m['hold']:>6.0f}{m['turn']:>7.1%}{m['net']:>+10.3%}"
                   f"{m['ann']:>+9.2%}{m['dd']:>9.2%}{m['sharpe']:>9.3f}{m['ann_ex']:>+9.2%}")
            print(row, flush=True)
            rows.append((ws, m))
        out_lines.append(("加权方案", rows))

    path = os.path.join(RESULTS_DIR, f"tune_zz{u}_report.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"中证{u} 交易层参数优化\n")
        f.write(f"特征集: 技术面 + 股东户数 + 资金流 + {'/'.join(fc)}\n")
        f.write("口径: 可执行体系(t+1开盘) + 逐日盯市, H=30\n\n")
        for title, rows in out_lines:
            f.write(f"### {title}\n")
            for v, m in rows:
                f.write(f"{v}\t持{m['hold']:.0f}\t换手{m['turn']:.1%}\t净{m['net']:+.3%}\t"
                        f"年化{m['ann']:+.2%}\t回撤{m['dd']:.2%}\t夏普{m['sharpe']:.3f}\t"
                        f"超额{m['ann_ex']:+.2%}\n")
            f.write("\n")
    print(f"\n报告已保存: {path}", flush=True)
    print(f"总耗时 {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
